﻿Public Class view_tag
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        gettagInformation()


    End Sub

    Sub gettagInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_tag As New Tag
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_tag.tag_Id = T_Id
            T_tag.executeSelecttag()

            If T_tag.Error_Id = 0 Then

                txt_tag_name.Text = T_tag.tag_Name
                txt_project.Text = T_tag.Project_Name
                txt_tag_type.Text = T_tag.tag_Type_Description
                txt_status.Text = T_tag.Status_Name
                txt_priority.Text = T_tag.Priority_Name
                txt_assigned_by.Text = T_tag.Assigned_By
                txt_assigned_to.Text = T_tag.Assigned_To
                txt_start_date.Text = T_tag.Start_Date
                txt_end_date.Text = T_tag.End_Date
                txt_comment.Text = T_tag.Comment

                T_tag.DS_Data = DS_Tag_Comments_Manager
                T_tag.selecttagComments()

            Else
                T_Msg = "Error Retrieving tag Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding tag Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_tag = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

End Class