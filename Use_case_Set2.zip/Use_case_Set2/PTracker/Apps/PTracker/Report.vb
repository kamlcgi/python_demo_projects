﻿
'Component Name: Report
'Description: Used to Create, Update, View and Delete report Information
'Author:  Srinivasan Subbanchattiar 
'Created By: Abinav.M 
'Created Date: 11/14/2011 
'Modified By: Abinav.M 
'Modified Date: 02/01/2011 
'Version: 1.0

Imports System.Web
Imports System.Data
Imports System.Data.SqlClient

Public Class Report



    Protected intErr As Integer
    Protected strErr As String
    Protected strBy As String

    Protected strReportId As String
    Protected strReportName As String
    Protected strReportQuery As String
    Protected strReportDescription As String
    Protected strUserId As String

    Protected gvData As GridView
    Protected dsData As SqlDataSource

    'for view purpose only
    Protected strCreatedBy As String
    Protected dtCreatedDate As Date
    Protected strModifiedBy As String
    Protected dtModifiedDate As Date


    Public Sub New()

        Clear()

    End Sub


    Public Sub Clear()

        intErr = Nothing
        strErr = Nothing
        strBy = Nothing

        strReportId = Nothing
        strReportName = Nothing
        strReportQuery = Nothing
        strReportDescription = Nothing
        strUserId = Nothing

        gvData = Nothing
        dsData = Nothing

        strCreatedBy = Nothing
        dtCreatedDate = Nothing
        strModifiedBy = Nothing
        dtModifiedDate = Nothing


    End Sub

    Public Property Error_Id() As Integer
        Get
            Return intErr
        End Get
        Set(ByVal Value As Integer)
            intErr = Value
        End Set
    End Property

    Public Property Error_Message() As String
        Get
            Return strErr
        End Get
        Set(ByVal Value As String)
            strErr = Value
        End Set
    End Property

    Public Property Report_Id() As String
        Get
            Return strReportId
        End Get
        Set(ByVal Value As String)
            strReportId = Value
        End Set
    End Property

    Public Property Report_Name() As String
        Get
            Return strReportName
        End Get
        Set(ByVal Value As String)
            strReportName = Value
        End Set
    End Property

    Public Property Report_Query() As String
        Get
            Return strReportQuery
        End Get
        Set(ByVal Value As String)
            strReportQuery = Value
        End Set
    End Property
    Public Property Report_Description() As String
        Get
            Return strReportDescription
        End Get
        Set(ByVal Value As String)
            strReportDescription = Value
        End Set
    End Property

    Public Property User_ID() As String
        Get
            Return strUserId
        End Get
        Set(ByVal Value As String)
            strUserId = Value
        End Set
    End Property

    Public Property Created_By() As String
        Get
            Return strCreatedBy
        End Get
        Set(ByVal Value As String)
            strCreatedBy = Value
        End Set
    End Property

    Public Property Modified_By() As String
        Get
            Return strModifiedBy
        End Get
        Set(ByVal Value As String)
            strModifiedBy = Value
        End Set
    End Property

    Public Property Created_Date() As Date
        Get
            Return dtCreatedDate
        End Get
        Set(ByVal Value As Date)
            dtCreatedDate = Value
        End Set
    End Property

    Public Property Modified_Date() As Date
        Get
            Return dtModifiedDate
        End Get
        Set(ByVal Value As Date)
            dtModifiedDate = Value
        End Set
    End Property
  


    Public Property DS_Data() As SqlDataSource
        Get
            Return dsData
        End Get
        Set(ByVal Value As SqlDataSource)
            dsData = Value
        End Set
    End Property

    Public Property GV_Data() As GridView
        Get
            Return gvData
        End Get
        Set(ByVal Value As GridView)
            gvData = Value
        End Set
    End Property

    Public Property By() As String
        Get
            Return strBy
        End Get
        Set(ByVal Value As String)
            strBy = Value
        End Set
    End Property

    Public Sub selectAllReports()

        Dim dbCon As New DBAccess

        'Get all the User information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_reports"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub runReports()

        Dim dbCon As New DBAccess

        'Get all the Report information from the database


        DS_Data.SelectParameters.Clear()
        DS_Data.SelectCommand = "dbo.sp_run_reports"
        DS_Data.SelectParameters.Add("Report_id", strReportId)
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub executeSelectReport()

        If Not IsDBNull(strReportId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the user information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_report", _
                         New SqlParameter("@report_id", strReportId))

            If dbRs.Read Then


                If Not IsDBNull(dbRs("Report_name")) Then
                    strReportName = dbRs("Report_name")
                End If

                If Not IsDBNull(dbRs("Report_query")) Then
                    strReportQuery = dbRs("Report_query")
                End If

                If Not IsDBNull(dbRs("Report_description")) Then
                    strReportDescription = dbRs("Report_description")
                End If

                If Not IsDBNull(dbRs("Created_by")) Then
                    strCreatedBy = dbRs("Created_by")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                If Not IsDBNull(dbRs("Created_date")) Then
                    dtCreatedDate = dbRs("Created_date")
                End If

                If Not IsDBNull(dbRs("Modified_date")) Then
                    dtModifiedDate = dbRs("Modified_date")
                End If

                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 'Id is Nothing
            strErr = "ReportId is Nothing"

        End If

    End Sub 'executeSelectReport()


    Public Sub executeCreateReport()


        Dim dbCon As New DBAccess
        Dim T_id As String

        'Create New report to the database 

        T_id = dbCon.RunSPReturnId("dbo.sp_create_report_wiz", _
                         New SqlParameter("@report_name", strReportName), _
                         New SqlParameter("@report_query", strReportQuery), _
                         New SqlParameter("@report_description", strReportDescription), _
                         New SqlParameter("@Created_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Create New Report Failed
            strErr = "Create New Report Failed"

        Else

            intErr = 0 'New Report Created Successfully
            strErr = "New Report Created Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeCreateReport()


    Public Sub executeUpdateReport()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Save report Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_report_wiz", _
                         New SqlParameter("@Report_id", strReportId), _
                         New SqlParameter("@Report_name", strReportName), _
                         New SqlParameter("@Report_query", strReportQuery), _
                         New SqlParameter("@Report_description", strReportDescription), _
                         New SqlParameter("@Modified_by", strBy))

        If T_id = -1 Then

            intErr = -1 'Update report Failed
            strErr = "Update report Failed"

        Else

            intErr = 0 'report Information Saved Successfully
            strErr = "report Information Saved Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateReport()



    Public Sub executeDeleteReport()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Delete report Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_delete_report_wiz", _
                         New SqlParameter("@Report_id", strReportId), _
                         New SqlParameter("@Modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Delete Report Failed
            strErr = "Delete Report Failed"

        Else

            intErr = 0 'Report Information Deleted Successfully
            strErr = "Report Information Deleted Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeletereport()

End Class
