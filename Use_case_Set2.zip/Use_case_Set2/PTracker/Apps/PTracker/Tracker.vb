

'Component Name: Tracker
'Description: Used to Create, Update, View and Delete Tracker Information
'Author:  Srinivasan Subbanchattiar 
'Created By: Arpita Das 
'Created Date: 01/02/2012 
'Modified By: Arpita Das 
'Modified Date: 01/02/2012 
'Version: 1.0

Imports System.Web
Imports System.Data
Imports System.Data.SqlClient

Public Class Tracker

    Protected intErr As Integer
    Protected strErr As String
    Protected strBy As String

    Protected strTrackerId As String
    Protected strTrackerName As String
    Protected strProjectId As String
    Protected strProjectName As String
    Protected intTrackerTypeId As Integer
    Protected strTrackerTypeDescription As String
    Protected intStatusId As Integer
    Protected strStatusName As String
    Protected intPriorityId As Integer
    Protected strPriorityName As String
    Protected strUserId As String
    Protected strAssignedBy As String
    Protected strAssignedTo As String

    Protected dtStartDate As String
    Protected dtEndDate As String

    Protected strComment As String



    Protected strTrackerCommentId As String
    Protected strTrackerComment As String


    Protected intTrackerGroupId As Integer
    Protected strTrackerGroupName As String

    Protected gvData As GridView
    Protected dsData As SqlDataSource

    'for view purpose only
    Protected strCreatedBy As String
    Protected dtCreatedDate As Date
    Protected strModifiedBy As String
    Protected dtModifiedDate As Date
   



    Public Sub New()

        Clear()

    End Sub


    Public Sub Clear()

        intErr = Nothing
        strErr = Nothing
        strBy = Nothing

        strTrackerId = Nothing
        strTrackerName = Nothing
        strProjectId = Nothing
        strProjectName = Nothing
        intTrackerTypeId = Nothing
        strTrackerTypeDescription = Nothing
        intStatusId = Nothing
        strStatusName = Nothing
        intPriorityId = Nothing
        strPriorityName = Nothing

        dtStartDate = Nothing
        dtEndDate = Nothing

        strComment = Nothing

        strUserId = Nothing
        strAssignedBy = Nothing
        strAssignedTo = Nothing



        gvData = Nothing
        dsData = Nothing

        strCreatedBy = Nothing
        dtCreatedDate = Nothing
        strModifiedBy = Nothing
        dtModifiedDate = Nothing
     


    End Sub

    Public Property Error_Id() As Integer
        Get
            Return intErr
        End Get
        Set(ByVal Value As Integer)
            intErr = Value
        End Set
    End Property

    Public Property Error_Message() As String
        Get
            Return strErr
        End Get
        Set(ByVal Value As String)
            strErr = Value
        End Set
    End Property

    Public Property Tracker_Id() As String
        Get
            Return strTrackerId
        End Get
        Set(ByVal Value As String)
            strTrackerId = Value
        End Set
    End Property

    Public Property Tracker_Name() As String
        Get
            Return strTrackerName
        End Get
        Set(ByVal Value As String)
            strTrackerName = Value
        End Set
    End Property

    Public Property Project_Id() As String
        Get
            Return strProjectId
        End Get
        Set(ByVal Value As String)
            strProjectId = Value
        End Set
    End Property

    Public Property Project_Name() As String
        Get
            Return strProjectName
        End Get
        Set(ByVal Value As String)
            strProjectName = Value
        End Set
    End Property


    Public Property Tracker_Type_Id() As Integer
        Get
            Return intTrackerTypeId
        End Get
        Set(ByVal Value As Integer)
            intTrackerTypeId = Value
        End Set
    End Property

    Public Property Tracker_Type_Description() As String
        Get
            Return strTrackerTypeDescription
        End Get
        Set(ByVal Value As String)
            strTrackerTypeDescription = Value
        End Set
    End Property

    Public Property Status_Id() As Integer
        Get
            Return intStatusId
        End Get
        Set(ByVal Value As Integer)
            intStatusId = Value
        End Set
    End Property
    Public Property Status_Name() As String
        Get
            Return strStatusName
        End Get
        Set(ByVal Value As String)
            strStatusName = Value
        End Set
    End Property

    Public Property Priority_Id() As Integer
        Get
            Return intPriorityId
        End Get
        Set(ByVal Value As Integer)
            intPriorityId = Value
        End Set
    End Property

    Public Property Priority_Name() As String
        Get
            Return strPriorityName
        End Get
        Set(ByVal Value As String)
            strPriorityName = Value
        End Set
    End Property


    Public Property User_id() As String
        Get
            Return strUserId
        End Get
        Set(ByVal Value As String)
            strUserId = Value
        End Set
    End Property
    Public Property Assigned_By() As String
        Get
            Return strAssignedBy
        End Get
        Set(ByVal Value As String)
            strAssignedBy = Value
        End Set
    End Property
    Public Property Assigned_To() As String
        Get
            Return strAssignedTo
        End Get
        Set(ByVal Value As String)
            strAssignedTo = Value
        End Set
    End Property

    Public Property Start_Date() As String
        Get
            Return dtStartDate
        End Get
        Set(ByVal Value As String)
            dtStartDate = Value
        End Set
    End Property
    Public Property End_Date() As String
        Get
            Return dtEndDate
        End Get
        Set(ByVal Value As String)
            dtEndDate = Value
        End Set
    End Property

    Public Property Comment() As String
        Get
            Return strComment
        End Get
        Set(ByVal Value As String)
            strComment = Value
        End Set
    End Property


    Public Property DS_Data() As SqlDataSource
        Get
            Return dsData
        End Get
        Set(ByVal Value As SqlDataSource)
            dsData = Value
        End Set
    End Property

    Public Property GV_Data() As GridView
        Get
            Return gvData
        End Get
        Set(ByVal Value As GridView)
            gvData = Value
        End Set
    End Property

    Public Property By() As String
        Get
            Return strBy
        End Get
        Set(ByVal Value As String)
            strBy = Value
        End Set
    End Property

    Public Property Created_By() As String
        Get
            Return strCreatedBy
        End Get
        Set(ByVal Value As String)
            strCreatedBy = Value
        End Set
    End Property

    Public Property Modified_By() As String
        Get
            Return strModifiedBy
        End Get
        Set(ByVal Value As String)
            strModifiedBy = Value
        End Set
    End Property

    Public Property Created_Date() As Date
        Get
            Return dtCreatedDate
        End Get
        Set(ByVal Value As Date)
            dtCreatedDate = Value
        End Set
    End Property

    Public Property Modified_Date() As Date
        Get
            Return dtModifiedDate
        End Get
        Set(ByVal Value As Date)
            dtModifiedDate = Value
        End Set
    End Property
  

    Public Sub selectAllTrackers()

        Dim dbCon As New DBAccess

        'Get all the Tag information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_trackers"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub selectTrackerComments()

        Dim dbCon As New DBAccess

        'Get all the Tag information from the database

        DS_Data.SelectParameters.Clear()
        DS_Data.SelectCommand = "dbo.sp_get_all_tracker_comments"
        DS_Data.SelectParameters.Add("Tracker_id", strTrackerId)
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub executeSelectTracker()

        If Not IsDBNull(strTrackerId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the user information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_tracker", _
                         New SqlParameter("@Tracker_id", strTrackerId))

            If dbRs.Read Then

                If Not IsDBNull(dbRs("Tracker_name")) Then
                    strTrackerName = dbRs("Tracker_name")
                End If

                If Not IsDBNull(dbRs("Project_id")) Then
                    strProjectId = dbRs("Project_id")
                End If
                If Not IsDBNull(dbRs("Project_name")) Then
                    strProjectName = dbRs("Project_name")
                End If
                If Not IsDBNull(dbRs("Tracker_type_id")) Then
                    intTrackerTypeId = dbRs("Tracker_type_id")
                End If
                If Not IsDBNull(dbRs("Tracker_type_description")) Then
                    strTrackerTypeDescription = dbRs("Tracker_type_description")
                End If

                If Not IsDBNull(dbRs("Status_id")) Then
                    intStatusId = dbRs("Status_id")
                End If
                If Not IsDBNull(dbRs("Status_name")) Then
                    strStatusName = dbRs("Status_name")
                End If

                If Not IsDBNull(dbRs("Priority_id")) Then
                    intPriorityId = dbRs("Priority_id")
                End If

                If Not IsDBNull(dbRs("Priority_name")) Then
                    strPriorityName = dbRs("Priority_name")
                End If

                If Not IsDBNull(dbRs("Assigned_user_id")) Then
                    strUserId = dbRs("Assigned_user_id")
                End If
                If Not IsDBNull(dbRs("Assigned_by")) Then
                    strAssignedBy = dbRs("Assigned_by")
                End If
                If Not IsDBNull(dbRs("Assigned_to")) Then
                    strAssignedTo = dbRs("Assigned_to")
                End If

                If Not IsDBNull(dbRs("Created_by")) Then
                    strCreatedBy = dbRs("Created_by")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                If Not IsDBNull(dbRs("Created_date")) Then
                    dtCreatedDate = dbRs("Created_date")
                End If

                If Not IsDBNull(dbRs("Modified_date")) Then
                    dtModifiedDate = dbRs("Modified_date")
                End If

                If Not IsDBNull(dbRs("Start_date")) Then
                    dtStartDate = dbRs("Start_date")
                End If

                If Not IsDBNull(dbRs("End_date")) Then
                    dtEndDate = dbRs("End_date")
                End If
                If Not IsDBNull(dbRs("Comment")) Then
                    strComment = dbRs("Comment")
                End If
                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If
            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else
            intErr = -2 'Id is Nothing
            strErr = "UserId is Nothing"

        End If

    End Sub 'executeSelectTracker()

    Public Sub executeCreateTracker()

        Dim dbCon As New DBAccess
        Dim T_User_id As String

        'Create New Tracker to the database 

        T_User_id = dbCon.RunSPReturnId("dbo.sp_create_tracker_wiz", _
                            New SqlParameter("@Tracker_name", strTrackerName), _
                            New SqlParameter("@Project_id", strProjectId), _
                            New SqlParameter("@Tracker_type_id", intTrackerTypeId),
                            New SqlParameter("@Status_id", intStatusId), _
                            New SqlParameter("@Priority_id", intPriorityId), _
                            New SqlParameter("@Assigned_user_id", strUserId), _
                            New SqlParameter("@Assigned_by", strAssignedBy), _
                            New SqlParameter("@Assigned_to", strAssignedTo), _
                            New SqlParameter("@Start_date", dtStartDate), _
                            New SqlParameter("@End_date", dtEndDate), _
                            New SqlParameter("@Comment", strComment), _
                            New SqlParameter("@created_by", strBy))

        If T_User_id = "-1" Then

            intErr = -1 'Create New Tracker Failed
            strErr = "Create New Tracker Failed"

        Else

            intErr = 0 'New Tracker Created Successfully
            strErr = "New Tracker Created Successfully"

        End If

        dbCon = Nothing
    End Sub 'executeCreateTracker()

    Public Sub executeUpdateTracker()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Save Tracker Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_tracker_wiz", _
                            New SqlParameter("@Tracker_id", strTrackerId), _
                            New SqlParameter("@Tracker_name", strTrackerName), _
                            New SqlParameter("@Project_id", strProjectId), _
                            New SqlParameter("@Tracker_type_id", intTrackerTypeId),
                            New SqlParameter("@Status_id", intStatusId), _
                            New SqlParameter("@Priority_id", intPriorityId), _
                            New SqlParameter("@Assigned_user_id", strUserId), _
                            New SqlParameter("@Assigned_by", strAssignedBy), _
                            New SqlParameter("@Assigned_to", strAssignedTo), _
                            New SqlParameter("@Start_date", dtStartDate), _
                            New SqlParameter("@End_date", dtEndDate), _
                             New SqlParameter("@Comment", strComment), _
                            New SqlParameter("@modified_by", strBy))

        If T_id = -1 Then

            intErr = -1 'Update Tracker Failed
            strErr = "Update Tracker Failed"

        Else

            intErr = 0 'Tracker Information Saved Successfully
            strErr = "Tracker Information Saved Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateTracker()



    Public Sub executeDeleteTracker()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Delete Tracker Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_delete_tracker_wiz", _
                         New SqlParameter("@Tracker_id", strTrackerId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Delete Tracker Failed
            strErr = "Delete Tracker Failed"

        Else

            intErr = 0 'Tracker Information Deleted Successfully
            strErr = "Tracker Information Deleted Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeleteTracker()


    Public Sub executeAddTrackerComments()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Add Tracker Comments Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_add_tracker_to_comment", _
                         New SqlParameter("@Tracker_id", strTrackerId), _
                         New SqlParameter("@Tracker_comment", strComment), _
                         New SqlParameter("@created_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Add Tracker Comments Failed
            strErr = "Add Tracker Comments Failed"

        Else

            intErr = 0 'Added Tracker Comments Information Successfully
            strErr = "Added Tracker Comments Information Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeleteTracker()

End Class



