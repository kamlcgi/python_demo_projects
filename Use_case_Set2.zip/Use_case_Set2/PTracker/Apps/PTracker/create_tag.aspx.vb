﻿Public Class create_tag
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            setLookups()
        End If
    End Sub

    Protected Sub create_tag(ByVal sender As Object, ByVal e As EventArgs) Handles btn_create_tag.Click

        createtagInformation()

    End Sub

    Sub createtagInformation()

        Dim T_Tag As New Tag
        Dim T_Security As New PAL_Security
        Dim T_Msg As String = ""

        Try
            T_Tag.Tag_Name = txt_tag_name.Text
            T_Tag.Project_Id = ddl_project.SelectedValue
            T_Tag.Tag_Type_Id = ddl_tag_type.SelectedValue
            T_Tag.Status_Id = ddl_status.SelectedValue
            T_Tag.Priority_Id = ddl_priority.SelectedValue
            T_Tag.User_id = ddl_user_list.SelectedValue
            T_Tag.Assigned_By = ddl_user_list.SelectedValue
            T_Tag.Assigned_To = ddl_assigned_to.SelectedValue
            T_Tag.Start_Date = txt_start_date.Text
            T_Tag.End_Date = txt_end_date.Text
            T_Tag.Comment = txt_comment.Text

            T_Tag.By = Session("user_Id")
            T_Tag.executeCreateTag()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Creating New Tag Information."
                T_Security.Browser(Request)
                T_Security.By = Session("user_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Creating New Tag Information."
            T_Security.Browser(Request)
            T_Security.By = Session("user_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("Tag_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub
   
    Sub setLookups()

        Dim T_Lookup As New PLookup


        T_Lookup.bindTagTypeList(ddl_tag_type)
        T_Lookup.bindProjectList(ddl_project)
        T_Lookup.bindStatusList(ddl_status)
        T_Lookup.bindPriorityList(ddl_priority)
        T_Lookup.bindAssignedUserList(ddl_user_list)
        T_Lookup.bindAssignedUserListTo(ddl_assigned_to)



        T_Lookup = Nothing

    End Sub

  

End Class