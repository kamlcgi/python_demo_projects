﻿Public Class delete_tracker
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            getTrackerInformation()

        End If

    End Sub

    Protected Sub delete_Tracker(ByVal sender As Object, ByVal e As EventArgs) Handles btn_delete.Click

        deleteTrackerInformation()

    End Sub

    Sub getTrackerInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Tracker As New Tracker
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Tracker.Tracker_Id = T_Id
            T_Tracker.executeSelectTracker()

            If T_Tracker.Error_Id = 0 Then

                lbl_text.Text = T_Tracker.Tracker_Name

            Else

                T_Msg = "Error Retrieving Tracker Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Tracker Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Tracker = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub deleteTrackerInformation()

        Dim T_Tracker As New Tracker
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try
            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Tracker.Tracker_Id = T_Id
            T_Tracker.By = Session("User_Id")
            T_Tracker.executeDeleteTracker()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Deleting Tracker Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Deleting Tracker Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Tracker = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("tracker_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

End Class