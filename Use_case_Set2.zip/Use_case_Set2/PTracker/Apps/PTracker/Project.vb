﻿
'Component Name: Project
'Description: Used to Create, Update, View and Delete Project Information
'Author:  Srinivasan Subbanchattiar 
'Created By: Rolina Nayak 
'Created Date: 02/01/2012 
'Modified By: Rolina Nayak  
'Modified Date: 02/14/2012 
'Version: 1.0

Imports System.Web
Imports System.Data
Imports System.Data.SqlClient

Public Class Project

    Protected intErr As Integer
    Protected strErr As String
    Protected strBy As String

    Protected strProjectId As String
    Protected strProjectName As String
    Protected strProjectShortName As String
    Protected strProjectDescription As String
    Protected intStatusId As Integer
    Protected strStatusName As String
    Protected strComments As String

    Protected dtStartDate As String
    Protected dtEndDate As String

    Protected gvData As GridView
    Protected dsData As SqlDataSource

    'for view purpose only
    Protected strCreatedBy As String
    Protected dtCreatedDate As Date
    Protected strModifiedBy As String
    Protected dtModifiedDate As Date


    Public Sub New()

        Clear()

    End Sub


    Public Sub Clear()

        intErr = Nothing
        strErr = Nothing
        strBy = Nothing

        strProjectId = Nothing
        strProjectName = Nothing
        strProjectShortName = Nothing
        strProjectDescription = Nothing
        intStatusId = Nothing
        strStatusName = Nothing

        strComments = Nothing
        dtStartDate = Nothing
        dtEndDate = Nothing


        gvData = Nothing
        dsData = Nothing

        strCreatedBy = Nothing
        dtCreatedDate = Nothing
        strModifiedBy = Nothing
        dtModifiedDate = Nothing

    End Sub

    Public Property Error_Id() As Integer
        Get
            Return intErr
        End Get
        Set(ByVal Value As Integer)
            intErr = Value
        End Set
    End Property

    Public Property Error_Message() As String
        Get
            Return strErr
        End Get
        Set(ByVal Value As String)
            strErr = Value
        End Set
    End Property

    Public Property Project_Id() As String
        Get
            Return strProjectId
        End Get
        Set(ByVal Value As String)
            strProjectId = Value
        End Set
    End Property
    Public Property Project_Name() As String
        Get
            Return strProjectName
        End Get
        Set(ByVal Value As String)
            strProjectName = Value
        End Set
    End Property

    Public Property Project_Short_Name() As String
        Get
            Return strProjectShortName
        End Get
        Set(ByVal Value As String)
            strProjectShortName = Value
        End Set
    End Property

    Public Property Project_Description() As String
        Get
            Return strProjectDescription
        End Get
        Set(ByVal Value As String)
            strProjectDescription = Value
        End Set
    End Property

    Public Property Status_Id() As Integer
        Get
            Return intStatusId
        End Get
        Set(ByVal Value As Integer)
            intStatusId = Value
        End Set
    End Property

    Public Property Status_Name() As String
        Get
            Return strStatusName
        End Get
        Set(ByVal Value As String)
            strStatusName = Value
        End Set
    End Property

    Public Property Start_Date() As String
        Get
            Return dtStartDate
        End Get
        Set(ByVal Value As String)
            dtStartDate = Value
        End Set
    End Property
    Public Property End_Date() As String
        Get
            Return dtEndDate
        End Get
        Set(ByVal Value As String)
            dtEndDate = Value
        End Set
    End Property
    Public Property Comments() As String
        Get
            Return strComments
        End Get
        Set(ByVal Value As String)
            strComments = Value
        End Set
    End Property

    Public Property DS_Data() As SqlDataSource
        Get
            Return dsData
        End Get
        Set(ByVal Value As SqlDataSource)
            dsData = Value
        End Set
    End Property

    Public Property GV_Data() As GridView
        Get
            Return gvData
        End Get
        Set(ByVal Value As GridView)
            gvData = Value
        End Set
    End Property

    Public Property By() As String
        Get
            Return strBy
        End Get
        Set(ByVal Value As String)
            strBy = Value
        End Set
    End Property

    Public Property Created_By() As String
        Get
            Return strCreatedBy
        End Get
        Set(ByVal Value As String)
            strCreatedBy = Value
        End Set
    End Property

    Public Property Modified_By() As String
        Get
            Return strModifiedBy
        End Get
        Set(ByVal Value As String)
            strModifiedBy = Value
        End Set
    End Property

    Public Property Created_Date() As Date
        Get
            Return dtCreatedDate
        End Get
        Set(ByVal Value As Date)
            dtCreatedDate = Value
        End Set
    End Property

    Public Property Modified_Date() As Date
        Get
            Return dtModifiedDate
        End Get
        Set(ByVal Value As Date)
            dtModifiedDate = Value
        End Set
    End Property


    Public Sub selectAllProjects()

        Dim dbCon As New DBAccess

        'Get all the User information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_projects"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub executeSelectProject()

        If Not IsDBNull(strProjectId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get project information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_project", _
                         New SqlParameter("@Project_id", strProjectId))

            If dbRs.Read Then


                If Not IsDBNull(dbRs("Project_name")) Then
                    strProjectName = dbRs("Project_name")
                End If

                If Not IsDBNull(dbRs("Project_short_name")) Then
                    strProjectShortName = dbRs("Project_short_name")
                End If

                If Not IsDBNull(dbRs("Project_description")) Then
                    strProjectDescription = dbRs("Project_description")
                End If

                If Not IsDBNull(dbRs("Start_date")) Then
                    dtStartDate = dbRs("Start_date")
                End If

                If Not IsDBNull(dbRs("End_date")) Then
                    dtEndDate = dbRs("End_date")
                End If

                If Not IsDBNull(dbRs("Status_id")) Then
                    intStatusId = dbRs("Status_id")
                End If

                If Not IsDBNull(dbRs("Status_Name")) Then
                    strStatusName = dbRs("Status_Name")
                End If

                If Not IsDBNull(dbRs("Comments")) Then
                    strComments = dbRs("Comments")
                End If

                If Not IsDBNull(dbRs("Created_by")) Then
                    strCreatedBy = dbRs("Created_by")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                If Not IsDBNull(dbRs("Created_date")) Then
                    dtCreatedDate = dbRs("Created_date")
                End If

                If Not IsDBNull(dbRs("Modified_date")) Then
                    dtModifiedDate = dbRs("Modified_date")
                End If


                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 'Id is Nothing
            strErr = "Project Id is Nothing"

        End If

    End Sub 'executeSelectProject()


    Public Sub executeCreateProject()


        Dim dbCon As New DBAccess
        Dim T_Id As String

        'Create New Project to the database 

        T_Id = dbCon.RunSPReturnId("dbo.sp_create_project_wiz", _
                         New SqlParameter("@Project_name", strProjectName), _
                         New SqlParameter("@Project_short_name", strProjectShortName), _
                         New SqlParameter("@Project_description", strProjectDescription), _
                         New SqlParameter("@Start_date", dtStartDate), _
                         New SqlParameter("@End_date", dtEndDate), _
                         New SqlParameter("@Status_id", intStatusId), _
                         New SqlParameter("@Comments", strComments), _
                         New SqlParameter("@Created_by", strBy))

        If T_Id = "-1" Then

            intErr = -1 'Create New Project Failed
            strErr = "Create New Project Failed"

        Else

            intErr = 0 'New  Project Created Successfully
            strErr = "New  Project Created  Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeCreateProject()


    Public Sub executeUpdateProject()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Save Project Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_project_wiz", _
                         New SqlParameter("@Project_id", strProjectId), _
                         New SqlParameter("@Project_name", strProjectName), _
                         New SqlParameter("@Project_short_name", strProjectShortName), _
                         New SqlParameter("@Project_description", strProjectDescription), _
                         New SqlParameter("@Start_date", dtStartDate), _
                         New SqlParameter("@End_date", dtEndDate), _
                         New SqlParameter("@Status_id", intStatusId), _
                         New SqlParameter("@Comments", strComments), _
                         New SqlParameter("@Modified_by", strBy))

        If T_id = -1 Then

            intErr = -1 'Update Project Failed
            strErr = "Update Project Failed"

        Else

            intErr = 0 'Project Information Saved Successfully
            strErr = "Project Information Saved Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateProject()



    Public Sub executeDeleteProject()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Delete Project Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_delete_project_wiz", _
                         New SqlParameter("@Project_id", strProjectId), _
                         New SqlParameter("@Modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Delete Project Failed
            strErr = "Delete Project Failed"

        Else

            intErr = 0 'Project Information Deleted Successfully
            strErr = "Project Information Deleted Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeleteProject()

End Class
