﻿Public Class view_tracker
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        getTrackerInformation()


    End Sub

    Sub getTrackerInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Tracker As New Tracker
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Tracker.Tracker_Id = T_Id
            T_Tracker.executeSelectTracker()

            If T_Tracker.Error_Id = 0 Then

                txt_tracker_name.Text = T_Tracker.Tracker_Name
                txt_project.Text = T_Tracker.Project_Name
                txt_tracker_type.Text = T_Tracker.Tracker_Type_Description
                txt_status.Text = T_Tracker.Status_Name
                txt_priority.Text = T_Tracker.Priority_Name
                txt_assigned_by.Text = T_Tracker.Assigned_By
                txt_assigned_to.Text = T_Tracker.Assigned_To
                txt_start_date.Text = T_Tracker.Start_Date
                txt_end_date.Text = T_Tracker.End_Date
                txt_comment.Text = T_Tracker.Comment

                T_Tracker.DS_Data = DS_Tracker_Comments_Manager
                T_Tracker.selectTrackerComments()

            Else
                T_Msg = "Error Retrieving Tracker Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Tracker Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Tracker = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

End Class