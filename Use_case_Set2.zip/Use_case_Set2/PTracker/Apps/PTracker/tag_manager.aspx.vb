﻿Public Class tag_manager
    Inherits System.Web.UI.Page

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        setRolePermission()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        getAlltag()

    End Sub

    Private Sub setRolePermission()

        Dim T_Security As New PAL_Security

        T_Security.Role_Id = Session("Role_Id")
        T_Security.Navigate_Url = T_Security.Get_Page(Request)
        T_Security.GV_Data = GV_tag_Manager
        T_Security.setGVUserPermission("tag_id", "_tag.aspx", "id", "tag_id")

        T_Security = Nothing

    End Sub

    Private Sub getAlltag()

        Dim T_tag As New tag

        T_tag.DS_Data = DS_Tag_Manager
        T_tag.selectAllTags()

        T_tag = Nothing

    End Sub
End Class