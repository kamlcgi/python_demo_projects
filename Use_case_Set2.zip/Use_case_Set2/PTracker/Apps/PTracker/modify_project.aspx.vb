﻿Public Class modify_project
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            setLookups()
            getProjectInformation()

        End If

    End Sub

    Protected Sub modify_project(ByVal sender As Object, ByVal e As EventArgs) Handles btn_save_project.Click

        saveProjectInformation()

    End Sub

    Sub getProjectInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Project As New Project
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Project.Project_Id = T_Id
            T_Project.executeSelectProject()

            If T_Project.Error_Id = 0 Then

                txt_project_name.Text = T_Project.Project_Name
                txt_project_short_name.Text = T_Project.Project_Short_Name
                txt_project_description.Text = T_Project.Project_Description
                ddl_status.SelectedValue = T_Project.Status_Id
                txt_start_date.Text = T_Project.Start_Date
                txt_end_date.Text = T_Project.End_Date
                ddl_status.SelectedValue = T_Project.Status_Id
                txt_Comments.Text = T_Project.Comments

            Else

                T_Msg = "Error Retrieving Project Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Project Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Project = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub saveProjectInformation()

        Dim T_Project As New Project
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try
            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Project.Project_Id = T_Id

            T_Project.Project_Name = txt_project_name.Text
            T_Project.Project_Short_Name = txt_project_short_name.Text
            T_Project.Project_Description = txt_project_description.Text
            T_Project.Start_Date = txt_start_date.Text
            T_Project.End_Date = txt_end_date.Text
            T_Project.Status_Id = ddl_status.SelectedValue
            T_Project.Comments = txt_Comments.Text

            T_Project.By = Session("User_Id")
            T_Project.executeUpdateProject()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Updating Project Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Updating Project Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Project = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("project_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If
    End Sub
    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindProjectStatusList(ddl_status)

        T_Lookup = Nothing

    End Sub

End Class