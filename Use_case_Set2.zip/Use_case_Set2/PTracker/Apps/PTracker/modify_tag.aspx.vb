﻿Public Class modify_tag
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            setLookups()
            getTagInformation()

        End If

    End Sub

    Protected Sub save_Tag(ByVal sender As Object, ByVal e As EventArgs) Handles btn_save.Click

        saveTagInformation()

    End Sub

    Protected Sub add_comments(ByVal sender As Object, ByVal e As EventArgs) Handles btn_add.Click

        addTagCommentInformation()

    End Sub

    Protected Sub attach_file(ByVal sender As Object, ByVal e As EventArgs) Handles btn_attach.Click

        uploadTagFileInformation()

    End Sub


    Sub getTagInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Tag As New Tag
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Tag.Tag_Id = T_Id
            T_Tag.executeSelectTag()

            If T_Tag.Error_Id = 0 Then

                txt_tag_name.Text = T_Tag.Tag_Name
                ddl_project.SelectedValue = T_Tag.Project_Id
                ddl_Tag_type.SelectedValue = T_Tag.Tag_Type_Id
                ddl_status.SelectedValue = T_Tag.Status_Id
                ddl_priority.SelectedValue = T_Tag.Priority_Id
                ddl_user_list.SelectedValue = T_Tag.User_id
                ddl_user_list.SelectedValue = T_Tag.Assigned_By
                ddl_assigned_to.SelectedValue = T_Tag.Assigned_To
                txt_start_date.Text = T_Tag.Start_Date
                txt_end_date.Text = T_Tag.End_Date
                txt_comment.Text = T_Tag.Comment

                T_Tag.DS_Data = DS_Tag_Comments_Manager
                T_Tag.selectTagComments()

            Else

                T_Msg = "Error Retrieving Tag Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If


        Catch ex As Exception

            T_Msg = "Error Decoding Tag Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Tag = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If
    End Sub

    Sub saveTagInformation()

        Dim T_Tag As New Tag
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try
            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Tag.Tag_Id = T_Id

            T_Tag.Tag_Name = txt_tag_name.Text
            T_Tag.Project_Id = ddl_project.SelectedValue
            T_Tag.Tag_Type_Id = ddl_tag_type.SelectedValue
            T_Tag.Status_Id = ddl_status.SelectedValue
            T_Tag.Priority_Id = ddl_priority.SelectedValue
            T_Tag.User_id = ddl_user_list.SelectedValue
            T_Tag.Assigned_By = ddl_user_list.SelectedValue
            T_Tag.Assigned_To = ddl_assigned_to.SelectedValue
            T_Tag.Start_Date = txt_start_date.Text
            T_Tag.End_Date = txt_end_date.Text
            T_Tag.Comment = txt_comment.Text


            T_Tag.By = Session("User_Id")
            T_Tag.executeUpdateTag()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Updating Tag Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Updating Tag Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Tag = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("Tag_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub addTagCommentInformation()

        Dim T_Tag As New Tag
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try
            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Tag.Tag_Id = T_Id
            T_Tag.Comment = txt_comments.Text

            T_Tag.By = Session("User_Id")
            T_Tag.executeAddTagComments()

            If T_Security.Error_Id = 0 Then

                T_Tag.DS_Data = DS_Tag_Comments_Manager
                T_Tag.selectTagComments()
                GV_Tag_Comments_Manager.DataBind()
            Else

                T_Msg = "Error Updating Tag Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Updating Tag Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Tag = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub uploadTagFileInformation()

        Dim T_Tag As New Tag
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        ErrorMessage.Text = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Tag.Tag_Id = T_Id
            T_Tag.By = Session("User_Id")

            If upl_tag.HasFile Then

                T_Tag.Tag_File_Name = upl_tag.FileName
                T_Tag.Tag_File = upl_tag.PostedFile
                T_Tag.executeAttachTag()
            Else

                ErrorMessage.Text = "Choose File"

            End If

        Catch ex As Exception

            T_Msg = "Error  Uploading Tag File."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Tag = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then

            Response.Redirect("error_message.aspx?msg=" & T_Msg)

        End If

    End Sub

    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindtagTypeList(ddl_tag_type)
        T_Lookup.bindProjectList(ddl_project)
        T_Lookup.bindStatusList(ddl_status)
        T_Lookup.bindPriorityList(ddl_priority)
        T_Lookup.bindAssignedUserList(ddl_user_list)
        T_Lookup.bindAssignedUserListTo(ddl_assigned_to)

        T_Lookup = Nothing

    End Sub

End Class