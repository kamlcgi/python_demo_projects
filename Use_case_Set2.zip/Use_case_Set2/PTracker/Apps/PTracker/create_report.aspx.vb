﻿Public Class create_report
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then


        End If

    End Sub

    Protected Sub create_report(ByVal sender As Object, ByVal e As EventArgs) Handles btn_create_report.Click

        createReportInformation()

    End Sub

    Sub createReportInformation()

        Dim T_Report As New Report
        Dim T_Security As New PAL_Security
        Dim T_Msg As String = ""

        Try

            T_Report.Report_Name = txt_report_name.Text
            T_Report.Report_Description = txt_report_description.Text
            T_Report.Report_Query = txt_report_query.Text

            T_Report.By = Session("User_Id")
            T_Report.executeCreateReport()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Creating New Report Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Creating New Report Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("report_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub







End Class