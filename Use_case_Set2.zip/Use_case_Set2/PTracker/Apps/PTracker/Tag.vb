

'Component Name: Tag
'Description: Used to Create, Update, View and Delete Tag Information
'Author:  Srinivasan Subbanchattiar 
'Created By: Arpita Das 
'Created Date: 01/02/2012 
'Modified By: Arpita Das 
'Modified Date: 01/02/2012 
'Version: 1.0

Imports System.Web
Imports System.Data
Imports System.Data.SqlClient

Public Class Tag

    Protected intErr As Integer
    Protected strErr As String
    Protected strBy As String

    Protected strTagId As String
    Protected strTagName As String
    Protected strProjectId As String
    Protected strProjectName As String
    Protected intTagTypeId As Integer
    Protected strTagTypeDescription As String
    Protected intStatusId As Integer
    Protected strStatusName As String
    Protected intPriorityId As Integer
    Protected strPriorityName As String
    Protected strUserId As String
    Protected strAssignedBy As String
    Protected strAssignedTo As String

    Protected dtStartDate As String
    Protected dtEndDate As String

    Protected strComment As String



    Protected strTagCommentId As String
    Protected strTagComment As String


    Protected intTagGroupId As Integer
    Protected strTagGroupName As String

    Protected strTagAttachmentId As String
    Protected hpfTagFile As HttpPostedFile
    Protected strTagFileName As String
    Protected strTagFileMime As String


    Protected gvData As GridView
    Protected dsData As SqlDataSource

    'for view purpose only
    Protected strCreatedBy As String
    Protected dtCreatedDate As Date
    Protected strModifiedBy As String
    Protected dtModifiedDate As Date




    Public Sub New()

        Clear()

    End Sub


    Public Sub Clear()

        intErr = Nothing
        strErr = Nothing
        strBy = Nothing

        strTagId = Nothing
        strTagName = Nothing
        strProjectId = Nothing
        strProjectName = Nothing
        intTagTypeId = Nothing
        strTagTypeDescription = Nothing
        intStatusId = Nothing
        strStatusName = Nothing
        intPriorityId = Nothing
        strPriorityName = Nothing

        dtStartDate = Nothing
        dtEndDate = Nothing

        strComment = Nothing

        strUserId = Nothing
        strAssignedBy = Nothing
        strAssignedTo = Nothing

        hpfTagFile = Nothing
        strTagAttachmentId = Nothing

        strTagFileName = Nothing
        strTagFileMime = Nothing


        gvData = Nothing
        dsData = Nothing

        strCreatedBy = Nothing
        dtCreatedDate = Nothing
        strModifiedBy = Nothing
        dtModifiedDate = Nothing



    End Sub

    Public Property Error_Id() As Integer
        Get
            Return intErr
        End Get
        Set(ByVal Value As Integer)
            intErr = Value
        End Set
    End Property

    Public Property Error_Message() As String
        Get
            Return strErr
        End Get
        Set(ByVal Value As String)
            strErr = Value
        End Set
    End Property

    Public Property Tag_Id() As String
        Get
            Return strTagId
        End Get
        Set(ByVal Value As String)
            strTagId = Value
        End Set
    End Property

    Public Property Tag_Name() As String
        Get
            Return strTagName
        End Get
        Set(ByVal Value As String)
            strTagName = Value
        End Set
    End Property

    Public Property Project_Id() As String
        Get
            Return strProjectId
        End Get
        Set(ByVal Value As String)
            strProjectId = Value
        End Set
    End Property

    Public Property Project_Name() As String
        Get
            Return strProjectName
        End Get
        Set(ByVal Value As String)
            strProjectName = Value
        End Set
    End Property


    Public Property Tag_Type_Id() As Integer
        Get
            Return intTagTypeId
        End Get
        Set(ByVal Value As Integer)
            intTagTypeId = Value
        End Set
    End Property

    Public Property Tag_Type_Description() As String
        Get
            Return strTagTypeDescription
        End Get
        Set(ByVal Value As String)
            strTagTypeDescription = Value
        End Set
    End Property

    Public Property Status_Id() As Integer
        Get
            Return intStatusId
        End Get
        Set(ByVal Value As Integer)
            intStatusId = Value
        End Set
    End Property
    Public Property Status_Name() As String
        Get
            Return strStatusName
        End Get
        Set(ByVal Value As String)
            strStatusName = Value
        End Set
    End Property

    Public Property Priority_Id() As Integer
        Get
            Return intPriorityId
        End Get
        Set(ByVal Value As Integer)
            intPriorityId = Value
        End Set
    End Property

    Public Property Priority_Name() As String
        Get
            Return strPriorityName
        End Get
        Set(ByVal Value As String)
            strPriorityName = Value
        End Set
    End Property


    Public Property User_id() As String
        Get
            Return strUserId
        End Get
        Set(ByVal Value As String)
            strUserId = Value
        End Set
    End Property
    Public Property Assigned_By() As String
        Get
            Return strAssignedBy
        End Get
        Set(ByVal Value As String)
            strAssignedBy = Value
        End Set
    End Property
    Public Property Assigned_To() As String
        Get
            Return strAssignedTo
        End Get
        Set(ByVal Value As String)
            strAssignedTo = Value
        End Set
    End Property

    Public Property Start_Date() As String
        Get
            Return dtStartDate
        End Get
        Set(ByVal Value As String)
            dtStartDate = Value
        End Set
    End Property
    Public Property End_Date() As String
        Get
            Return dtEndDate
        End Get
        Set(ByVal Value As String)
            dtEndDate = Value
        End Set
    End Property

    Public Property Comment() As String
        Get
            Return strComment
        End Get
        Set(ByVal Value As String)
            strComment = Value
        End Set
    End Property
    Public Property Tag_Attachment_Id() As String
        Get
            Return strTagAttachmentId
        End Get
        Set(ByVal Value As String)
            strTagAttachmentId = Value
        End Set

    End Property
    Public Property Tag_File_Name() As String
        Get
            Return strTagFileName
        End Get
        Set(ByVal Value As String)
            strTagFileName = Value
        End Set
    End Property

    Public Property Tag_File_Mime() As String
        Get
            Return strTagFileMime
        End Get
        Set(ByVal Value As String)
            strTagFileMime = Value
        End Set
    End Property

    Public Property Tag_File() As HttpPostedFile
        Get
            Return hpfTagFile
        End Get
        Set(ByVal Value As HttpPostedFile)
            hpfTagFile = Value
        End Set
    End Property



    Public Property DS_Data() As SqlDataSource
        Get
            Return dsData
        End Get
        Set(ByVal Value As SqlDataSource)
            dsData = Value
        End Set
    End Property

    Public Property GV_Data() As GridView
        Get
            Return gvData
        End Get
        Set(ByVal Value As GridView)
            gvData = Value
        End Set
    End Property

    Public Property By() As String
        Get
            Return strBy
        End Get
        Set(ByVal Value As String)
            strBy = Value
        End Set
    End Property

    Public Property Created_By() As String
        Get
            Return strCreatedBy
        End Get
        Set(ByVal Value As String)
            strCreatedBy = Value
        End Set
    End Property

    Public Property Modified_By() As String
        Get
            Return strModifiedBy
        End Get
        Set(ByVal Value As String)
            strModifiedBy = Value
        End Set
    End Property

    Public Property Created_Date() As Date
        Get
            Return dtCreatedDate
        End Get
        Set(ByVal Value As Date)
            dtCreatedDate = Value
        End Set
    End Property

    Public Property Modified_Date() As Date
        Get
            Return dtModifiedDate
        End Get
        Set(ByVal Value As Date)
            dtModifiedDate = Value
        End Set
    End Property


    Public Sub selectAllTags()

        Dim dbCon As New DBAccess

        'Get all the Tag information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_tags"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub selectTagComments()

        Dim dbCon As New DBAccess

        'Get all the Tag information from the database

        DS_Data.SelectParameters.Clear()
        DS_Data.SelectCommand = "dbo.sp_get_all_tag_comments"
        DS_Data.SelectParameters.Add("Tag_id", strTagId)
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub executeSelectTag()

        If Not IsDBNull(strTagId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the user information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_Tag", _
                         New SqlParameter("@Tag_id", strTagId))

            If dbRs.Read Then

                If Not IsDBNull(dbRs("Tag_name")) Then
                    strTagName = dbRs("Tag_name")
                End If

                If Not IsDBNull(dbRs("Project_id")) Then
                    strProjectId = dbRs("Project_id")
                End If
                If Not IsDBNull(dbRs("Project_name")) Then
                    strProjectName = dbRs("Project_name")
                End If
                If Not IsDBNull(dbRs("Tag_type_id")) Then
                    intTagTypeId = dbRs("Tag_type_id")
                End If
                If Not IsDBNull(dbRs("Tag_type_description")) Then
                    strTagTypeDescription = dbRs("Tag_type_description")
                End If

                If Not IsDBNull(dbRs("Status_id")) Then
                    intStatusId = dbRs("Status_id")
                End If
                If Not IsDBNull(dbRs("Status_name")) Then
                    strStatusName = dbRs("Status_name")
                End If

                If Not IsDBNull(dbRs("Priority_id")) Then
                    intPriorityId = dbRs("Priority_id")
                End If

                If Not IsDBNull(dbRs("Priority_name")) Then
                    strPriorityName = dbRs("Priority_name")
                End If

                If Not IsDBNull(dbRs("Assigned_user_id")) Then
                    strUserId = dbRs("Assigned_user_id")
                End If
                If Not IsDBNull(dbRs("Assigned_by")) Then
                    strAssignedBy = dbRs("Assigned_by")
                End If
                If Not IsDBNull(dbRs("Assigned_to")) Then
                    strAssignedTo = dbRs("Assigned_to")
                End If

                If Not IsDBNull(dbRs("Created_by")) Then
                    strCreatedBy = dbRs("Created_by")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                If Not IsDBNull(dbRs("Created_date")) Then
                    dtCreatedDate = dbRs("Created_date")
                End If

                If Not IsDBNull(dbRs("Modified_date")) Then
                    dtModifiedDate = dbRs("Modified_date")
                End If

                If Not IsDBNull(dbRs("Start_date")) Then
                    dtStartDate = dbRs("Start_date")
                End If

                If Not IsDBNull(dbRs("End_date")) Then
                    dtEndDate = dbRs("End_date")
                End If
                If Not IsDBNull(dbRs("Comment")) Then
                    strComment = dbRs("Comment")
                End If
                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If
            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else
            intErr = -2 'Id is Nothing
            strErr = "UserId is Nothing"

        End If

    End Sub 'executeSelectTag()

    Public Sub executeCreateTag()

        Dim dbCon As New DBAccess
        Dim T_User_id As String

        'Create New Tag to the database 

        T_User_id = dbCon.RunSPReturnId("dbo.sp_create_Tag_wiz", _
                            New SqlParameter("@Tag_name", strTagName), _
                            New SqlParameter("@Project_id", strProjectId), _
                            New SqlParameter("@Tag_type_id", intTagTypeId),
                            New SqlParameter("@Status_id", intStatusId), _
                            New SqlParameter("@Priority_id", intPriorityId), _
                            New SqlParameter("@Assigned_user_id", strUserId), _
                            New SqlParameter("@Assigned_by", strAssignedBy), _
                            New SqlParameter("@Assigned_to", strAssignedTo), _
                            New SqlParameter("@Start_date", dtStartDate), _
                            New SqlParameter("@End_date", dtEndDate), _
                            New SqlParameter("@Comment", strComment), _
                            New SqlParameter("@created_by", strBy))

        If T_User_id = "-1" Then

            intErr = -1 'Create New Tag Failed
            strErr = "Create New Tag Failed"

        Else

            intErr = 0 'New Tag Created Successfully
            strErr = "New Tag Created Successfully"

        End If

        dbCon = Nothing
    End Sub 'executeCreateTag()

    Public Sub executeUpdateTag()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Save Tag Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_Tag_wiz", _
                            New SqlParameter("@Tag_id", strTagId), _
                            New SqlParameter("@Tag_name", strTagName), _
                            New SqlParameter("@Project_id", strProjectId), _
                            New SqlParameter("@Tag_type_id", intTagTypeId),
                            New SqlParameter("@Status_id", intStatusId), _
                            New SqlParameter("@Priority_id", intPriorityId), _
                            New SqlParameter("@Assigned_user_id", strUserId), _
                            New SqlParameter("@Assigned_by", strAssignedBy), _
                            New SqlParameter("@Assigned_to", strAssignedTo), _
                            New SqlParameter("@Start_date", dtStartDate), _
                            New SqlParameter("@End_date", dtEndDate), _
                             New SqlParameter("@Comment", strComment), _
                            New SqlParameter("@modified_by", strBy))

        If T_id = -1 Then

            intErr = -1 'Update Tag Failed
            strErr = "Update Tag Failed"

        Else

            intErr = 0 'Tag Information Saved Successfully
            strErr = "Tag Information Saved Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateTag()



    Public Sub executeDeleteTag()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Delete Tag Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_delete_Tag_wiz", _
                         New SqlParameter("@Tag_id", strTagId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Delete Tag Failed
            strErr = "Delete Tag Failed"

        Else

            intErr = 0 'Tag Information Deleted Successfully
            strErr = "Tag Information Deleted Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeleteTag()


    Public Sub executeAddTagComments()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Add Tag Comments Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_add_Tag_to_comment", _
                         New SqlParameter("@Tag_id", strTagId), _
                         New SqlParameter("@Tag_comment", strComment), _
                         New SqlParameter("@created_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Add Tag Comments Failed
            strErr = "Add Tag Comments Failed"

        Else

            intErr = 0 'Added Tag Comments Information Successfully
            strErr = "Added Tag Comments Information Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeleteTag()




    Public Sub executeAttachTag()


        Dim dbCon As New DBAccess
        Dim T_id As String

        'Create New Tag to the database 

        Dim imgByte As Byte() = Nothing
        imgByte = New Byte(hpfTagFile.ContentLength - 1) {}

        hpfTagFile.InputStream.Read(imgByte, 0, hpfTagFile.ContentLength)

        Dim sqp_Tag_file As New SqlParameter("@Tag_file", SqlDbType.Image, hpfTagFile.ContentLength)
        sqp_Tag_file.Value = imgByte

        T_id = dbCon.RunSPReturnId("dbo.sp_attach_tag_file_wiz", _
                                        New SqlParameter("@Tag_id", strTagId), _
                                        New SqlParameter("@Tag_file_name", strTagFileName), _
                                        sqp_Tag_file, _
                                        New SqlParameter("@created_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Upload Tag Attachment Failed
            strErr = "Upload Tag Attachment Failed"

        Else

            intErr = 0 'Uploaded Tag Attachment Successfully
            strErr = "Uploaded Tag  Attachment Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeAttachTag()

    Public Sub executeSelectTag(ByVal Response As HttpResponse)

        Dim dbCon As New DBAccess
        Dim dbRs As SqlDataReader
        Dim T_File_Name As String = ""

        'get Tag information from the database 

        Const T_SQL As String = "SELECT Tag_file_name, Tag_file_mime, Tag_File FROM dbo.Tag_Attachment_File WHERE Tag_Attachment_id = @Tag_Attachment_id"

        dbRs = dbCon.RunSQLReturnRS(T_SQL, _
                     New SqlParameter("@Tag_Attachment_id", strTagAttachmentId))

        If dbRs.Read Then

            If Not IsDBNull(dbRs("Tag_file_name")) Then
                T_File_Name = dbRs("Tag_file_name")
            End If

            If Not IsDBNull(dbRs("Tag_file_mime")) Then
                Response.ContentType = dbRs("Tag_file_mime")
            Else

                If T_File_Name.EndsWith(".doc") Or T_File_Name.EndsWith(".docx") Then

                    Response.ContentType = "application/vnd.ms-word"

                ElseIf T_File_Name.EndsWith(".xls") Or T_File_Name.EndsWith(".xlsx") Then

                    Response.ContentType = "application/vnd.ms-excel"

                ElseIf T_File_Name.EndsWith(".pdf") Then

                    Response.ContentType = "Application/pdf"

                ElseIf T_File_Name.EndsWith(".jpeg") Or T_File_Name.EndsWith(".jpg") Then

                    Response.ContentType = "image/jpeg"

                ElseIf T_File_Name.EndsWith(".gif") Then

                    Response.ContentType = "image/gif"

                End If

            End If

            Response.AddHeader("content-disposition", "attachment;filename=" + T_File_Name + """")

            If Not IsDBNull(dbRs("Tag_file")) Then
                Response.BinaryWrite(dbRs("Tag_file"))
            End If

        End If

        dbRs.Close()
        dbRs = Nothing
        dbCon = Nothing

    End Sub 'executeSelectTag()

End Class



