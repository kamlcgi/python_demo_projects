﻿
Imports System.Web
Imports System.Data
Imports System.Data.SqlClient

Public Class PLookup

    Protected intErr As Integer
    Protected strErr As String
    Protected strBy As String

    Public Sub New()

        Clear()

    End Sub


    Public Sub Clear()

        intErr = Nothing
        strErr = Nothing
        strBy = Nothing

    End Sub

    Public Property Error_Id() As Integer
        Get
            Return intErr
        End Get
        Set(ByVal Value As Integer)
            intErr = Value
        End Set
    End Property

    Public Property Error_Message() As String
        Get
            Return strErr
        End Get
        Set(ByVal Value As String)
            strErr = Value
        End Set
    End Property

    Public Property By() As String
        Get
            Return strBy
        End Get
        Set(ByVal Value As String)
            strBy = Value
        End Set
    End Property


    Public Sub bindCountryList(ByVal country_list As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the country information from the database

        country_list.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_country")
        country_list.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindStateList(ByVal state_list As DropDownList, ByVal country_id As Integer)

        Dim dbCon As New DBAccess

        'Get all the state information from the database

        state_list.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_state_by_country", _
                                                         New SqlParameter("@country_id", country_id))
        state_list.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindRoleList(ByVal role_list As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the country information from the database

        role_list.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_roles")
        role_list.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindParentPageList(ByVal page_list As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the Parent Pages information from the database

        page_list.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_parent_pages")

        page_list.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindPageNotInRoleList(ByVal page_list As DropDownList, ByVal role_id As Integer)

        Dim dbCon As New DBAccess

        'Get all the pages information not in role from the database

        page_list.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_pages_not_in_role", _
                                                         New SqlParameter("@role_id", role_id))
        page_list.DataBind()

        dbCon = Nothing

    End Sub


    Public Sub bindUserList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the user information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_users_lkup")

        Plist.DataBind()

        dbCon = Nothing

    End Sub


    Public Sub bindTagTypeList(ByVal Tlist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Tlist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_tag_type_lkup")

        Tlist.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindProjectList(ByVal PRlist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        PRlist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_project_lkup")

        PRlist.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindProjectStatusList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the project status  information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_project_status_lkup")

        Plist.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindStatusList(ByVal Slist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Slist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_status_lkup")

        Slist.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindAssignedUserList(ByVal Alist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Alist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_assigned_user")

        Alist.DataBind()

        dbCon = Nothing

    End Sub
    Public Sub bindAssignedUserListTo(ByVal Atollist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Atollist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_assigned_user_to")

        Atollist.DataBind()

        dbCon = Nothing

    End Sub
    Public Sub bindPriorityList(ByVal Prioritylist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Prioritylist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_priority_lkup")

        Prioritylist.DataBind()

        dbCon = Nothing

    End Sub
  
    Public Sub bindTagGroupList(ByVal Tglist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Tglist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_tag_group_x_tag")

        Tglist.DataBind()

        dbCon = Nothing

    End Sub
    Public Sub bindProductTypeList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_product_type_lkup")

        Plist.DataBind()

        dbCon = Nothing

    End Sub


    

    Public Sub bindFileTypeList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_file_type")

        Plist.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindTransactionTypeList(ByVal Tlist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Tlist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_transaction_type_lkup")

        Tlist.DataBind()

        dbCon = Nothing

    End Sub



End Class
