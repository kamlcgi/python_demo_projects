﻿Public Class modify_tracker
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            setLookups()
            getTrackerInformation()

        End If

    End Sub

    Protected Sub save_Tracker(ByVal sender As Object, ByVal e As EventArgs) Handles btn_save.Click

        saveTrackerInformation()

    End Sub

    Protected Sub add_comments(ByVal sender As Object, ByVal e As EventArgs) Handles btn_add.Click

        addTrackerCommentInformation()

    End Sub

    Sub getTrackerInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Tracker As New Tracker
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Tracker.Tracker_Id = T_Id
            T_Tracker.executeSelectTracker()

            If T_Tracker.Error_Id = 0 Then

                txt_Tracker_name.Text = T_Tracker.Tracker_Name
                ddl_project.SelectedValue = T_Tracker.Project_Id
                ddl_tracker_type.SelectedValue = T_Tracker.Tracker_Type_Id
                ddl_status.SelectedValue = T_Tracker.Status_Id
                ddl_priority.SelectedValue = T_Tracker.Priority_Id
                ddl_user_list.SelectedValue = T_Tracker.User_id
                ddl_user_list.SelectedValue = T_Tracker.Assigned_By
                ddl_assigned_to.SelectedValue = T_Tracker.Assigned_To
                txt_start_date.Text = T_Tracker.Start_Date
                txt_end_date.Text = T_Tracker.End_Date
                txt_comment.Text = T_Tracker.Comment

                T_Tracker.DS_Data = DS_Tracker_Comments_Manager
                T_Tracker.selectTrackerComments()

            Else

                T_Msg = "Error Retrieving Tracker Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If


        Catch ex As Exception

            T_Msg = "Error Decoding Tracker Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Tracker = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If
    End Sub

    Sub saveTrackerInformation()

        Dim T_Tracker As New Tracker
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try
            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Tracker.Tracker_Id = T_Id

            T_Tracker.Tracker_Name = txt_Tracker_name.Text
            T_Tracker.Project_Id = ddl_project.SelectedValue
            T_Tracker.Tracker_Type_Id = ddl_tracker_type.SelectedValue
            T_Tracker.Status_Id = ddl_status.SelectedValue
            T_Tracker.Priority_Id = ddl_priority.SelectedValue
            T_Tracker.User_id = ddl_user_list.SelectedValue
            T_Tracker.Assigned_By = ddl_user_list.SelectedValue
            T_Tracker.Assigned_To = ddl_assigned_to.SelectedValue
            T_Tracker.Start_Date = txt_start_date.Text
            T_Tracker.End_Date = txt_end_date.Text
            T_Tracker.Comment = txt_comment.Text

           
            T_Tracker.By = Session("User_Id")
            T_Tracker.executeUpdateTracker()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Updating Tracker Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Updating Tracker Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Tracker = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("tracker_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Sub addTrackerCommentInformation()

        Dim T_Tracker As New Tracker
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try
            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Tracker.Tracker_Id = T_Id
            T_Tracker.Comment = txt_comments.Text

            T_Tracker.By = Session("User_Id")
            T_Tracker.executeAddTrackerComments()

            If T_Security.Error_Id = 0 Then

                T_Tracker.DS_Data = DS_Tracker_Comments_Manager
                T_Tracker.selectTrackerComments()
                GV_Tracker_Comments_Manager.DataBind()
            Else

                T_Msg = "Error Updating Tracker Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Updating Tracker Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Tracker = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub



    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindTrackerTypeList(ddl_tracker_type)
        T_Lookup.bindProjectList(ddl_project)
        T_Lookup.bindStatusList(ddl_status)
        T_Lookup.bindPriorityList(ddl_priority)
        T_Lookup.bindAssignedUserList(ddl_user_list)
        T_Lookup.bindAssignedUserListTo(ddl_assigned_to)

        T_Lookup = Nothing

    End Sub

End Class