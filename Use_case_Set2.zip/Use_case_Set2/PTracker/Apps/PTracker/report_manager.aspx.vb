﻿Public Class report_manager
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        getAllReports()
    End Sub

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        setRolePermission()

    End Sub

    Private Sub setRolePermission()

        Dim T_Security As New PAL_Security


        T_Security.Role_Id = Session("Role_id")
        T_Security.Navigate_Url = T_Security.Get_Page(Request)
        T_Security.GV_Data = GV_Report_Manager
        T_Security.setGVUserPermission("Report_id", "_report.aspx", "id", "Report_id")

        T_Security = Nothing

    End Sub

    Private Sub getAllReports()

        Dim T_report As New Report

        T_report.DS_Data = DS_Report_Manager
        T_report.selectAllReports()
        T_report = Nothing

    End Sub

End Class