﻿Public Class view_project
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        getProjectInformation()

    End Sub

    Sub getProjectInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Project As New Project
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Project.Project_Id = T_Id
            T_Project.executeSelectProject()

            If T_Project.Error_Id = 0 Then

                txt_project_name.Text = T_Project.Project_Name
                txt_project_short_name.Text = T_Project.Project_Short_Name
                txt_project_description.Text = T_Project.Project_Description
                txt_start_date.Text = T_Project.Start_Date
                txt_end_date.Text = T_Project.End_Date
                txt_status_id.Text = T_Project.Status_Id
                txt_status_name.Text = T_Project.Status_Name
                txt_comments.Text = T_Project.Comments

            Else

                T_Msg = "Error Retrieving Project Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Project Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Project = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub
End Class