

'Component Name: Tracker
'Description: Used to Create, Update, View and Delete Tracker Information
'Author:  Srinivasan Subbanchattiar 
'Created By: Arpita Das 
'Created Date: 01/02/2012 
'Modified By: Arpita Das 
'Modified Date: 01/02/2012 
'Version: 1.0

Imports System.Web
Imports System.Data
Imports System.Data.SqlClient

Public Class Tracker

    Protected intErr As Integer
    Protected strErr As String
    Protected strBy As String

    Protected strTrackerId As String
    Protected strTrackerName As String
    Protected strProjectId As String
    Protected intTrackerTypeId As Integer
    Protected intStatusId As Integer
    Protected intPriorityId As Integer
    Protected dtTrackerDueDate As Date
    Protected strAssignedUserId As String


    Protected strTrackerCommentId As String
    Protected strTrackerComment As String


    Protected intTrackerGroupId As Integer
    Protected strTrackerGroupName As String
   
    Protected gvData As GridView
    Protected dsData As SqlDataSource

    'for view purpose only
    Protected strCreatedBy As String
    Protected dtCreatedDate As Date
    Protected strModifiedBy As String
    Protected dtModifiedDate As Date



    Public Sub New()

        Clear()

    End Sub


    Public Sub Clear()

        intErr = Nothing
        strErr = Nothing
        strBy = Nothing

        strTrackerId = Nothing
        strTrackerName = Nothing
        strProjectId = Nothing
        intTrackerTypeId = Nothing
        intStatusId = Nothing
        intPriorityId = Nothing
        dtTrackerDueDate = Nothing
        strAssignedUserId = Nothing


        strTrackerCommentId = Nothing
        strTrackerComment = Nothing


        intTrackerGroupId = Nothing
        strTrackerGroupName = Nothing


        gvData = Nothing
        dsData = Nothing

        strCreatedBy = Nothing
        dtCreatedDate = Nothing
        strModifiedBy = Nothing
        dtModifiedDate = Nothing


    End Sub

    Public Property Error_Id() As Integer
        Get
            Return intErr
        End Get
        Set(ByVal Value As Integer)
            intErr = Value
        End Set
    End Property

    Public Property Error_Message() As String
        Get
            Return strErr
        End Get
        Set(ByVal Value As String)
            strErr = Value
        End Set
    End Property

    Public Property Tracker_Id() As String
        Get
            Return strTrackerId
        End Get
        Set(ByVal Value As String)
            strTrackerId = Value
        End Set
    End Property

    Public Property Tracker_Name() As String
        Get
            Return strTrackerName
        End Get
        Set(ByVal Value As String)
            strTrackerName = Value
        End Set
    End Property

    Public Property Project_Id() As String
        Get
            Return strProjectId
        End Get
        Set(ByVal Value As String)
            strProjectId = Value
        End Set
    End Property


    Public Property Tracker_Type_Id() As Integer
        Get
            Return intTrackerTypeId
        End Get
        Set(ByVal Value As Integer)
            intTrackerTypeId = Value
        End Set
    End Property

    Public Property Status_Id() As Integer
        Get
            Return intStatusId
        End Get
        Set(ByVal Value As Integer)
            intStatusId = Value
        End Set
    End Property

    Public Property Priority_Id() As Integer
        Get
            Return intPriorityId
        End Get
        Set(ByVal Value As Integer)
            intPriorityId = Value
        End Set
    End Property

    Public Property Tracker_Due_Date() As Date
        Get
            Return dtTrackerDueDate
        End Get
        Set(ByVal Value As Date)
            dtTrackerDueDate = Value
        End Set
    End Property

    Public Property Assigned_User_Id() As String
        Get
            Return strAssignedUserId
        End Get
        Set(ByVal Value As String)
            strAssignedUserId = Value
        End Set
    End Property

    Public Property Tracker_Comment_Id() As String
        Get
            Return strTrackerCommentId
        End Get
        Set(ByVal Value As String)
            strTrackerCommentId = Value
        End Set
    End Property

    Public Property Tracker_Comment() As String
        Get
            Return strTrackerComment
        End Get
        Set(ByVal Value As String)
            strTrackerComment = Value
        End Set
    End Property

    Public Property Tracker_Group_Id() As Integer
        Get
            Return intTrackerGroupId
        End Get
        Set(ByVal Value As Integer)
            intTrackerGroupId = Value
        End Set
    End Property

    Public Property Tracker_Group_Name() As String
        Get
            Return strTrackerGroupName
        End Get
        Set(ByVal Value As String)
            strTrackerGroupName = Value
        End Set
    End Property


    Public Property DS_Data() As SqlDataSource
        Get
            Return dsData
        End Get
        Set(ByVal Value As SqlDataSource)
            dsData = Value
        End Set
    End Property

    Public Property GV_Data() As GridView
        Get
            Return gvData
        End Get
        Set(ByVal Value As GridView)
            gvData = Value
        End Set
    End Property

    Public Property By() As String
        Get
            Return strBy
        End Get
        Set(ByVal Value As String)
            strBy = Value
        End Set
    End Property

    Public Property Created_By() As String
        Get
            Return strCreatedBy
        End Get
        Set(ByVal Value As String)
            strCreatedBy = Value
        End Set
    End Property

    Public Property Modified_By() As String
        Get
            Return strModifiedBy
        End Get
        Set(ByVal Value As String)
            strModifiedBy = Value
        End Set
    End Property

    Public Property Created_Date() As Date
        Get
            Return dtCreatedDate
        End Get
        Set(ByVal Value As Date)
            dtCreatedDate = Value
        End Set
    End Property

    Public Property Modified_Date() As Date
        Get
            Return dtModifiedDate
        End Get
        Set(ByVal Value As Date)
            dtModifiedDate = Value
        End Set
    End Property

    Public Sub selectAllTrackers()

        Dim dbCon As New DBAccess

        'Get all the User information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_trackers"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub


    Public Sub executeSelectTracker()

        If Not IsDBNull(strTrackerId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the user information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_tracker", _
                         New SqlParameter("@Tracker_Id", strTrackerId))

            If dbRs.Read Then


                If Not IsDBNull(dbRs("Tracker_Name")) Then
                    strTrackerName = dbRs("Tracker_Name")
                End If

                If Not IsDBNull(dbRs("Project_Id")) Then
                    strProjectId = dbRs("Project_Id")
                End If

                If Not IsDBNull(dbRs("Tracker_Type_Id")) Then
                    intTrackerTypeId = dbRs("Tracker_Type_Id")
                End If

                If Not IsDBNull(dbRs("Status_Id")) Then
                    intStatusId = dbRs("Status_Id")
                End If

                If Not IsDBNull(dbRs("Priority_Id ")) Then
                    intPriorityId = dbRs("Priority_Id")
                End If

                If Not IsDBNull(dbRs("Tracker_Due_Date")) Then
                    dtTrackerDueDate = dbRs("Tracker_Due_Date")
                End If

                If Not IsDBNull(dbRs("Assigned_User_Id")) Then
                    strAssignedUserId = dbRs("Assigned_User_Id")
                End If

                If Not IsDBNull(dbRs("Tracker_Comment_Id")) Then
                    strTrackerCommentId = dbRs("Tracker_Comment_Id")
                End If

                If Not IsDBNull(dbRs("Tracker_Comment")) Then
                    strTrackerComment = dbRs("Tracker_Comment")
                End If
                If Not IsDBNull(dbRs("Tracker_Group_Id")) Then
                    intTrackerGroupId = dbRs("Tracker_Group_Id")
                End If
                If Not IsDBNull(dbRs("Tracker_Group_Name")) Then
                    strTrackerGroupName = dbRs("Tracker_Group_Name")
                End If

                If Not IsDBNull(dbRs("Created_by")) Then
                    strCreatedBy = dbRs("Created_by")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                If Not IsDBNull(dbRs("Created_date")) Then
                    dtCreatedDate = dbRs("Created_date")
                End If

                If Not IsDBNull(dbRs("Modified_date")) Then
                    dtModifiedDate = dbRs("Modified_date")
                End If

                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 'Id is Nothing
            strErr = "UserId is Nothing"

        End If

    End Sub 'executeSelectTracker()


    Public Sub executeCreateTracker()


        Dim dbCon As New DBAccess
        Dim T_User_id As String

        'Create New Tracker to the database 

        T_User_id = dbCon.RunSPReturnId("dbo.sp_create_tracker_wiz", _
                         New SqlParameter("@Tracker_name", strTrackerName), _
                         New SqlParameter("@Project_id", strProjectId), _
                         New SqlParameter("@Tracker_type_id", intTrackerTypeId), _
                         New SqlParameter("@Status_id", intStatusId), _
                         New SqlParameter("@Priority_id", intPriorityId), _
                         New SqlParameter("@Tracker_due_date", dtTrackerDueDate), _
                         New SqlParameter("@Assigned_user_id", strAssignedUserId), _
                         New SqlParameter("@Tracker_comment_id", strTrackerCommentId), _
                         New SqlParameter("@Tracker_comment", strTrackerComment), _
                         New SqlParameter("@Tracker_group_id", intTrackerGroupId), _
                         New SqlParameter("@Tracker_group_name", strTrackerGroupName), _
                         New SqlParameter("@created_by", strBy))

        If T_User_id = "-1" Then

            intErr = -1 'Create New Tracker Failed
            strErr = "Create New Tracker Failed"

        Else

            intErr = 0 'New Tracker Created Successfully
            strErr = "New Tracker Created Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeCreateTracker()


    Public Sub executeUpdateTracker()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Save Tracker Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_tracker_wiz", _
                         New SqlParameter("@Tracker_id", strTrackerId), _
                          New SqlParameter("@Tracker_name", strTrackerName), _
                         New SqlParameter("@Project_id", strProjectId), _
                         New SqlParameter("@Tracker_type_id", intTrackerTypeId), _
                         New SqlParameter("@Status_id", intStatusId), _
                         New SqlParameter("@Priority_id", intPriorityId), _
                         New SqlParameter("@Tracker_due_date", dtTrackerDueDate), _
                         New SqlParameter("@Assigned_user_id", strAssignedUserId), _
                         New SqlParameter("@Tracker_comment_id", strTrackerCommentId), _
                         New SqlParameter("@Tracker_comment", strTrackerComment), _
                         New SqlParameter("@Tracker_group_id", intTrackerGroupId), _
                         New SqlParameter("@Tracker_group_name", strTrackerGroupName), _
                         New SqlParameter("@created_by", strBy))

        If T_id = -1 Then

            intErr = -1 'Update Tracker Failed
            strErr = "Update Tracker Failed"

        Else

            intErr = 0 'Tracker Information Saved Successfully
            strErr = "Tracker Information Saved Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateTracker()



    Public Sub executeDeleteTracker()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Delete Tracker Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_delete_tracker_wiz", _
                         New SqlParameter("@Tracker_id", strTrackerId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Delete Tracker Failed
            strErr = "Delete Tracker Failed"

        Else

            intErr = 0 'Tracker Information Deleted Successfully
            strErr = "Tracker Information Deleted Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeleteTracker()
End Class



