 /****** Database Name: PTracker_db_10  ******/
/****** Author:  Sreenivasan Subbanchattiar  ******/
/****** Script Created By: Sreenivasan Subbanchattiar ******/
/****** Script Created date: 12/29/2011  ******/
/****** Script Modified By: Rolina  ******/
/****** Script Modified date: 12/29/2011  ******/
/****** Script Version: 1.0  ******/

 
/****** Database:  PTracker_db_10  ******/
USE PTracker_db_10
GO

/****** Object:Stored PROCEDURE   dbo.sp_get_all_tips  Script date: 12/29/2011 	  ******/
IF exists (SELECT * FROM dbo.sysobjects WHERE id= object_id(N'sp_get_all_tips ')and objectproperty(id,N'isPROCEDURE')=1)
	DROP PROCEDURE dbo.sp_get_all_tips
GO

CREATE PROCEDURE dbo.sp_get_all_tips	
AS 
BEGIN 

	SELECT * FROM dbo.view_all_tips
    
END
GO 

/****** Object:Stored PROCEDURE   dbo.sp_get_tip   Script date: 12/29/2011 	  ******/
IF exists (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'dbo.sp_get_tip') and OBJECTPROPERTY(id, N'IsPROCEDURE') = 1)
DROP PROCEDURE  dbo.sp_get_tip
GO

CREATE PROCEDURE  dbo.sp_get_tip
        @Tip_id AS VARCHAR(10)
AS
BEGIN
  
  SELECT * FROM  dbo.view_all_tips  WHERE Tip_id = @Tip_id 
  
 END
GO 

/******object: Table dbo.sp_insert_tips  Script date:12/29/2011 ******/

IF exists (SELECT * FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_create_tip_wiz')
and OBJECTPROPERTY(id,N'IsPROCEDURE')=1)
DROP PROCEDURE dbo.sp_create_tip_wiz
GO

CREATE PROCEDURE dbo.sp_create_tip_wiz
	@Tip_name VARCHAR(75),
	@Tip_description VARCHAR(500),
	@File_type_id tinyint ,
	@File_location VARCHAR(50),
	@Modified_by VARCHAR(10),
	@Modified_date dateTIME,	
	@Post char(1),
	@retval VARCHAR(20) output

AS
BEGIN
DECLARE @Tip_id VARCHAR(10)

exec dbo.sp_new_id @Tip_id OUTPUT

BEGIN TRAN


INSERT INTO dbo.Tips(
     Tip_id,
     Tip_name,
     Tip_description,
     File_type_id,
     File_location,
     Modified_by,
     Modified_date,
     Post
     
)VALUES(
    @Tip_id,
    @Tip_name,
    @Tip_description,
    @File_type_id,
    @File_location,
    @Modified_by,@Modified_date,
    @Post
)
if @@ERROR<>0
BEGIN
     ROLLBACK TRAN
     SET @retval='-1'
     RETURN
  END
     COMMIT TRAN
     SET @retval=@Tip_id
     RETURN
END
GO

/******object: Table dbo.sp_update_tip  Script date: 12/29/2011******/
IF exists (SELECT * FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_update_tip_wiz')
and OBJECTPROPERTY(id,N'IsPROCEDURE')=1)
DROP PROCEDURE dbo.sp_update_tip_wiz
GO

CREATE PROCEDURE dbo.sp_update_tip_wiz(
	@Tip_id VARCHAR(10) ,
	@Tip_name VARCHAR(75),
	@Tip_description VARCHAR(500),
	@File_type_id tinyint ,
	@File_location VARCHAR(50),
	@Modified_by VARCHAR(10),
	@Modified_date dateTIME,	
	@Post char(1),
	@retval VARCHAR(20) output
)
AS
BEGIN
BEGIN TRAN


UPdate dbo.Tips SET
	Tip_id=@Tip_id, 
	Tip_name =@Tip_name ,
	Tip_description =@Tip_description ,
	File_type_id=@File_type_id ,
	File_location=@File_location,
	Modified_by=@Modified_by ,
	Modified_date =@Modified_date ,
	Post=@Post
	
	
WHERE Tip_id=@Tip_id

IF @@ERROR <>0
	BEGIN
		ROLLBACK TRAN
		SET @retval='-1'
		RETURN
	END
	
       COMMIT TRAN
       SET @retval = 0
       RETURN

END
GO


/******object: Table dbo.sp_delete_tip_wiz  Script date: 12/29/2011 ******/
IF exists (SELECT * FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_delete_tip_wiz')
and OBJECTPROPERTY(id,N'IsPROCEDURE')=1)
DROP PROCEDURE dbo.sp_delete_tip_wiz
GO

CREATE PROCEDURE dbo.sp_delete_tip_wiz(
@Tip_id VARCHAR(10),
@retval VARCHAR(20) output)


AS
BEGIN

BEGIN TRAN

DELETE dbo.Tips
WHERE Tip_id=@Tip_id
IF @@ERROR <>0

BEGIN

     ROLLBACK TRAN
     SET @retval='-1'
     RETURN
END
     COMMIT TRAN
     SET @retval = 0
     RETURN


END
GO