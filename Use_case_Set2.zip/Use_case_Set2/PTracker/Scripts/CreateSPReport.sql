 /****** Database Name: PTracker_db_10  ******/
/****** Author:  Sreenivasan Subbanchattiar  ******/
/****** Script Created By: Sreenivasan Subbanchattiar ******/
/****** Script Created date: 12/29/2011  ******/
/****** Script Modified By: Rolina  ******/
/****** Script Modified date: 12/29/2011  ******/
/****** Script Version: 1.0  ******/

 
/****** Database:  PTracker_db_10  ******/
USE PTracker_db_10
GO
 
 /***Object=Table  dbo.sp_get_all_reports Script date:12/29/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_all_reports') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_all_reports	
GO

CREATE PROCEDURE dbo.sp_get_all_reports
AS
 BEGIN
	 SELECT * FROM dbo.view_all_reports
 END
GO 

/***Object=Table  dbo.sp_get_report Script date:12/29/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_report') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_report
GO

CREATE PROCEDURE dbo.sp_get_report
				 @Report_id	Varchar(20)
AS
BEGIN
	SELECT * FROM dbo.view_all_reports WHERE Report_id=@Report_id
END
GO

/***Object=Table  dbo.sp_run_reports Script date:12/29/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_run_reports') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_run_reports
GO

CREATE PROCEDURE dbo.sp_run_reports
				 @Report_id	Varchar(20)
AS
BEGIN

DECLARE @T_Query Varchar(4000)
   
	SELECT @T_Query=Report_query  FROM dbo.view_all_reports WHERE Report_id=@Report_id
	
	exec(@T_Query)
	
END
GO

/***Object=Table dbo.sp_create_report_wiz Script date:12/29/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_create_report_wiz') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_create_report_wiz
GO

CREATE PROCEDURE dbo.sp_create_report_wiz(  
    @Report_name	VARCHAR(100),
    @Report_query	VARCHAR(8000),
    @Report_description	VARCHAR(255),
    @Created_by	VARCHAR(20),
    @retval VARCHAR(20) OUTPUT
) AS
BEGIN

DECLARE @Report_id VARCHAR(20)

exec dbo.sp_new_id @Report_id OUTPUT

BEGIN TRAN
 
 INSERT INTO dbo.Reports(
	 Report_id,
     Report_name,
     Report_query,
     Report_description,
     Created_by,
     Created_date,
     Modified_by,
     Modified_date
    )VALUES(
     @Report_id,
     @Report_name,
     @Report_query,
     @Report_description,
     @Created_by,
     GETDATE(),
     @Created_by,
     GETDATE()
    )
 
 IF @@ERROR <> 0
 BEGIN
	 ROLLBACK TRAN
	 SET @retval='-1'
	 RETURN
 END
 
	 COMMIT TRAN
	 SET @retval=0
	 RETURN
	 
 END 
 GO
 
 /***Object=Table dbo.sp_update_report_wiz Script date:12/29/2011***/
 IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_update_report_wiz') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_update_report_wiz
 GO
 
 CREATE PROCEDURE dbo.sp_update_report_wiz(
    @Report_id	Varchar(20),
    @Report_name	VARCHAR(100),
    @Report_query	VARCHAR(8000),
    @Report_description	VARCHAR(255),
    @Modified_by	VARCHAR(20),
    @retval VARCHAR(20) OUTPUT
) AS  
 BEGIN
 
 BEGIN TRAN
 
 Update dbo.Reports SET     
     Report_id=@Report_id,
     Report_name=@Report_name,
     Report_query=@Report_query,
     Report_description=@Report_description,
     Modified_by=@Modified_by,
	 Modified_date=GETdate()	
WHERE   Report_id=@Report_id
 
 IF @@ERROR <>0
  BEGIN
     ROLLBACK TRAN
     SET @retval='-1'
     RETURN
  END
  
      COMMIT TRAN
      SET @retval=0 
      RETURN
 
 END
 GO
 /***Object=Table dbo.sp_delete_report_wiz Script date:12/29/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_delete_report_wiz') and  OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_delete_report_wiz
GO

CREATE PROCEDURE dbo.sp_delete_report_wiz(
    @Report_id Varchar(20),
    @Modified_by	VARCHAR(20),
	@retval INT OUTPUT
) AS 
BEGIN

BEGIN TRAN 
 
	DELETE FROM dbo.Reports WHERE Report_id=@Report_id
    
IF @@ERROR <>0
 BEGIN
	ROLLBACK TRAN
	SET @retval='-1'
	RETURN
 END
 
    COMMIT TRAN
    SET @retval=0
    RETURN

END 
GO
/***Object=Table  dbo.sp_get_all_report_x_pal_users Script date:12/29/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_all_report_x_pal_users') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_all_report_x_pal_users	
GO

CREATE PROCEDURE dbo.sp_get_all_report_x_pal_users
AS
 BEGIN
	 SELECT * FROM dbo.view_all_reports_by_user
 END
GO 
/***Object=Table  dbo.sp_get_report_x_pal_user Script date:12/29/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_report_x_pal_user') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_report_x_pal_user
GO

CREATE PROCEDURE dbo.sp_get_report_x_pal_user
				 @Report_id	Varchar(20)
AS
BEGIN

	SELECT * FROM dbo.view_all_reports_by_user WHERE @Report_id=@Report_id

END
GO

/***Object=Table dbo.sp_add_user_to_report Script date:12/29/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_add_user_to_report') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_add_user_to_report
GO

CREATE PROCEDURE dbo.sp_add_user_to_report(  
	@User_id	Varchar(20),
    @retval VARCHAR(20) OUTPUT
) AS
BEGIN

DECLARE @Report_id Varchar(20)

exec dbo.sp_new_id @Report_id OUTPUT

BEGIN TRAN
 
 INSERT INTO dbo.Report_X_PAL_Users(
	 Report_id,
     User_id
     
  )VALUES(
	  @Report_id,
      @User_id
      
  )
 
 IF @@ERROR <> 0
 BEGIN
	 ROLLBACK TRAN
	 SET @retval='-1'
	 RETURN
 END
 
	 COMMIT TRAN
	 SET @retval=0
	 RETURN
	 
 END 
 GO

 /***Object=Table dbo.sp_remove_user_from_report Script date:12/29/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_remove_user_from_report') and  OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_remove_user_from_report
GO

CREATE PROCEDURE dbo.sp_remove_user_from_report(
    @Report_id Varchar(20),
	@retval INT OUTPUT
) AS 
BEGIN

BEGIN TRAN 
 
	DELETE FROM dbo.Report_X_PAL_Users WHERE Report_id=@Report_id
    
IF @@ERROR <>0
 BEGIN
	 ROLLBACK TRAN
	 SET @retval='-1'
	 RETURN
 END
 
     COMMIT TRAN
     SET @retval=0
     RETURN

END 
GO