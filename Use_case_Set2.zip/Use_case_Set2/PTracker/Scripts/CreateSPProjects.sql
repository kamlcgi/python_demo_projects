/****** Database Name: PTracker_db_10  ******/
/****** Author:  Sreenivasan Subbanchattiar  ******/
/****** Script Created By: Sreenivasan Subbanchattiar ******/
/****** Script Created date: 12/26/2011  ******/
/****** Script Modified By: Rolina  ******/
/****** Script Modified date: 12/26/2011  ******/
/****** Script Version: 1.0  ******/



/****** Database:  PTracker_db_10  ******/
USE PTracker_db_10
GO

 /***Object=Table  dbo.sp_get_all_projects Script date:12/26/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_all_projects') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_all_projects	

GO

CREATE PROCEDURE dbo.sp_get_all_projects
AS
 BEGIN
	 SELECT * FROM dbo.view_all_projects
 END
GO 

/***Object=Table  dbo.sp_get_project Script date:12/26/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_project') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_project
GO

CREATE PROCEDURE dbo.sp_get_project
				 @Project_id	Varchar(20)
AS
BEGIN
	SELECT * FROM dbo.view_all_projects WHERE Project_id=@Project_id
END
GO


/***Object Stored Procedure Name: dbo.sp_create_project_wiz Script date:12/26/2011***/
IF exists(SELECT * FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_create_project_wiz') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_create_project_wiz
GO

CREATE PROCEDURE dbo.sp_create_project_wiz(    
	@Project_name	VARCHAR(100),
    @Project_short_name	VARCHAR(100),
    @Project_description	VARCHAR(255),    
    @Start_date VARCHAR(10),
    @End_date  VARCHAR(10),
    @Status_id	INTEGER,
    @Comments VARCHAR(255),
    @Created_by VARCHAR(20),
    @retval VARCHAR(20) OUTPUT
) AS
BEGIN

DECLARE @Project_id VARCHAR(20)
DECLARE @dt_start_date Date
DECLARE @dt_end_date Date

if @Start_date =''
	SET @dt_start_date=null
else
    SET @dt_start_date = @Start_date

if @end_date =''
	SET @dt_end_date=null
else
    SET @dt_end_date = @End_date 

EXEC dbo.sp_new_id @Project_id OUTPUT

BEGIN TRAN
 
 INSERT INTO dbo.Projects(
	 Project_id,
     Project_name,
     Project_short_name,
     Project_description,     
     Start_date,
     End_date,
     Status_id,
     Comments,
     Created_by,
     Created_date,
     Modified_by,
     Modified_date   
  )VALUES(
	  @Project_id,
      @Project_name,
      @Project_short_name,
      @Project_description,      
      @dt_start_date,
      @dt_end_date,
      @Status_id,
      @Comments,
      @Created_by,
	  GETDATE(),
	  @Created_by,
	  GETDATE() 
	  
  )
 
	IF @@ERROR <> 0
	 BEGIN
		 ROLLBACK TRAN
		 SET @retval='-1'
		 RETURN
	 END
 
	 COMMIT TRAN
	 SET @retval=@Project_id
	 RETURN
	 
 END 
 GO
 
 /***Object=Table dbo.sp_update_project_wiz Script date:12/26/2011***/
 IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_update_project_wiz') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_update_project_wiz
 GO
 
 CREATE PROCEDURE dbo.sp_update_project_wiz(
    @Project_id	Varchar(20),
    @Project_name	VARCHAR(100),
    @Project_short_name	VARCHAR(100),
    @Project_description	VARCHAR(255),    
    @Start_date VARCHAR(10),
    @End_date  VARCHAR(10),
    @Status_id	INTEGER,
    @Comments VARCHAR(255),
    @Modified_by	VARCHAR(20),
    @retval VARCHAR(20) OUTPUT
) AS  
 BEGIN
 
DECLARE @dt_start_date Date
DECLARE @dt_end_date Date

if @Start_date =''
	SET @dt_start_date=null
else
    SET @dt_start_date = @Start_date

if @end_date =''
	SET @dt_end_date=null
else
    SET @dt_end_date = @End_date 

 BEGIN TRAN
 
	UPDATE	dbo.Projects SET     
		 Project_name = @Project_name,
		 Project_short_name = @Project_short_name,
		 Project_description = @Project_description,		 
		 Start_date = @dt_start_date,
		 End_date = @dt_end_date,
		 Status_id=@Status_id,
		 Comments=@Comments,
		 Modified_by = @Modified_by,
		 Modified_date = GETDATE()	 	
	WHERE Project_id = @Project_id
 
 IF @@ERROR <>0
  BEGIN
    ROLLBACK TRAN
    SET @retval='-1'
    RETURN
  END
  
    COMMIT TRAN
    SET @retval=0 
    RETURN
 
 END
 GO
 
 
 /***Object=Table dbo.sp_delete_project_wiz Script date:12/26/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_delete_project_wiz') and  OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_delete_project_wiz
GO

CREATE PROCEDURE dbo.sp_delete_project_wiz(
    @Project_id Varchar(20),
    @Modified_by	VARCHAR(20),
    @retval INT OUTPUT
) AS 
BEGIN

BEGIN TRAN 
 
	DELETE FROM dbo.Projects WHERE Project_id=@Project_id
    
IF @@ERROR <>0
 BEGIN
	ROLLBACK TRAN
	SET @retval='-1'
	RETURN
 END
 
    COMMIT TRAN
    SET @retval=0
    RETURN

END 
GO


/***Object=Table  dbo.sp_get_all_project_x_pal_users Script date:12/26/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_all_project_x_pal_users') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_all_project_x_pal_users	
GO

CREATE PROCEDURE dbo.sp_get_all_project_x_pal_users
AS
 BEGIN
	 SELECT * FROM dbo.view_all_projects_by_user
 END
GO 


/***Object=Table  dbo.sp_get_project_x_pal_user Script date:12/26/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_project_x_pal_user') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_project_x_pal_user
GO

CREATE PROCEDURE dbo.sp_get_project_x_pal_user
				 @Project_id	Varchar(20)
AS
BEGIN
	SELECT * FROM dbo.view_all_projects_by_user WHERE Project_id=@Project_id
END
GO

/***Object=Table dbo.sp_add_user_to_project Script date:12/26/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_add_user_to_project') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_add_user_to_project
GO

CREATE PROCEDURE dbo.sp_add_user_to_project(    
	@User_id	Varchar(20),
    @retval VARCHAR(20) OUTPUT
) AS
BEGIN

DECLARE @Project_id Varchar(20)

EXEC dbo.sp_new_id @Project_id OUTPUT

BEGIN TRAN
 
 INSERT INTO dbo.Project_X_PAL_Users(
	 Project_id,
     User_id
     
  )VALUES(
	  @Project_id,
      @User_id
      
  )
 
 IF @@ERROR <> 0
 BEGIN
	 ROLLBACK TRAN
	 SET @retval='-1'
	 RETURN
 END
 
	 COMMIT TRAN
	 SET @retval=0
	 RETURN
	 
 END 
 GO
 
 /***Object=Table dbo.sp_remove_user_from_project Script date:12/26/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_remove_user_from_project') and  OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_remove_user_from_project
GO

CREATE PROCEDURE dbo.sp_remove_user_from_project(
    @Project_id Varchar(20),
	@retval INT OUTPUT
) AS 
BEGIN

BEGIN TRAN 
 
	DELETE FROM dbo.Project_X_PAL_Users WHERE Project_id=@Project_id
    
IF @@ERROR <>0
 BEGIN
	ROLLBACK TRAN
	SET @retval='-1'
	RETURN
 END
 
    COMMIT TRAN
    SET @retval=0
    RETURN

END 
GO