
/****** Description: All Views Create and DROP Scripts For PTag_db_xx  ******/
/****** Author:  Sreenivasan Subbanchattiar  ******/
/****** Script Created By: Sreenivasan Subbanchattiar ******/
/****** Script Created Date: 12/29/2011  ******/
/****** Script Modified Date: 12/29/2011  ******/
/****** Script Version: 1.0  ******/

/****** Object:  View dbo.view_all_projects    Script Date: 12/29/2011  ******/
IF exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_projects') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW dbo.view_all_projects
GO

CREATE VIEW dbo.view_all_projects
AS
SELECT	dbo.Projects.Project_id, dbo.Projects.Project_name, dbo.Projects.Project_short_name, dbo.Projects.Project_description,
        dbo.Projects.Start_date, dbo.Projects.End_date,dbo.Projects.Status_id,dbo.Status_LKUP.Status_name, dbo.view_created_by.Created_by,
        dbo.Projects.Created_date, dbo.view_Modified_by.Modified_by,dbo.Projects.Modified_date 
  
FROM    dbo.Projects 
		LEFT OUTER JOIN dbo.view_Modified_by ON dbo.Projects.Modified_by = dbo.view_Modified_by.User_id 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.Projects.Created_by = dbo.view_created_by.User_id
		LEFT OUTER JOIN dbo.Status_LKUP ON dbo.Projects.Status_id = dbo.Status_LKUP.Status_id
			
GO	

/****** Object:  View dbo.view_all_projects_by_user    Script Date: 12/29/2011  ******/
IF exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_projects_by_user') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW dbo.view_all_projects_by_user
GO

CREATE VIEW dbo.view_all_projects_by_user
AS
SELECT	dbo.Projects.Project_id, dbo.Projects.Project_name, dbo.Projects.Project_short_name, dbo.Projects.Project_description, 
        dbo.Projects.Start_date,dbo.Projects.End_date,dbo.Projects.Status_id,
        dbo.Projects.Comments, dbo.view_created_by.Created_by, dbo.Projects.Created_date, dbo.view_Modified_by.Modified_by, 
        dbo.Projects.Modified_date, dbo.Project_X_PAL_Users.User_id
FROM    dbo.Projects 		
		LEFT OUTER JOIN dbo.view_Modified_by ON dbo.Projects.Modified_by = dbo.view_Modified_by.User_id 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.Projects.Created_by = dbo.view_created_by.User_id
		INNER JOIN dbo.Project_X_PAL_Users ON dbo.Projects.Project_id = dbo.Project_X_PAL_Users.Project_id 
	
GO

                      
/****** Object:  View dbo.view_all_reports    Script Date: 12/29/2011  ******/
IF exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_reports') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW dbo.view_all_reports
GO

CREATE VIEW dbo.view_all_reports
AS
SELECT	dbo.Reports.Report_id, dbo.Reports.Report_name, dbo.Reports.Report_query,
        dbo.Reports.Report_description,dbo.view_created_by.Created_by,dbo.Reports.Created_date,
        dbo.view_Modified_by.Modified_by,dbo.Reports.Modified_date
FROM    dbo.Reports
		LEFT OUTER JOIN dbo.view_Modified_by ON dbo.Reports.Modified_by = dbo.view_Modified_by.User_id 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.Reports.Created_by = dbo.view_created_by.User_id		
GO 
                      
/****** Object:  View dbo.view_all_reports_by_user    Script Date: 12/29/2011  ******/
IF exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_reports_by_user') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW dbo.view_all_reports_by_user
GO

CREATE VIEW dbo.view_all_reports_by_user
AS
SELECT	dbo.Reports.Report_id, dbo.Reports.Report_name, dbo.Reports.Report_query,
        dbo.Reports.Report_description,dbo.view_created_by.Created_by,dbo.Reports.Created_date,
        dbo.view_Modified_by.Modified_by,dbo.Reports.Modified_date,dbo.Report_X_PAL_Users.User_id
FROM    dbo.Reports
		LEFT OUTER JOIN dbo.view_Modified_by ON dbo.Reports.Modified_by = dbo.view_Modified_by.User_id 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.Reports.Created_by = dbo.view_created_by.User_id
		INNER JOIN  dbo.Report_X_PAL_Users ON dbo.Reports.Report_id = dbo.Report_X_PAL_Users.Report_id	
GO

 
/****** Object:  View dbo.view_all_tags   Script Date: 12/29/2011  ******/
IF exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_tags') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW dbo.view_all_tags
GO

CREATE VIEW dbo.view_all_tags
AS
SELECT	dbo.Tag.Tag_id, dbo.Tag.Tag_name, dbo.Tag.Project_id, dbo.Projects.Project_name, dbo.Projects.Project_short_name, 
        dbo.Projects.Project_description,dbo.Tag.Tag_type_id, dbo.Tag_Type_LKUP.Tag_type_description, 
        dbo.Tag.Status_id, dbo.Status_LKUP.Status_name, dbo.Tag.Start_date,dbo.Tag.End_date, dbo.Tag.Comment,dbo.Tag.Assigned_user_id, 
        dbo.view_assigned_by.Assigned_by,dbo.view_assigned_to.Assigned_to, dbo.view_created_by.Created_by, dbo.Tag.Created_date, dbo.view_Modified_by.Modified_by, 
        dbo.Tag.Modified_date, dbo.Tag.Priority_id, dbo.Priority_LKUP.Priority_name
FROM    dbo.Tag 
		LEFT OUTER JOIN dbo.Priority_LKUP ON dbo.Tag.Priority_id = dbo.Priority_LKUP.Priority_id 
		LEFT OUTER JOIN dbo.view_Modified_by ON dbo.Tag.Modified_by = dbo.view_Modified_by.User_id 
		LEFT OUTER JOIN dbo.Projects ON dbo.Tag.Project_id = dbo.Projects.Project_id 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.Tag.Created_by = dbo.view_created_by.User_id 
		LEFT OUTER JOIN dbo.Status_LKUP ON dbo.Tag.Status_id = dbo.Status_LKUP.Status_id 
		LEFT OUTER JOIN dbo.Tag_Type_LKUP ON dbo.Tag.Tag_type_id = dbo.Tag_Type_LKUP.Tag_type_id 
		LEFT OUTER JOIN dbo.view_assigned_by ON dbo.Tag.Assigned_user_id = dbo.view_assigned_by.User_id      
		LEFT OUTER JOIN dbo.view_assigned_to ON dbo.Tag.Assigned_user_id = dbo.view_assigned_to.User_id                   
 GO	
  
 
 
/****** Object:  View dbo.view_all_tags_comment   Script Date: 12/29/2011  ******/
IF exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_tags_comment') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW dbo.view_all_tags_comment
GO


CREATE VIEW dbo.view_all_tags_comment
AS

SELECT     dbo.Tag_comments.Tag_comment_id, dbo.Tag_comments.Tag_id, dbo.Tag_comments.Tag_comment, 
           dbo.Tag_comments.Created_date, dbo.view_created_by.Created_by
FROM       dbo.Tag_comments 
           INNER JOIN dbo.view_created_by ON dbo.Tag_comments.Created_by = dbo.view_created_by.User_id
           
GO	         


/****** Object:  View dbo.view_all_tags_group   Script Date: 12/29/2011  ******/
IF exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_tags_group') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW dbo.view_all_tags_group
GO


CREATE VIEW dbo.view_all_tags_group
AS
SELECT     dbo.Tag_Group.Tag_group_id, dbo.Tag_Group.Tag_group_name, dbo.Tag_Group.Created_date, dbo.Tag_Group.Modified_date, 
           dbo.view_Modified_by.Modified_by, dbo.view_created_by.Created_by
FROM       dbo.Tag_Group 
           INNER JOIN dbo.view_created_by ON dbo.Tag_Group.Created_by = dbo.view_created_by.User_id 
           INNER JOIN  dbo.view_Modified_by ON dbo.Tag_Group.Modified_by = dbo.view_Modified_by.User_id
           
           
GO	           
 

/****** Object:  View dbo.view_all_tags_by_group   Script Date: 12/29/2011  ******/
IF exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_tags_by_group') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW dbo.view_all_tags_by_group
GO


CREATE VIEW dbo.view_all_tags_by_group
AS

SELECT     dbo.Tag_Group_X_Tag.Tag_group_id, dbo.view_all_tags.Tag_id, dbo.view_all_tags.Tag_name, 
           dbo.view_all_tags.Project_id, dbo.view_all_tags.Project_name, dbo.view_all_tags.Project_short_name, 
           dbo.view_all_tags.Project_description, dbo.view_all_tags.Project_due_date, dbo.view_all_tags.Tag_type_id, 
           dbo.view_all_tags.Tag_type_description, dbo.view_all_tags.Status_id, dbo.view_all_tags.Status_name, 
           dbo.view_all_tags.Tag_due_date, dbo.view_all_tags.Assigned_by, dbo.view_all_tags.Assigned_user_id, 
           dbo.view_all_tags.Created_by, dbo.view_all_tags.Created_date, dbo.view_all_tags.Modified_by, dbo.view_all_tags.Modified_date, 
           dbo.view_all_tags.Priority_id, dbo.view_all_tags.Priority_name
FROM       dbo.Tag_Group_X_Tag
           INNER JOIN   dbo.view_all_tags ON dbo.Tag_Group_X_Tag.Tag_id = dbo.view_all_tags.Tag_id
           
 GO	           

/****** Object:  View dbo.view_all_tips   Script Date: 12/29/2011  ******/
IF exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_tips') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP VIEW dbo.view_all_tips
GO


CREATE VIEW dbo.view_all_tips
AS

SELECT     dbo.Tips.Tip_id, dbo.Tips.Tip_name, dbo.Tips.Tip_description, dbo.Tips.File_type_id, dbo.Tips.File_location, dbo.Tips.ModIFied_date, dbo.Tips.Post, 
           dbo.view_Modified_by.Modified_by
FROM       dbo.Tips 

           INNER JOIN dbo.view_Modified_by ON dbo.Tips.Modified_by = dbo.view_Modified_by.User_id
          
GO	       
