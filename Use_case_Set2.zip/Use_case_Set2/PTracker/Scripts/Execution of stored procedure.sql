
DECLARE @Project_id VARCHAR(20)

EXEC dbo.sp_new_id @Project_id OUTPUT

print @Project_id

/***Object=EXECUTION OF SPtag  date:14/29/2011***/
EXEC dbo.sp_get_all_tag

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_create_tag_wiz 'projects','g','3','1','8','3-06-2009','PROJECT','A','3-06-2009','D','3-06-2009',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.tag


EXEC dbo.sp_get_all_tag

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_update_tag_wiz 'ppy100013','project','prj','3','1','8','3-06-2009','PROJECT','A','3-06-2009','D','3-06-2009',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.tag


EXEC dbo.sp_get_all_tag

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_delete_tag_wiz 'ppy100022',  @RETVAL OUTPUT
Print @RETVAL



/***Object=EXECUTION OF PROJECT_X_PAL_USER  date:14/29/2011***/
EXEC dbo.sp_get_all_project_x_pal_users

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_add_user_to_project '1',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.Project_X_PAL_Users




EXEC dbo.sp_get_all_project_x_pal_users

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_remove_user_from_project 'PTR100036',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.Project_X_PAL_Users



/***Object=EXECUTION OF REPORT_X_PAL_USER  date:14/29/2011***/
EXEC dbo.sp_get_all_report_x_pal_users

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_add_user_to_report 'd','SS',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.report_X_PAL_Users




EXEC dbo.sp_get_all_project_x_pal_users

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_remove_user_from_report 'AHH',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.report_X_PAL_Users


/***Object=EXECUTION OF SP_tag_to_comment  date:14/29/2011***/
EXEC dbo.sp_get_all_tag_comments

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_add_tag_to_comment 'S','A','PB001','2-03-2001',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.tag_comments


/***Object=EXECUTION OF SP_tag_to_comment  date:14/29/2011***/
EXEC dbo.sp_get_all_tag_comments

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_remove_tag_to_comment 'S','A','PB001','2-03-2001',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.tag_comments





/***Object=EXECUTION OF sp_tag_groups  date:14/29/2011***/
EXEC dbo.sp_get_all_tag_groups

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_create_tag_group_wiz 'Pop','u','8-09-2000','C','8-09-2000',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.tag_Group



/***Object=EXECUTION OF sp_tag_groups  date:14/29/2011***/
EXEC dbo.sp_get_all_tag_groups

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_update_tag_group_wiz 'ppy100028','poo','k','8-09-2000','C','8-09-2000',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.tag_Group


/***Object=EXECUTION OF sp_tag_groups  date:14/29/2011***/
EXEC dbo.sp_get_all_tag_groups

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_delete_tag_Group_wiz 'ppy100028',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.tag_Group





/***Object=EXECUTION OF sp_tag_group_x_tag  date:14/29/2011***/
EXEC dbo.sp_get_all_tag_groups

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_add_tag_to_tag_group 'gg',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.tag_Group_X_tag





/***Object=EXECUTION OF sp_tag_group_x_tag  date:14/29/2011***/
EXEC dbo.sp_get_all_tag_group_x_tag

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_remove_tag_from_tag_group 'PA003',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.tag_Group_X_tag





/***Object=EXECUTION OF sp_tips  date:14/29/2011***/
EXEC dbo.sp_get_all_tips

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_create_tip_wiz 'A','S','5','PB','PB001','7-09-2000','J',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.Tips

EXEC dbo.sp_get_all_projects

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_create_project_wiz 'rrr','pghh','a','2','1-1-2012','1-1-2012','rtrt',@RETVAL OUTPUT
Print @RETVAL

select * from dbo.Projects

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_update_project_wiz 'as12118','PAL','pppp','a','2-05-2000','Rolina',  @RETVAL OUTPUT
Print @RETVAL
 
select * from dbo.Projects

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_delete_project_wiz'as12118','Rolina' , @RETVAL OUTPUT
Print @RETVAL

 EXEC  dbo.sp_get_all_project_x_pal_users
 
 
DECLARE @RETVAL AS VARCHAR(20)
EXEC  dbo.sp_add_user_to_project '675676' , @RETVAL OUTPUT
Print @RETVAL 

 select * from dbo.Project_X_PAL_Users
 
 DECLARE @RETVAL AS VARCHAR(20)
 
  EXEC dbo.sp_remove_user_from_project 'ppy100017', @RETVAL OUTPUT
  Print @RETVAL
  
   select * from dbo.Project_X_PAL_Users


exec dbo.sp_get_all_priority_lkup

DECLARE @RETVAL AS VARCHAR(20)
EXEC  dbo.sp_create_priority_lkup_wiz 'vvb','12',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.Priority_LKUP


EXEC dbo.sp_get_all_reports	

DECLARE @RETVAL AS VARCHAR(20)
EXEC  dbo.sp_create_report_wiz 'aeaefd','pg','gg','Abi','12-05-2011','Abi','23-06-2011',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.Reports

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_update_report_wiz 'ppy100018','pal','pg','gg','rolina','12-05-2011','arpita','23-06-2011',  @RETVAL OUTPUT
Print @RETVAL

select * from dbo.reports

DECLARE @RETVAL AS VARCHAR(20)
EXEC dbo.sp_delete_report_wiz'as1260',  @RETVAL OUTPUT
Print @RETVAL


