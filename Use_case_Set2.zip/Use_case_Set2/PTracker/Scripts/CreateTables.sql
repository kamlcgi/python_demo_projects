/****** Database Name: PTracker_db_10 ******/
/****** Author:  Sreenivasan Subbanchattiar  ******/
/****** Script Created By: Sreenivasan Subbanchattiar ******/
/****** Script Created Date: 12/26/2011  ******/
/****** Script Modified By: Arpita  ******/
/****** Script Modified Date: 12/26/2011  ******/
/****** Script Version: 1.0  ******/


/****** Database:  PTracker_db_10  ******/
USE PTracker_db_10
GO


/****** Object:  Table dbo.Projects    Script Date: 12/26/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Projects') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Projects
GO

/****** Object:  Table dbo.Project_X_PAL_Users    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Project_X_PAL_Users') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Project_X_PAL_Users
GO

/****** Object:  Table dbo.Priority_LKUP    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Priority_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Priority_LKUP
GO

/****** Object:  Table dbo.Tag_Type_LKUP    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Tag_Type_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Tag_Type_LKUP
GO

/****** Object:  Table dbo.Project_Status_LKUP    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Project_Status_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Project_Status_LKUP
GO

/****** Object:  Table dbo.Status_LKUP    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Status_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Status_LKUP
GO

/****** Object:  Table dbo.Tag    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Tag') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Tag
GO

/****** Object:  Table dbo.Tag_comments    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Tag_comments') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Tag_comments
GO

/****** Object:  Table dbo.Tag_attachment    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Tag_attachment') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Tag_attachment
GO

/****** Object:  Table dbo.Tag_Group    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Tag_Group') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Tag_Group
GO

/****** Object:  Table dbo.Tag_Group_X_Tag    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Tag_Group_X_Tag') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Tag_Group_X_Tag
GO

/****** Object:  Table dbo.Reports    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Reports') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Reports
GO

/****** Object:  Table dbo.Report_X_PAL_Users    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Report_X_PAL_Users') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Report_X_PAL_Users
GO

/****** Object:  Table dbo.File_Type_LKUP    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.File_Type_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.File_Type_LKUP
GO

/****** Object:  Table dbo.Tips    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Tips') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Tips
GO

/****** Object:  Table dbo.PAL_Users    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Users') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Users
GO

/****** Object:  Table dbo.PAL_Users_Log    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Users_Log') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Users_Log
GO

/****** Object:  Table dbo.PAL_Role    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Role') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Role
GO

/****** Object:  Table dbo.PAL_Page    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Page') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Page
GO

/****** Object:  Table dbo.PAL_Role_X_PAL_Page    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Role_X_PAL_Page') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Role_X_PAL_Page
GO

/****** Object:  Table dbo.T_PAL_Role_X_PAL_Page    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.T_PAL_Role_X_PAL_Page') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.T_PAL_Role_X_PAL_Page
GO

/****** Object:  Table dbo.PAL_Address    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Address') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Address
GO

/****** Object:  Table dbo.Country_LKUP    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Country_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Country_LKUP
GO

/****** Object:  Table dbo.State_LKUP    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.State_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.State_LKUP
GO

/****** Object:  Table dbo.Country_X_State    Script Date: 12/26/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Country_X_State') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Country_X_State
GO


/****** Object:  Table dbo.PAL_Identifiers    Script Date: 12/26/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Identifiers') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Identifiers
GO


/****** Object:  Table dbo.Projects    Script Date: 12/26/2011  ******/
CREATE TABLE dbo.Projects (
		Project_id	Varchar(20)	NOT NULL,
		Project_name	Varchar(100)NULL,	
		Project_short_name	Varchar(100)NULL,	
		Project_description	Varchar(255)NULL,	
		Start_date	Datetime	NULL,
		End_date	Datetime	NULL,
		Status_id	Integer NULL,
		Comments  Varchar(500) NULL,
		Created_by	Varchar(20)	NULL,	
		Created_date	Datetime NULL,	
		Modified_by	Varchar(20)	NULL,	
		Modified_date	Datetime	NULL,
        CONSTRAINT PK_Projects PRIMARY KEY (Project_id)  
) 
GO

/****** Object:  Table dbo.Project_X_PAL_Users    Script Date: 12/26/2011   ******/
CREATE TABLE dbo.Project_X_PAL_Users (
		Project_id	Varchar(20)	NOT NULL,
		User_id	Varchar(20)	NOT NULL,
        CONSTRAINT PK_Project_X_PAL_Users PRIMARY KEY (Project_id,User_id) 
) 
GO

/****** Object:  Table dbo.Priority_LKUP    Script Date: 12/26/2011   ******/
CREATE TABLE dbo.Priority_LKUP (
		Priority_id	Integer	NOT NULL,	
		Priority_name	Varchar(100) NULL,	
		Sort_order	Integer	NULL,
        CONSTRAINT PK_Priority_LKUP PRIMARY KEY (Priority_id)  
) 
GO


/****** Object:  Table dbo.Tag_Type_LKUP    Script Date: 12/26/2011   ******/
CREATE  TABLE dbo.Tag_Type_LKUP (	
		Tag_type_id	Integer	NOT NULL,
		Tag_type_description	Varchar(100) NULL,
		Sort_order	Integer	NULL,	
        CONSTRAINT PK_Tag_Type_LKUP PRIMARY KEY (Tag_type_id)  
) 
GO

/****** Object:  Table dbo.Project_Status_LKUP    Script Date: 12/26/2011   ******/
CREATE TABLE dbo.Project_Status_LKUP (
		Status_id	Integer	NOT NULL,
		Status_name	Varchar(100) NULL,	
		Sort_order	Integer	NULL,	
        CONSTRAINT PK_Project_Status_LKUP PRIMARY KEY (Status_id)  
) 
GO

/****** Object:  Table dbo.Status_LKUP    Script Date: 12/26/2011   ******/
CREATE TABLE dbo.Status_LKUP (
		Status_id	Integer	NOT NULL,
		Status_name	Varchar(100) NULL,	
		Sort_order	Integer	NULL,	
        CONSTRAINT PK_Status_LKUP PRIMARY KEY (Status_id)  
) 
GO


/****** Object:  Table dbo.Tag    Script Date: 12/26/2011   ******/
CREATE    TABLE dbo.Tag (	
		Tag_id	Varchar(20)	NOT NULL,
		Tag_name	Varchar(100)	NULL,	
		Project_id	Varchar(20)	NOT NULL,
		Tag_type_id	Integer	NOT NULL,
		Status_id	Integer	NOT NULL,
		Priority_id	Integer	NOT NULL,	
		Tag_due_date	Date	NULL,	
		Assigned_user_id	Varchar(20)	NULL,
		Assigned_by  Varchar(20)	NULL,
		Assigned_to     Varchar(20)	NULL,
		Created_by	Varchar(20)	NULL,	
		Created_date	Datetime	NULL,	
		Modified_by	Varchar(20)	NULL,
		Modified_date	Datetime	NULL,
		Start_date	Date	NULL,
		End_date	Date	NULL,
		Comment     Varchar(255) Null,
        CONSTRAINT PK_Tag PRIMARY KEY (Tag_id)  
) 
GO

/****** Object:  Table dbo.Tag_Comments    Script Date: 12/26/2011   ******/
CREATE TABLE dbo.Tag_Comments (	
		Tag_comment_id	UniqueIdentifier NOT NULL Default newid(),
		Tag_id	Varchar(20)	NOT NULL,
		Tag_comment	Varchar(2000)	NULL,	
		Created_by	Varchar(20)	NULL,
		Created_date	Datetime	NULL,
        CONSTRAINT PK_Tag_Comments PRIMARY KEY (Tag_comment_id)  
) 
GO

/****** Object:  Table dbo.Tag_Attachments    Script Date: 12/26/2011   ******/
CREATE  TABLE dbo.Tag_Attachments (
		Tag_attachment_id	UniqueIdentifier NOT NULL,
		Tag_id	Varchar(20)	NOT NULL,
		Tag_file_name	Varchar(50)	 NULL,
		Tag_file_mine	Varchar(50)	 NULL,		
		Tag_file	Image	NULL,	
		Created_by	Varchar(20)	NULL,
		Created_date	Datetime	NULL,
        CONSTRAINT PK_Tag_attachment_id PRIMARY KEY (Tag_attachment_id)  
) 
GO

/****** Object:  Table dbo.Tag_Group    Script Date: 12/26/2011   ******/
CREATE  TABLE dbo.Tag_Group (
		Tag_group_id	Integer	NOT NULL,
		Tag_group_name	Varchar(100) NOT NULL,
		Created_by	Varchar(20)	NULL,
		Created_date	Datetime	NULL,
		Modified_by	Varchar(20)	NULL,
		Modified_date	Datetime	NULL,
        CONSTRAINT PK_Tag_Group PRIMARY KEY (Tag_group_id)  
) 
GO

/****** Object:  Table dbo.Tag_Group_X_Tag    Script Date: 12/26/2011   ******/
CREATE TABLE dbo.Tag_Group_X_Tag (
		Tag_group_id	Integer	NOT NULL,
		Tag_id	Varchar(20)	NOT NULL,
        CONSTRAINT PK_Tag_Group_X_Tag PRIMARY KEY (Tag_group_id)  
) 
GO

/****** Object:  Table dbo.Reports   Script Date: 12/26/2011   ******/
CREATE TABLE dbo.Reports (
		Report_id	Varchar(20)	NOT NULL,
		Report_name	Varchar(100)	NULL,	
		Report_query	Varchar(8000)	NULL,	
		Report_description	Varchar(255)	NULL,	
		Created_by	Varchar(20)	NULL,	
		Created_date	Datetime	NULL,	
		Modified_by	Varchar(20)	NULL,	
		Modified_date	Datetime	NULL,	
        CONSTRAINT PK_Reports PRIMARY KEY (Report_id)  
) 
GO

/****** Object:  Table dbo.Report_X_PAL_Users    Script Date: 12/26/2011   ******/
CREATE TABLE dbo.Report_X_PAL_Users (
		Report_id	Varchar(20)	NOT NULL,
		User_id	Varchar(20)	NOT NULL,
        CONSTRAINT PK_Report_X_PAL_Users PRIMARY KEY (Report_id,User_id)  
) 
GO


/****** Object:  Table dbo.File_Type_LKUP    Script Date: 12/26/2011   ******/
CREATE TABLE dbo.File_Type_LKUP (
		File_type_id Int NOT NULL,
		File_type_description Varchar(50) NULL,
        CONSTRAINT PK_File_Type_LKUP PRIMARY KEY (File_type_id)  
) 
GO

/****** Object:  Table dbo.Tips    Script Date: 12/26/2011   ******/
CREATE TABLE dbo.Tips (
		Tip_id Varchar(20) NOT NULL,
		Tip_name varchar(75) NULL,
		Tip_description varchar(500) NULL,
		File_type_id tinyint NULL,
		File_location varchar(50) NULL,
		Modified_by Varchar(20) NULL,
		Modified_date datetime NULL,	
		Post char(1) NULL,
        CONSTRAINT PK_Tips PRIMARY KEY (Tip_id)  
) 
GO

/****** Object:  Table dbo.PAL_Users    Script Date: 12/26/2011   ******/
CREATE TABLE dbo.PAL_Users (
	User_id Varchar(20) NOT NULL,
	User_name varchar(50) NULL,
	Passwd varchar(50) NULL,
	First_name varchar(50) NULL,
	Last_name varchar(50) NULL,
	Active_user char(1) NULL,
	Role_id	 integer NOT NULL,
	Last_login_date datetime NULL,
	Address_id Varchar(20) NULL,
	Created_by Varchar(20) NULL,
	Created_date datetime NULL,
	Modified_by Varchar(20) NULL,
	Modified_date datetime NULL,
	CONSTRAINT PK_PAL_Users PRIMARY KEY (User_id)  
) 
GO

/****** Object:  Table dbo.PAL_Role    Script Date: 12/26/2011  ******/
CREATE TABLE dbo.PAL_Role (
	Role_id	 integer NOT NULL,
	Role_name	varchar(50) NULL,
	Created_by	Varchar(20) NULL,
	Created_date	datetime NULL,
	Modified_by	Varchar(20) NULL,
	Modified_date	Datetime NULL,
	CONSTRAINT PK_PAL_Role  PRIMARY KEY (Role_id)	
) 
GO

/****** Object:  Table dbo.PAL_Page    Script Date: 12/26/2011  ******/
CREATE TABLE dbo.PAL_Page (
	Page_id	 integer NOT NULL,
	Parent_Page_id	integer NULL,
	Page_title	varchar(50) NULL,
	Navigate_url	varchar(50) NULL,
	Page_description	varchar(255) NULL,
	Created_by	Varchar(20) NULL,
	Created_date	datetime NULL,
	Modified_by	Varchar(20) NULL,
	Modified_date	Datetime NULL,
	CONSTRAINT PK_PAL_Page PRIMARY KEY (Page_id)	
) 
GO

/****** Object:  Table dbo.PAL_Role_X_PAL_Page    Script Date: 12/26/2011  ******/
CREATE TABLE dbo.PAL_Role_X_PAL_Page (
	Role_id	integer NOT NULL,	
    Page_id	integer NOT NULL,
	Sort_index	smallint NULL,
	Allow_view char(1) NULL,
	Allow_modify char(1) NULL,
	Allow_delete char(1) NULL,
	CONSTRAINT PK_PAL_Role_X_PAL_Page PRIMARY KEY (Role_id,Page_id)	
) 
GO

/****** Object:  Table dbo.T_PAL_Role_X_PAL_Page    Script Date: 12/26/2011  ******/
CREATE TABLE dbo.T_PAL_Role_X_PAL_Page (
	Role_id	integer NOT NULL,	
    Page_id	integer NOT NULL,
    Modified_by varchar(20) NOT NULL,
	Sort_index	smallint NULL,
	Allow_view char(1) NULL,
	Allow_modify char(1) NULL,
	Allow_delete char(1) NULL,	
	CONSTRAINT PK_T_PAL_Role_X_PAL_Page PRIMARY KEY (Role_id,Page_id,Modified_by)	
) 
GO
	
/****** Object:  Table dbo.PAL_Users_Log    Script Date: 12/26/2011   ******/
CREATE TABLE dbo.PAL_Users_Log (
	Log_id uniqueidentifier NOT NULL DEFAULT NEWID(),
	IP_address  varchar(50) NULL,
	Browser  varchar(500) NULL,
	Log_data varchar(2000) NULL,
	Log_by varchar(20) NULL,
	Log_date datetime NULL,	
	CONSTRAINT PK_PAL_Users_Log PRIMARY KEY (Log_id)  
) 
GO

/****** Object:  Table dbo.Pal_Address    Script Date: 12/26/2011   ******/
CREATE TABLE dbo.Pal_Address (
	Address_id Varchar(20) NOT NULL,
	Address1 varchar(100) NULL,
	Address2 varchar(100) NULL,
	City varchar(50) NULL,
	State_id int NULL,
	Zip varchar(50) NULL,
	Country_id int NULL,
	Phone varchar(50) NULL,
	Mobile varchar(50) NULL,
	Fax varchar(50) NULL,
	Email varchar(50) NULL,
	Website varchar(50) NULL,
	CONSTRAINT PK_Pal_Address PRIMARY KEY (Address_id)  
) 
GO

/****** Object:  Table dbo.Country_LKUP    Script Date: 12/26/2011   ******/
CREATE TABLE dbo.Country_LKUP (
	Country_id int NOT NULL,
	Country_name varchar(50) NULL,
	Country_code varchar(2) NULL,
	CONSTRAINT PK_Country_LKUP PRIMARY KEY (Country_id)  
	) 
GO

/****** Object:  Table dbo.State_LKUP    Script Date: 12/26/2011   ******/
CREATE TABLE dbo.State_LKUP (	
	State_id int NOT NULL,
	State_name varchar(50) NULL,
	State_code varchar(2) NULL,
	CONSTRAINT PK_State_LKUP PRIMARY KEY (State_id)  
	) 
GO

/****** Object:  Table dbo.Country_X_State    Script Date: 12/26/2011   ******/
CREATE TABLE dbo.Country_X_State (
	Country_id int  NOT NULL,
	State_id int NOT NULL, 
	CONSTRAINT PK_Country_X_State PRIMARY KEY (Country_id,State_id)  
	) 
GO


/****** Object:  Table dbo.PAL_Identifiers    Script Date: 12/26/2011   ******/
CREATE TABLE dbo.PAL_Identifiers (
	PAL_id varchar(4) NOT NULL,
	New_id int NOT NULL,	
) 
GO
