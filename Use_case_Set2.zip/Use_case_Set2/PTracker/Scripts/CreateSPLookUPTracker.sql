/****** Script: Create All LookUp Table Stored Procedures - PBill_db_xx	******/
/****** Author: Sreenivasan Subbanchattiar******/
/****** Script Created By: Arpita das******/
/****** Script Created Date: 12/29/2011******/
/****** Script Modified By: Sreenivasan Subbanchattiar******/
/****** Script Modified Date:  12/29/2011******/
/****** Script Version: 1.0 ******/

/****** Object:Stored Procedure   dbo.sp_get_all_project_lkup    Script Date: 12/29/2011******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_project_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_project_lkup
GO

CREATE procedure dbo.sp_get_all_project_lkup
AS
begin

 SELECT * FROM  dbo.view_all_projects 

end
GO

/****** Object:Stored Procedure   dbo.sp_get_all_priority_lkup    Script Date: 12/29/2011******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_priority_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_priority_lkup
GO

CREATE procedure dbo.sp_get_all_priority_lkup
AS
begin


 SELECT * FROM  dbo.Priority_LKUP

end
GO

/****** Object:Stored Procedure   dbo.sp_get_all_tag_type_lkup  Script Date:  12/29/2011******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_tag_type_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_tag_type_lkup
GO

CREATE procedure dbo.sp_get_all_tag_type_lkup
AS
begin

 SELECT * FROM  dbo.tag_Type_LKUP

end
GO

/****** Object:Stored Procedure   dbo.sp_get_all_status_lkup  Script Date:  12/29/2011******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_status_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_status_lkup
GO

CREATE procedure dbo.sp_get_all_status_lkup
AS
begin

 SELECT * FROM  dbo.Status_LKUP

end
GO


/****** Object:Stored Procedure   dbo.sp_get_all_file_type_lkup  Script Date:  12/29/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_file_type_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_file_type_lkup
GO

CREATE procedure dbo.sp_get_all_file_type_lkup
AS
begin

 SELECT * FROM  dbo.File_Type_LKUP

end
GO

/****** Object:Stored Procedure   dbo.sp_get_all_assigned_user  Script Date:  12/29/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_assigned_user') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_assigned_user
GO

CREATE procedure dbo.sp_get_all_assigned_user
AS
begin

 SELECT * FROM  dbo.view_assigned_by

end
GO


/****** Object:Stored Procedure   dbo.sp_get_all_assigned_user_to  Script Date:  12/29/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_assigned_user_to') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_assigned_user_to
GO

CREATE procedure dbo.sp_get_all_assigned_user_to
AS
begin

 SELECT * FROM  dbo.view_assigned_to

end
GO



 /***Object=Table  dbo.sp_get_project_lkup  Script Date: 12/29/2011 ***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_project_lkup') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_project_lkup
GO

CREATE PROCEDURE dbo.sp_get_project_lkup
			@Project_id	varchar(20)
			
AS
BEGIN
	SELECT * FROM dbo.view_all_projects WHERE Project_id=@Project_id
END
GO

 /***Object=Table  dbo.sp_get_priority_lkup  Script Date: 12/29/2011 ***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_priority_lkup') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_priority_lkup
GO

CREATE PROCEDURE dbo.sp_get_priority_lkup
			@Priority_id	Integer	
			
AS
BEGIN
	SELECT * FROM dbo.Priority_LKUP WHERE Priority_id=@Priority_id
END
GO
 
 /***Object=Table  dbo.sp_get_tag_type_lkup  Script Date: 12/29/2011 ***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_tag_type_lkup') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_tag_type_lkup
GO

CREATE PROCEDURE dbo.sp_get_tag_type_lkup
			@tag_type_id	Integer	
			
AS
BEGIN
	SELECT * FROM dbo.tag_Type_LKUP WHERE tag_type_id=@tag_type_id
END
GO

 /***Object=Table  dbo.sp_get_all_project_status_lkup  Script Date: 12/29/2011 ***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_all_project_status_lkup') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_all_project_status_lkup
GO

CREATE PROCEDURE dbo.sp_get_all_project_status_lkup
AS
BEGIN
	SELECT * FROM dbo.Project_Status_LKUP 
END
GO
 
 /***Object=Table  dbo.sp_get_status_lkup  Script Date: 12/29/2011 ***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_status_lkup') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_status_lkup
GO

CREATE PROCEDURE dbo.sp_get_status_lkup
			@Status_id	Integer	
			
AS
BEGIN
	SELECT * FROM dbo.Status_LKUP WHERE Status_id=@Status_id
END
GO

 
 /***Object=Table  dbo.sp_get_file_Type_lkup  Script Date: 12/29/2011 ***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_file_Type_lkup') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_file_Type_lkup
GO

CREATE PROCEDURE dbo.sp_get_file_Type_lkup
			@File_type_id	Integer	
			
AS
BEGIN
	SELECT * FROM dbo.File_Type_LKUP WHERE File_type_id=@File_type_id
END
GO


/***Object=Table dbo.sp_create_priority_lkup Script Date: 12/29/2011 ***/

IF exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_create_priority_lkup') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
DROP PROCEDURE dbo.sp_create_priority_lkup
GO

 
CREATE procedure dbo.sp_create_priority_lkup(
  
	
		@Priority_name	Varchar(100),
		@Sort_order	Integer,
		@retval varchar(20) output
	)
As
BEGIN
declare @Priority_id int

BEGIN TRAN

 INSERT INTO dbo.Priority_LKUP(
		 Priority_id,
		 Priority_name,
		 Sort_order)
	 	
 values(
		 @Priority_id,
		 @Priority_name,
		 @Sort_order )
 
 IF @@ERROR <> 0
 BEGIN
 ROLLBACK TRAN
 SET @retval='-1'
 RETURN
 END
 COMMIT TRAN
 SET @retval=0
 RETURN
 END 
 GO
 
  /***Object=Table dbo.sp_update_priority_lkup Script Date: 12/29/2011 ***/
 IF exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_update_priority_lkup') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
 DROP procedure dbo.sp_update_priority_lkup
 GO
 CREATE procedure dbo.sp_update_priority_lkup
 (
        @Priority_id int,
		@Priority_name	Varchar(100),
		@Sort_order	Integer,
		@retval varchar(20) output)
	
	
	
 
 AS
 
 BEGIN
 BEGIN TRAN
 UPDATE dbo.Priority_LKUP SET
 
	Priority_name=@Priority_name,
	Sort_order=@Sort_order
	
 WHERE   Priority_id=@Priority_id 
 
  IF @@ERROR <>0
       BEGIN
       ROLLBACK TRAN
       SET @retval='-1'
       RETURN
 END
 COMMIT TRAN
 
    SET @retval=0 
    
 RETURN
 
 END
 GO
 
  /***Object=Table dbo.sp_delete_priority_lkup Script Date: 12/29/2011 **/

 IF exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_delete_priority_lkup') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
 DROP procedure dbo.sp_delete_priority_lkup
 GO
 
 CREATE procedure dbo.sp_delete_priority_lkup
 (
    @Priority_id Int,
	@retval int output
)
 AS 
 BEGIN


 
BEGIN TRAN 
 
    DELETE dbo.Priority_LKUP
    WHERE   Priority_id=@Priority_id
    
 IF @@ERROR <>0
            BEGIN
            ROLLBACK TRAN
            SET @retval='-1'
            RETURN
 END
 
 COMMIT TRAN
 
        SET @retval=0
         RETURN
 END
 
 GO

 
 
/***Object=Table dbo.sp_create_tag_type_lkup Script Date: 12/29/2011 ***/

IF exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_create_tag_type_lkup') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
DROP PROCEDURE dbo.sp_create_tag_type_lkup
GO

 
CREATE procedure dbo.sp_create_tag_type_lkup(
  
				@tag_type_description	Varchar(100),
				@Sort_order	Integer,
				@retval varchar(20) output
	)
As
BEGIN
declare @tag_type_id int

BEGIN TRAN

 INSERT INTO dbo.tag_Type_LKUP(
		 tag_type_id,
		 tag_type_description,
		 Sort_order)
	 	
 values(
		 @tag_type_id,
		 @tag_type_description,
		 @Sort_order )
 
 IF @@ERROR <> 0
 BEGIN
 ROLLBACK TRAN
 SET @retval='-1'
 RETURN
 END
 COMMIT TRAN
 SET @retval=0
 RETURN
 END 
 GO
 
  /***Object=Table dbo.sp_update_tag_type_lkup Script Date: 12/29/2011 ***/
 IF exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_update_tag_type_lkup') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
 DROP procedure dbo.sp_update_tag_type_lkup
 GO
 CREATE procedure dbo.sp_update_tag_type_lkup
 (
				@tag_type_id	Integer,
				@tag_type_description	Varchar(100),
				@Sort_order	Integer,
				@retval varchar(20) output)
	
	
	
 
 AS
 
 BEGIN
 BEGIN TRAN
 UPDATE dbo.tag_Type_LKUP SET
 
	tag_type_description=@tag_type_description,
	Sort_order=@Sort_order
	
 WHERE   tag_type_id=@tag_type_id 
 
  IF @@ERROR <>0
       BEGIN
       ROLLBACK TRAN
       SET @retval='-1'
       RETURN
 END
 COMMIT TRAN
 
    SET @retval=0 
    
 RETURN
 
 END
 GO
  /***Object=Table dbo.sp_delete_tag_type_lkup Script Date: 12/29/2011 **/

 IF exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_delete_tag_type_lkup') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
 DROP procedure dbo.sp_delete_tag_type_lkup
 GO
 
 CREATE procedure dbo.sp_delete_tag_type_lkup
 (
    @tag_type_id Int,
	@retval int output
)
 AS 
 BEGIN


 
BEGIN TRAN 
 
    DELETE dbo.tag_Type_LKUP
    WHERE   tag_type_id=@tag_type_id
    
 IF @@ERROR <>0
            BEGIN
            ROLLBACK TRAN
            SET @retval='-1'
            RETURN
 END
 
 COMMIT TRAN
 
        SET @retval=0
         RETURN
 END
 
 GO
 
 /***Object=Table dbo.sp_create_status_lkup Script Date: 12/29/2011 ***/

IF exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_create_status_lkup') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
DROP PROCEDURE dbo.sp_create_status_lkup
GO

 
CREATE procedure dbo.sp_create_status_lkup(
 
		@Status_name	Varchar(100),
		@Sort_order	Integer,
		@retval varchar(20) output
	)
As
BEGIN
declare @Status_id int

BEGIN TRAN

 INSERT INTO dbo.Status_LKUP(
		 Status_id,
		 Status_name,
		 Sort_order)
	 	
 values(
		 @Status_id,
		 @Status_name,
		 @Sort_order )
 
 IF @@ERROR <> 0
 BEGIN
 ROLLBACK TRAN
 SET @retval='-1'
 RETURN
 END
 COMMIT TRAN
 SET @retval=0
 RETURN
 END 
 GO
 
  /***Object=Table dbo.sp_update_status_lkup Script Date: 12/29/2011 ***/
 IF exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_update_status_lkup') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
 DROP procedure dbo.sp_update_status_lkup
 GO
 CREATE procedure dbo.sp_update_status_lkup
 (
				@Status_id	Integer,
				@Status_name	Varchar(100),
				@Sort_order	Integer,
				@retval varchar(20) output)
	
	
	
 
 AS
 
 BEGIN
 BEGIN TRAN
 UPDATE dbo.Status_LKUP SET
 
	Status_name=@Status_name,
	Sort_order=@Sort_order
	
 WHERE   Status_id=@Status_id 
 
  IF @@ERROR <>0
       BEGIN
       ROLLBACK TRAN
       SET @retval='-1'
       RETURN
 END
 COMMIT TRAN
 
    SET @retval=0 
    
 RETURN
 
 END
 GO
  /***Object=Table dbo.sp_delete_status_lkup Script Date: 12/29/2011 **/

 IF exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_delete_status_lkup') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
 DROP procedure dbo.sp_delete_status_lkup
 GO
 
 CREATE procedure dbo.sp_delete_status_lkup
 (
    @Status_id Int,
	@retval int output
)
 AS 
 BEGIN


 
BEGIN TRAN 
 
    DELETE dbo.Status_LKUP
    WHERE   Status_id=@Status_id
    
 IF @@ERROR <>0
            BEGIN
            ROLLBACK TRAN
            SET @retval='-1'
            RETURN
 END
 
 COMMIT TRAN
 
        SET @retval=0
         RETURN
 END
 
 GO

  /***Object=Table dbo.sp_create_status_lkup Script Date: 12/29/2011 ***/

IF exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_create_file_type_lkup') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
DROP PROCEDURE dbo.sp_create_file_type_lkup
GO

 
CREATE procedure dbo.sp_create_file_type_lkup(
		 
				@File_type_description	Varchar(50),
				@retval varchar(20) output
	)
As
BEGIN
declare @File_type_id	Int

BEGIN TRAN

 INSERT INTO dbo.File_Type_LKUP(
				File_type_id,
				File_type_description)
	
	 	
 values(
				@File_type_id,
				@File_type_description)
 
 IF @@ERROR <> 0
 BEGIN
 ROLLBACK TRAN
 SET @retval='-1'
 RETURN
 END
 COMMIT TRAN
 SET @retval=0
 RETURN
 END 
 GO
 
  /***Object=Table dbo.sp_update_file_type_lkup Script Date: 12/29/2011 ***/
 IF exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_update_file_type_lkup') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
 DROP procedure dbo.sp_update_file_type_lkup
 GO
 CREATE procedure dbo.sp_update_file_type_lkup
 (
				@File_type_id	Integer,
				@File_type_description	Varchar(50),
				@retval varchar(20) output)
	
	
	
 
 AS
 
 BEGIN
 BEGIN TRAN
 UPDATE dbo.File_Type_LKUP SET
 
	File_type_description=@File_type_description
	
	
 WHERE   File_type_id=@File_type_id 
 
  IF @@ERROR <>0
       BEGIN
       ROLLBACK TRAN
       SET @retval='-1'
       RETURN
 END
 COMMIT TRAN
 
    SET  @retval=0 
    
 RETURN
 
 END
 GO
  /***Object=Table dbo.sp_delete_file_type_lkup Script Date: 12/29/2011 **/

 IF exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_delete_file_type_lkup') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
 DROP procedure dbo.sp_delete_file_type_lkup
 GO
 
 CREATE procedure dbo.sp_delete_file_type_lkup
 (
			@File_type_id Int,
			@retval int output
)
 AS 
 BEGIN


 
BEGIN TRAN 
 
    DELETE dbo.File_Type_LKUP
    WHERE   File_type_id=@File_type_id
    
 IF @@ERROR <>0
            BEGIN
            ROLLBACK TRAN
            SET @retval='-1'
            RETURN
 END
 
 COMMIT TRAN
 
        SET @retval=0
         RETURN
 END
 
 GO

 
 
 