
/****** Database Name: PTag_db_xx  ******/
/****** Author:  Sreenivasan Subbanchattiar  ******/
/****** Script Created By: Sreenivasan Subbanchattiar ******/
/****** Script Created date: 12/29/2011  ******/
/****** Script Modified By: Arpita ******/
/****** Script Modified date: 12/29/2011  ******/
/****** Script Version: 1.0  ******/
/****** Database:  PTag_db_xx  ******/


IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_all_tags') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_all_tags	
GO

CREATE PROCEDURE dbo.sp_get_all_tags
AS
 BEGIN
	 SELECT * FROM dbo.view_all_tags
 END
GO 


/***Object=Table  dbo.sp_get_Tag Script date:12/29/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_Tag') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_tag
GO

CREATE PROCEDURE dbo.sp_get_tag
				 @Tag_id	VARCHAR(20)
AS
BEGIN
	SELECT * FROM dbo.view_all_tags WHERE Tag_id=@Tag_id
END
GO

/***Object=Table  dbo.sp_get_all_tag_comments Script date:12/29/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_all_tag_comments') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_all_tag_comments
GO

CREATE PROCEDURE dbo.sp_get_all_tag_comments
				 @Tag_id	VARCHAR(20)
AS
BEGIN
	SELECT * FROM dbo.view_all_tags_comment WHERE Tag_id=@Tag_id
END
GO

/***Object=Table dbo.sp_create_tag_wiz Script date:12/29/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_create_tag_wiz') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_create_tag_wiz
GO

CREATE PROCEDURE dbo.sp_create_tag_wiz(    
			@Tag_name	VARCHAR(100),
			@Project_id	VARCHAR(20),
			@Tag_type_id	INTEGER,
			@Status_id	INTEGER,
			@Priority_id	INTEGER,
			@Assigned_user_id	VARCHAR(20),
			@Assigned_by VARCHAR(20),
			@Assigned_to VARCHAR(20),
			@Created_by	VARCHAR(20),
			@Start_date VARCHAR(10),
			@End_date VARCHAR(10),
			@Comment VARCHAR(255),
			@retval VARCHAR(20) OUTPUT
) AS
BEGIN

DECLARE @Tag_id VARCHAR(20)
DECLARE @dt_start_date Date
DECLARE @dt_end_date Date

if @Start_date =''
	SET @dt_start_date=null
else
    SET @dt_start_date = @Start_date

if @end_date =''
	SET @dt_end_date=null
else
    SET @dt_end_date = @End_date 


exec dbo.sp_new_id @Tag_id OUTPUT

BEGIN TRAN
 
  INSERT INTO dbo.Tag(
				Tag_id,
				Tag_name,
				Project_id,
				Tag_type_id,
				Status_id,
				Priority_id,
				Assigned_user_id,
				Assigned_by,
				Assigned_to,
				Created_by,
				Created_date,
				Modified_by,
				Modified_date,
				Start_date,
				End_date,
				Comment
	)VALUES(
				  @Tag_id,
				  @Tag_name,
				  @Project_id,
				  @Tag_type_id,
				  @Status_id,
				  @Priority_id,
				  @Assigned_user_id,
				  @Assigned_by,
				  @Assigned_to,
				  @Created_by,
				  GETDATE(),
				  @Created_by,
				  GETDATE() ,
				   @dt_start_date,
				   @dt_end_date,
				   @Comment
			    )
  
 
 IF @@ERROR <> 0
 BEGIN
	 ROLLBACK TRAN
	 SET @retval='-1'
	 RETURN
 END
 
	 COMMIT TRAN
	 SET @retval=@Tag_id
	 RETURN
	 
 END 
 GO

 
 /***Object=Table dbo.sp_update_tag_wiz Script date:12/29/2011***/
 IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_update_tag_wiz') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_update_tag_wiz

 GO
 

 CREATE PROCEDURE dbo.sp_update_tag_wiz(

			@Tag_id	VARCHAR(20),
			@Tag_name	VARCHAR(100),
			@Project_id	VARCHAR(20),
			@Tag_type_id	INTEGER,
			@Status_id	INTEGER,
			@Priority_id	INTEGER,
			@Assigned_user_id	VARCHAR(20),
			@Assigned_by VARCHAR(20),
			@Assigned_to VARCHAR(20),
			@Modified_by VARCHAR(20),
			@Start_date VARCHAR(10),
			@End_date VARCHAR(10),
			@Comment  VARCHAR(255),
			@retval VARCHAR(20) OUTPUT
) AS  
 BEGIN
 
DECLARE @dt_start_date Date
DECLARE @dt_end_date Date

if @Start_date =''
	SET @dt_start_date=null
else
    SET @dt_start_date = @Start_date

if @end_date =''
	SET @dt_end_date=null
else
    SET @dt_end_date = @End_date 
 BEGIN TRAN
 
 UPDATE dbo.Tag SET     
	
			Tag_name=@Tag_name,
			Project_id=@Project_id,
			Tag_type_id=@Tag_type_id,
			Status_id=@Status_id,
			Priority_id=@Priority_id,
			Assigned_user_id=@Assigned_user_id,
			Assigned_by=@Assigned_by,
			Assigned_to=@Assigned_to,
			Modified_by=@Modified_by,
			Modified_date=GETDATE(),
			Start_date = @dt_start_date,
		    End_date = @dt_end_date,
			Comment=@Comment
WHERE       Tag_id=@Tag_id
 
IF @@ERROR <>0
BEGIN
		ROLLBACK TRAN
		SET @retval='-1'
		RETURN
END
  
		COMMIT TRAN
		SET @retval=0 
		RETURN
 
END
GO
/***Object=Table dbo.sp_delete_tag_wiz Script date:12/29/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_delete_tag_wiz') and  OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_delete_tag_wiz
GO

CREATE PROCEDURE dbo.sp_delete_tag_wiz(
    @Tag_id VARCHAR(20),
    @Modified_by VARCHAR(20),
	@retval INT OUTPUT
) AS 
BEGIN

BEGIN TRAN 
 
DELETE FROM dbo.Tag WHERE Tag_id=@Tag_id
    
IF @@ERROR <>0
BEGIN
		ROLLBACK TRAN
		SET @retval='-1'
		RETURN
END
 
		COMMIT TRAN
		SET @retval=0
		RETURN

END 
GO

/***Object=Table  dbo.sp_get_all_tag_comments Script date:12/29/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_all_tag_comments') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_all_tag_comments	
GO

CREATE PROCEDURE dbo.sp_get_all_tag_comments
AS
 BEGIN
	 SELECT * FROM dbo.view_all_tags_comment
 END
GO 
/***Object=Table  dbo.sp_get_tag_comment Script date:12/29/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_tag_comment') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_tag_comment
GO

CREATE PROCEDURE dbo.sp_get_tag_comment
				 @Tag_comment_id	UniqueIdentifier
AS
BEGIN
	SELECT * FROM dbo.view_all_tags_comment WHERE Tag_comment_id=@Tag_comment_id
END
GO

/***Object=Table dbo.sp_add_tag_to_comment Script date:12/29/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_add_tag_to_comment') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_add_tag_to_comment
GO

CREATE PROCEDURE dbo.sp_add_tag_to_comment(
			@Tag_id	VARCHAR(20),
			@Tag_comment	VARCHAR(500),
			@Created_by	VARCHAR(20),			
			@retval VARCHAR(20) OUTPUT
) AS
BEGIN

BEGIN TRAN
 
	INSERT INTO dbo.Tag_comments(			
			 Tag_id,
			 Tag_comment,
			 Created_by,
			 Created_date
	)VALUES(			 
			 @Tag_id,
			 @Tag_comment,
			 @Created_by,
			 GETDATE()
)
 
 IF @@ERROR <> 0
 BEGIN
		 ROLLBACK TRAN
		 SET @retval='-1'
		 RETURN
 END
 
		 COMMIT TRAN
		 SET @retval=0
		 RETURN
	 
 END 
 GO
 
 /***Object=Table dbo.sp_remove_tag_from_comment Script date:12/29/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_remove_tag_from_comment') and  OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_remove_tag_from_comment
GO

CREATE PROCEDURE dbo.sp_remove_tag_from_comment(
    @Tag_comment_id VARCHAR(20),
	@retval INT OUTPUT
) AS 
BEGIN

BEGIN TRAN 
 
	DELETE FROM dbo.Tag_comments WHERE Tag_comment_id=@Tag_comment_id
    
IF @@ERROR <>0
 BEGIN
	ROLLBACK TRAN
	SET @retval='-1'
	RETURN
 END
 
    COMMIT TRAN
    SET @retval=0
    RETURN

END
GO
/***Object=Table  dbo.sp_get_all_tag_comment_attachment Script date:12/29/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_all_tag_comment_attachment') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_all_tag_comment_attachment	
GO

CREATE PROCEDURE dbo.sp_get_all_tag_comment_attachment
AS

 BEGIN
	 SELECT * FROM dbo.view_all_tag_comment_attachment
 END
GO 
/***Object=Table  dbo.sp_get_tag_comment_attachment Script date:12/29/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_tag_comment_attachment') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_tag_comment_attachment
GO

CREATE PROCEDURE dbo.sp_get_tag_comment_attachment
				 @Tag_comment_id	VARCHAR(20)
AS
BEGIN
	SELECT * FROM dbo.view_all_tag_comment_attachment WHERE Tag_comment_id=@Tag_comment_id
END
GO

/***Object=Table dbo.sp_add_tag_to_comment_attachment Script date:12/29/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_add_tag_to_comment_attachment') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_add_tag_to_comment_attachment
GO

CREATE PROCEDURE dbo.sp_add_tag_to_comment_attachment(    
	@T_image	Image,
    @retval VARCHAR(20) OUTPUT
) AS
BEGIN

DECLARE @Tag_comment_id UniqueIdentifier

exec dbo.sp_new_id @Tag_comment_id OUTPUT

BEGIN TRAN
 
INSERT INTO dbo.Tag_comment_attachment(
		 Tag_comment_id,
		 T_image

 )VALUES(
		  @Tag_comment_id,
		  @T_image
  )
 
 IF @@ERROR <> 0
 BEGIN
		 ROLLBACK TRAN
		 SET @retval='-1'
		 RETURN
 END
 
		 COMMIT TRAN
		 SET @retval=0
		 RETURN
	 
 END 
 GO
 
 /***Object=Table dbo.sp_remove_tag_from_comment_attachment Script date:12/29/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_remove_tag_from_comment_attachment') and  OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_remove_tag_from_comment_attachment
GO

CREATE PROCEDURE dbo.sp_remove_tag_from_comment_attachment(
   
	@retval INT OUTPUT
) AS 
BEGIN
DECLARE @Tag_comment_id UniqueIdentifier
BEGIN TRAN 
 
	DELETE FROM dbo.Tag_comment_attachment WHERE Tag_comment_id=@Tag_comment_id
    
IF @@ERROR <>0
 BEGIN
	ROLLBACK TRAN
	SET @retval='-1'
	RETURN
 END
 
    COMMIT TRAN
    SET @retval=0
    RETURN

END  
GO
/***Object=Table  dbo.sp_get_all_tag_groups Script date:12/29/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_all_tag_groups') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_all_tag_groups
GO

CREATE PROCEDURE dbo.sp_get_all_tag_groups
AS
 BEGIN
	 SELECT * FROM dbo.view_all_tags_group
 END
GO 
/***Object=Table  dbo.sp_get_tag_group Script date:12/29/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_tag_group') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_tag_group
GO

CREATE PROCEDURE dbo.sp_get_tag_group
				 @Tag_group_id	VARCHAR(20)
AS
BEGIN
	SELECT * FROM dbo.view_all_tags_group WHERE Tag_group_id=@Tag_group_id
END
GO

/***Object=Table dbo.sp_create_tag_group_wiz Script date:12/29/2011***/

IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_create_tag_group_wiz') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_create_tag_group_wiz
GO

CREATE PROCEDURE dbo.sp_create_tag_group_wiz(
    
	@Tag_group_name	VARCHAR(100),
	@Created_by	VARCHAR(20),
    @Created_date	DATETIME,
    @Modified_by	VARCHAR(20),
    @Modified_date	DATETIME,
    @retval VARCHAR(20) OUTPUT
) AS
BEGIN

DECLARE @Tag_group_id	VARCHAR(20)

exec dbo.sp_new_id @Tag_group_id OUTPUT

BEGIN TRAN
 
 INSERT INTO dbo.Tag_Group(
	 Tag_group_id,
     Tag_group_name,
     Created_by,
     Created_date,
     Modified_by,
     Modified_date


  )VALUES(
	  @Tag_group_id,
      @Tag_group_name,
      @Created_by,
	  GETDATE(),
	  @Created_by,
	  GETDATE() 
  )
 
 IF @@ERROR <> 0
 BEGIN
	 ROLLBACK TRAN
	 SET @retval='-1'
	 RETURN
 END
 
	 COMMIT TRAN
	 SET @retval=0
	 RETURN
	 
 END 
 GO

 /***Object=Table dbo.sp_update_tag_group_wiz Script date:12/29/2011***/

 IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_update_tag_group_wiz') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_update_tag_group_wiz
 GO
 
 CREATE PROCEDURE dbo.sp_update_tag_group_wiz(
	@Tag_group_id	VARCHAR(20),
	@Tag_group_name	VARCHAR(100),
	@Created_by	VARCHAR(20),
    @Created_date	DATETIME,
    @Modified_by	VARCHAR(20),
    @Modified_date	DATETIME,
    @retval VARCHAR(20) OUTPUT
) AS  
 BEGIN
 
 BEGIN TRAN
 
 UPDATE dbo.Tag_Group SET     
	
     Tag_group_name=@Tag_group_name,
     Modified_by=@Modified_by,
	 Modified_date=GETDATE()
     
WHERE   Tag_group_id=@Tag_group_id
 
 IF @@ERROR <>0
  BEGIN
     ROLLBACK TRAN
     SET @retval='-1'
     RETURN
  END
  
     COMMIT TRAN
     SET @retval=0 
     RETURN
 
 END
 GO

 /***Object=Table dbo.sp_delete_tag_group_wiz Script date:12/29/2011***/

IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_delete_tag_Group_wiz') and  OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_delete_tag_group_wiz
GO

CREATE PROCEDURE dbo.sp_delete_tag_Group_wiz(
    @Tag_group_id	VARCHAR(20),
	@retval INT OUTPUT
) AS 
BEGIN

BEGIN TRAN 
 
	DELETE FROM dbo.Tag_Group WHERE Tag_group_id=@Tag_group_id
    
IF @@ERROR <>0
 BEGIN
	ROLLBACK TRAN
	SET @retval='-1'
	RETURN
 END
 
    COMMIT TRAN
    SET @retval=0
    RETURN

END  
GO
 /***Object=Table  dbo.sp_get_all_tag_group_x_tag Script date:12/29/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_all_tag_group_x_tag') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_all_tag_group_x_tag
GO

CREATE PROCEDURE dbo.sp_get_all_tag_group_x_tag
AS
 BEGIN
	 SELECT * FROM dbo.view_all_tags_by_group
 END
GO 
/***Object=Table  dbo.sp_get_tag_group_x_tag Script date:12/29/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_tag_group_x_tag') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_tag_group_x_tag
GO

CREATE PROCEDURE dbo.sp_get_tag_group_x_tag
				 @Tag_group_id	VARCHAR(20)
AS
BEGIN
	SELECT * FROM dbo.view_all_tags_by_group WHERE Tag_group_id=@Tag_group_id
END
GO

/***Object=Table dbo.sp_add_tag_to_tag_group Script date:12/29/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_add_tag_to_tag_group') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_add_tag_to_tag_group
GO

CREATE PROCEDURE dbo.sp_add_tag_to_tag_group(
    
	@Tag_id	VARCHAR(50),
    @retval VARCHAR(20) OUTPUT
) AS
BEGIN

DECLARE @Tag_group_id	VARCHAR(20)

exec dbo.sp_new_id @Tag_group_id OUTPUT

BEGIN TRAN
 
 INSERT INTO dbo.Tag_Group_X_Tag(
	 Tag_group_id,
     Tag_id


  )VALUES(
	  @Tag_group_id,
      @Tag_id
  )
 
 IF @@ERROR <> 0
 BEGIN
	 ROLLBACK TRAN
	 SET @retval='-1'
	 RETURN
 END
 
	 COMMIT TRAN
	 SET @retval=0
	 RETURN
	 
 END 
 GO
 
 /***Object=Table dbo.sp_remove_tag_from_tag_group Script date:12/29/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_remove_tag_from_tag_group') and  OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_remove_tag_from_tag_group
GO

CREATE PROCEDURE dbo.sp_remove_tag_from_tag_group(
    @Tag_group_id	VARCHAR(20),
	@retval INT OUTPUT
) AS 
BEGIN

BEGIN TRAN 
 
	DELETE FROM dbo.Tag_Group_X_Tag WHERE Tag_group_id=@Tag_group_id
    
IF @@ERROR <>0
 BEGIN
	ROLLBACK TRAN
	SET @retval='-1'
	RETURN
 END
 
    COMMIT TRAN
    SET @retval=0
    RETURN

END  
GO