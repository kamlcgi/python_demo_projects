

/****** Script: Create All LookUp Table Stored Procedures - PBill_db_xx	******/
/****** Author: Sreenivasan Subbanchattiar		******/
/****** Script Created By: Sreenivasan Subbanchattiar   	******/
/****** Script Created Date: 11/11/2011 			******/
/****** Script Modified By: Sreenivasan Subbanchattiar		******/
/****** Script Modified Date: 11/11/2011 	  		******/
/****** Script Version: 1.0  				******/


/****** Object:Stored Procedure   dbo.sp_get_all_users_lkup    Script Date: 11/11/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_users_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_users_lkup
GO

CREATE procedure dbo.sp_get_all_users_lkup
AS
begin

 SELECT User_id, (Last_name + ', ' + First_name) AS First_name FROM  dbo.view_all_users ORDER BY Last_name

end
GO

/****** Object:Stored Procedure   dbo.sp_get_all_contact_type_lkup  Script Date: 11/11/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_contact_type_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_contact_type_lkup
GO

CREATE procedure dbo.sp_get_all_contact_type_lkup
AS
begin

 SELECT * FROM  dbo.Contact_Type_LKUP

end
GO

/****** Object:Stored Procedure   dbo.sp_get_all_file_type_lkup  Script Date: 11/11/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_file_type_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_file_type_lkup
GO

CREATE procedure dbo.sp_get_all_file_type_lkup
AS
begin

 SELECT * FROM  dbo.File_Type_LKUP

end
GO