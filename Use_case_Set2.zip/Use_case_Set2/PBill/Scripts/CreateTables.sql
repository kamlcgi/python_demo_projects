/****** Database Name: PBill_db_xx  ******/
/****** Author:  Sreenivasan Subbanchattiar  ******/
/****** Script Created Date: 11/11/2011  ******/
/****** Script Modified Date: 11/11/2011  ******/
/****** Script Version: 1.0  ******/


/****** Database:  PBill_db_xx  ******/
USE PBill_db_xx
GO


/****** Object:  Table dbo.Contacts    Script Date: 11/11/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Contacts') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Contacts
GO

/****** Object:  Table dbo.Contact_Type_LKUP    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Contact_Type_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Contact_Type_LKUP
GO

/****** Object:  Table dbo.Sales    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Sales') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Sales
GO

/****** Object:  Table dbo.Sale_Description    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Sale_Description') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Sale_Description
GO

/****** Object:  Table dbo.Purchases    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Purchases') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Purchases
GO

/****** Object:  Table dbo.Purchase_Description    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Purchase_Description') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Purchase_Description
GO

/****** Object:  Table dbo.Transactions    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Transactions') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Transactions
GO

/****** Object:  Table dbo.Transaction_Mode_LKUP    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Transaction_Mode_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Transaction_Mode_LKUP
GO

/****** Object:  Table dbo.Transaction_Type_LKUP    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Transaction_Type_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Transaction_Type_LKUP
GO

/****** Object:  Table dbo.Products    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Products') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Products
GO

/****** Object:  Table dbo.Product_Images    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Product_Images') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Product_Images
GO

/****** Object:  Table dbo.Product_Type_LKUP    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Product_Type_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Product_Type_LKUP
GO

/****** Object:  Table dbo.File_Type_LKUP    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.File_Type_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.File_Type_LKUP
GO

/****** Object:  Table dbo.Tips    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Tips') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Tips
GO

/****** Object:  Table dbo.PAL_Users    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Users') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Users
GO

/****** Object:  Table dbo.PAL_Users_Log    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Users_Log') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Users_Log
GO

/****** Object:  Table dbo.PAL_Role    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Role') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Role
GO

/****** Object:  Table dbo.PAL_Page    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Page') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Page
GO

/****** Object:  Table dbo.PAL_Role_X_PAL_Page    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Role_X_PAL_Page') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Role_X_PAL_Page
GO

/****** Object:  Table dbo.T_PAL_Role_X_PAL_Page    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.T_PAL_Role_X_PAL_Page') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.T_PAL_Role_X_PAL_Page
GO

/****** Object:  Table dbo.PAL_Address    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Address') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Address
GO

/****** Object:  Table dbo.Country_LKUP    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Country_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Country_LKUP
GO

/****** Object:  Table dbo.State_LKUP    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.State_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.State_LKUP
GO

/****** Object:  Table dbo.Country_X_State    Script Date: 11/11/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Country_X_State') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Country_X_State
GO


/****** Object:  Table dbo.PAL_Identifiers    Script Date: 11/11/2011   ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Identifiers') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Identifiers
GO


/****** Object:  Table dbo.Contacts    Script Date: 11/11/2011  ******/
CREATE TABLE dbo.Contacts (
	Contact_id	Varchar(10) NOT NULL,
	Contact_short_name	Varchar(100) NULL,
	Contact_type_id	Int NULL,
	Contact_name	Varchar(100) NULL,
	Company_name	Varchar(100) NULL,
	Address_id	Varchar(10) NOT NULL,
	Created_by	Varchar(10) NULL,
	Created_date	Datetime NULL,
	Modified_by	Varchar(10) NULL,
	Modified_date	Datetime NULL,
        CONSTRAINT PK_Contacts PRIMARY KEY (Contact_id)  
) 
GO

/****** Object:  Table dbo.Contact_Type_LKUP    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.Contact_Type_LKUP (
	Contact_type_id Int NOT NULL,
	Contact_type_description varchar(50) NULL,	
        CONSTRAINT PK_Contact_Type_LKUP PRIMARY KEY (Contact_type_id)  
) 
GO

/****** Object:  Table dbo.Sales    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.Sales (
	Sale_id	Varchar(10) NOT NULL,
	Billing_Contact_id	Varchar(10) NULL,
	Shipping_Contact_id	Varchar(10) NULL,
	Invoice_no	Varchar(10) NULL,
	Invoice_date	Date NULL,
	Ref_no	Varchar(10) NULL,
	Due_date	Date NULL,
	Created_by	Varchar(10) NULL,
	Created_date	Datetime NULL,
	Modified_by	Varchar(10) NULL,
	Modified_date	Datetime NULL,
        CONSTRAINT PK_Sales PRIMARY KEY (Sale_id)  
) 
GO


/****** Object:  Table dbo.Sale_Description    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.Sale_Description (	
	Sale_description_id UniqueIdentifier NOT NULL,
	Sale_id	Varchar(10) NOT NULL,
	Item_no	Integer NULL,
	Product_id	Varchar(10) NOT NULL,
	Unit_cost	Money NOT NULL,
	Quantity	Integer	 NOT NULL,
        CONSTRAINT PK_Sale_Description PRIMARY KEY (Sale_description_id)  
) 
GO


/****** Object:  Table dbo.Purchases    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.Purchases (
	Purchase_id	Varchar(10) NOT NULL,
	Contact_id	Varchar(10) NOT NULL,
	Invoice_no	Varchar(10) NULL,
	Invoice_date	Date NULL,
	Ref_no	Varchar(10) NULL,
	Due_date	Date NULL,
	Created_by	Varchar(10) NULL,
	Created_date	Datetime NULL,
	Modified_by	Varchar(10) NULL,
	Modified_date	Datetime NULL,
        CONSTRAINT PK_Purchases PRIMARY KEY (Purchase_id)  
) 
GO


/****** Object:  Table dbo.Purchase_Description    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.Purchase_Description (	
	Purchase_description_id UniqueIdentifier NOT NULL,
	Purchase_id	Varchar(10) NOT NULL,
	Item_no	Integer NULL,
	Product_id	Varchar(10) NOT NULL,
	Unit_cost	Money NOT NULL,
	Quantity	Integer	 NOT NULL,
        CONSTRAINT PK_Purchase_Description PRIMARY KEY (Purchase_description_id)  
) 
GO

/****** Object:  Table dbo.Transactions    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.Transactions (	
	Transaction_id	UniqueIdentifier NOT NULL,
	Transaction_type_id	Int NULL,
	Transaction_ref_id	Varchar(10) NULL,
	Amount	Money NULL,
	Cheque_no	Varchar(10) NULL,
	Cheque_date	Date NULL,
	Bank_name	Varchar(100) NULL,
	Bank_branch	Varchar(100) NULL,
	Transcation_description	Varchar(100) NULL,
	Created_by	Varchar(10) NULL,
	Created_date	Datetime NULL,	
        CONSTRAINT PK_Transactions PRIMARY KEY (Transaction_id)  
) 
GO

/****** Object:  Table dbo.Transaction_Mode_LKUP    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.Transaction_Mode_LKUP (
	Transaction_mode_id Int NOT NULL,
	Transaction_mode_description Varchar(50) NULL,
        CONSTRAINT PK_Transaction_Mode_LKUP PRIMARY KEY (Transaction_mode_id)  
) 
GO

/****** Object:  Table dbo.Transaction_Type_LKUP    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.Transaction_Type_LKUP (
	Transaction_type_id Int NOT NULL,
	Transaction_type_description Varchar(50) NULL,
        CONSTRAINT PK_Transaction_Type_LKUP PRIMARY KEY (Transaction_type_id)  
) 
GO

/****** Object:  Table dbo.Products    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.Products (
	Product_id	Varchar(10) NOT NULL,
	Product_short_description	Varchar(100) NOT NULL,
	Product_description	Varchar(100) NULL,
	Product_type_id	Int NULL,
	Created_by	Varchar(10) NULL,
	Created_date	Datetime NULL,
	Modified_by	Varchar(10) NULL,
	Modified_date	Datetime NULL,
        CONSTRAINT PK_Products PRIMARY KEY (Product_id)  
) 
GO

/****** Object:  Table dbo.Product_Images   Script Date: 11/11/2011   ******/
CREATE TABLE dbo.Product_Images (
	Product_id	Varchar(10) NOT NULL,
	P_image	Image NOT NULL,
        CONSTRAINT PK_Product_Images PRIMARY KEY (Product_id)  
) 
GO

/****** Object:  Table dbo.Product_Type_LKUP    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.Product_Type_LKUP (
	Product_type_id Int NOT NULL,
	Product_type_description Varchar(50) NULL,
        CONSTRAINT PK_Product_Type_LKUP PRIMARY KEY (Product_type_id)  
) 
GO


/****** Object:  Table dbo.File_Type_LKUP    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.File_Type_LKUP (
	File_type_id Int NOT NULL,
	File_type_description Varchar(50) NULL,
        CONSTRAINT PK_File_Type_LKUP PRIMARY KEY (File_type_id)  
) 
GO

/****** Object:  Table dbo.Tips    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.Tips (
	Tip_id varchar(10) NOT NULL,
	Tip_name varchar(75) NULL,
	Tip_description varchar(500) NULL,
	File_type_id tinyint NULL,
	File_location varchar(50) NULL,
	Modified_by varchar(10) NULL,
	Modified_date datetime NULL,	
	Post char(1) NULL,
        CONSTRAINT PK_Tips PRIMARY KEY (Tip_id)  
) 
GO

/****** Object:  Table dbo.PAL_Users    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.PAL_Users (
	User_id varchar(10) NOT NULL,
	User_name varchar(50) NULL,
	Passwd varchar(50) NULL,
	First_name varchar(50) NULL,
	Last_name varchar(50) NULL,
	Active_user char(1) NULL,
	Role_id	 integer NOT NULL,
	Last_login_date datetime NULL,
	Address_id varchar(10) NULL,
	Created_by varchar(10) NULL,
	Created_date datetime NULL,
	Modified_by varchar(10) NULL,
	Modified_date datetime NULL,
	CONSTRAINT PK_PAL_Users PRIMARY KEY (User_id)  
) 
GO

/****** Object:  Table dbo.PAL_Role    Script Date: 11/11/2011  ******/
CREATE TABLE dbo.PAL_Role (
	Role_id	 integer NOT NULL,
	Role_name	varchar(50) NULL,
	Created_by	varchar(10) NULL,
	Created_date	datetime NULL,
	Modified_by	varchar(10) NULL,
	Modified_date	Datetime NULL,
	CONSTRAINT PK_PAL_Role  PRIMARY KEY (Role_id)	
) 
GO

/****** Object:  Table dbo.PAL_Page    Script Date: 11/11/2011  ******/
CREATE TABLE dbo.PAL_Page (
	Page_id	 integer NOT NULL,
	Parent_Page_id	integer NULL,
	Page_title	varchar(50) NULL,
	Navigate_url	varchar(50) NULL,
	Page_description	varchar(255) NULL,
	Created_by	varchar(10) NULL,
	Created_date	datetime NULL,
	Modified_by	varchar(10) NULL,
	Modified_date	Datetime NULL,
	CONSTRAINT PK_PAL_Page PRIMARY KEY (Page_id)	
) 
GO

/****** Object:  Table dbo.PAL_Role_X_PAL_Page    Script Date: 11/11/2011  ******/
CREATE TABLE dbo.PAL_Role_X_PAL_Page (
	Role_id	integer NOT NULL,	
    Page_id	integer NOT NULL,
	Sort_index	smallint NULL,
	Allow_view char(1) NULL,
	Allow_modify char(1) NULL,
	Allow_delete char(1) NULL,
	CONSTRAINT PK_PAL_Role_X_PAL_Page PRIMARY KEY (Role_id,Page_id)	
) 
GO

/****** Object:  Table dbo.T_PAL_Role_X_PAL_Page    Script Date: 11/11/2011  ******/
CREATE TABLE dbo.T_PAL_Role_X_PAL_Page (
	Role_id	integer NOT NULL,	
    Page_id	integer NOT NULL,
    Modified_by varchar(20) NOT NULL,
	Sort_index	smallint NULL,
	Allow_view char(1) NULL,
	Allow_modify char(1) NULL,
	Allow_delete char(1) NULL,	
	CONSTRAINT PK_T_PAL_Role_X_PAL_Page PRIMARY KEY (Role_id,Page_id,Modified_by)	
) 
GO
	
/****** Object:  Table dbo.PAL_Users_Log    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.PAL_Users_Log (
	Log_id uniqueidentifier NOT NULL DEFAULT NEWID(),
	IP_address  varchar(50) NULL,
	Browser  varchar(500) NULL,
	Log_data varchar(2000) NULL,
	Log_by varchar(10) NULL,
	Log_date datetime NULL,	
	CONSTRAINT PK_PAL_Users_Log PRIMARY KEY (Log_id)  
) 
GO

/****** Object:  Table dbo.Pal_Address    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.Pal_Address (
	Address_id varchar(10) NOT NULL,
	Address1 varchar(100) NULL,
	Address2 varchar(100) NULL,
	City varchar(50) NULL,
	State_id int NULL,
	Zip varchar(50) NULL,
	Country_id int NULL,
	Phone varchar(50) NULL,
	Mobile varchar(50) NULL,
	Fax varchar(50) NULL,
	Email varchar(50) NULL,
	Website varchar(50) NULL,
	CONSTRAINT PK_Pal_Address PRIMARY KEY (Address_id)  
) 
GO

/****** Object:  Table dbo.Country_LKUP    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.Country_LKUP (
	Country_id int NOT NULL,
	Country_name varchar(50) NULL,
	Country_code varchar(2) NULL,
	CONSTRAINT PK_Country_LKUP PRIMARY KEY (Country_id)  
	) 
GO

/****** Object:  Table dbo.State_LKUP    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.State_LKUP (	
	State_id int NOT NULL,
	State_name varchar(50) NULL,
	State_code varchar(2) NULL,
	CONSTRAINT PK_State_LKUP PRIMARY KEY (State_id)  
	) 
GO

/****** Object:  Table dbo.Country_X_State    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.Country_X_State (
	Country_id int  NOT NULL,
	State_id int NOT NULL, 
	CONSTRAINT PK_Country_X_State PRIMARY KEY (Country_id,State_id)  
	) 
GO


/****** Object:  Table dbo.PAL_Identifiers    Script Date: 11/11/2011   ******/
CREATE TABLE dbo.PAL_Identifiers (
	PAL_id varchar(4) NOT NULL,
	New_id int NOT NULL,	
) 
GO
