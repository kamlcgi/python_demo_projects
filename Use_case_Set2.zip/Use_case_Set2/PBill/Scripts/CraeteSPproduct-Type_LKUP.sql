/****** Database Name:  PEvudeExamples  ******/
/****** Author:  Srinivasan  ******/
/****** Script Created Date: 14/11/2011  ******/
/****** Script Modified Date: 14/11/2011  ******/
/****** Script Version: 1.0  ******/
/****** Project: PRODUCT******/



/****** Object:  Store procedure:  dbo.sp_get_all_Product_Type_LKUP    Script Date: 14/11/2011  ******/

IF exists (SELECT * FROM dbo.sysobjects WHERE id= object_id(N'dbo.sp_get_all_Product_Type_LKUP  ')and objectproperty(id,N'Isprocedure')=1)
	DROP PROCEDURE dbo.sp_get_all_Product_Type_LKUP 
GO

CREATE PROCEDURE dbo.sp_get_all_Product_Type_LKUP 
AS 
BEGIN 
	SELECT * FROM dbo.Product_Type_LKUP 
END
GO 

 
 /***Object=Table  dbo.sp_get_product Script Date:14/11/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_product_type_lkup') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_product_type_lkup
GO

CREATE PROCEDURE dbo.sp_get_product_type_lkup
				 @Product_type_id	int
AS
BEGIN
	SELECT * FROM dbo.Product_Type_LKUP WHERE Product_type_id=@Product_type_id
END
GO
 



/***Object=Table dbo.sp_insert_Product_Type_LKUP Script Date:14/11/2011***/

IF exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_create_Product_Type_LKUP') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
DROP PROCEDURE dbo.sp_create_Product_Type_LKUP
GO

 
CREATE procedure dbo.sp_create_Product_Type_LKUP(
  
	@Product_type_description Varchar(50),
	@Created_by varchar(20),
	@retval varchar(20) output
	)
As
BEGIN


declare @Product_type_id int
 
SELECT @Product_type_id=MAX(@Product_type_id)+1 FROM dbo.Product_Type_LKUP


BEGIN TRAN

 INSERT INTO dbo.Product_Type_LKUP(
		 Product_type_id,
		 Product_type_description)
	 	
 values(
		 @Product_type_id,
		 @Product_type_description )
 
 IF @@ERROR <> 0
 BEGIN
 rollback TRAN
 SET @retval='-1'
 RETURN
 END
 COMMIT TRAN
 set @retval=0
 RETURN
 END 
 GO
 
  /***Object=Table dbo.sp_update_Product_Type_LKUP Script Date:14/11/2011***/
 IF exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_update_Product_Type_LKUP') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
 DROP procedure dbo.sp_update_Product_Type_LKUP
 GO
 CREATE procedure dbo.sp_update_Product_Type_LKUP
 (
    @Product_type_id Int ,
	@Product_type_description Varchar(50),
	
	@retval varchar(20) output)
	
 
 AS
 
 BEGIN
 BEGIN TRAN
 UPDATE dbo.Product_Type_LKUP SET
 
	Product_type_description=@Product_type_description 
	
 WHERE   Product_type_id=@Product_type_id 
 
  IF @@ERROR <>0
       BEGIN
       rollback TRAN
       set @retval='-1'
       RETURN
 END
 COMMIT TRAN
 
    set @retval=0 
    
 RETURN
 
 END
 GO
  /***Object=Table dbo.sp_delete_Product_Type_LKUP Script Date:14/11/2011**/

 IF exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_delete_Product_Type_LKUP') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
 DROP procedure dbo.sp_delete_Product_Type_LKUP
 GO
 
 CREATE procedure dbo.sp_delete_Product_Type_LKUP
 (
    @Product_type_id Int,
	@retval int output
)
 AS 
 BEGIN


 
BEGIN TRAN 
 
    DELETE dbo.Product_Type_LKUP
    WHERE   Product_type_id=@Product_type_id 
    
 IF @@ERROR <>0
            BEGIN
            rollback TRAN
            set @retval='-1'
            RETURN
 END
 
 COMMIT TRAN
 
        set @retval=0
         RETURN
 END
 
 GO

 