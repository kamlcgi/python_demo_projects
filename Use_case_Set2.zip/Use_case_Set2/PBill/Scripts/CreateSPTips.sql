/****** Script Created By: Arpita das   	******/
/****** Script Created Date: 14/11/2011 			******/
/****** Script Modified By: Arpita das		******/
/****** Script Modified Date: 14/11/2011 	  		******/
/****** Script Version: 1.0  				******/

/******Database: PEvudeExamples ******/

/******object: Table dbo.sp_get_all_tips Script Date: 14/11/2011 ******/
USE PBill_db_10
GO


IF exists (SELECT * FROM dbo.sysobjects WHERE id= object_id(N'sp_get_all_tips ')and objectproperty(id,N'isPROCEDURE')=1)
	DROP PROCEDURE dbo.sp_get_all_tips
GO

CREATE PROCEDURE dbo.sp_get_all_tips	
AS 
BEGIN 

	SELECT * FROM dbo.view_all_tips
    
END
GO 

/****** Object:Stored PROCEDURE   dbo.sp_get_tips   Script Date: 14/11/2011 	  ******/
IF exists (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'dbo.sp_get_tips') and OBJECTPROPERTY(id, N'IsPROCEDURE') = 1)
DROP PROCEDURE  dbo.sp_get_tips
GO

CREATE PROCEDURE  dbo.sp_get_tips
        @Tip_id AS varchar(10)
AS
BEGIN
  
  SELECT * FROM  dbo.view_all_tips  WHERE Tip_id = @Tip_id 
  
 END
GO 

/******object: Table dbo.sp_insert_tips  Script Date: 14/11/2011 ******/

IF exists (SELECT * FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_insert_tips_wiz')
and OBJECTPROPERTY(id,N'IsPROCEDURE')=1)
DROP PROCEDURE dbo.sp_insert_tips_wiz
GO

CREATE PROCEDURE dbo.sp_insert_tips_wiz
	@Tip_id varchar(10) ,
	@Tip_name varchar(75),
	@Tip_description varchar(500),
	@File_type_id tinyint ,
	@File_location varchar(50),
	@Modified_by varchar(10),
	@Modified_date datetime,	
	@Post char(1),
	@retval Varchar(20) output

AS
BEGIN
BEGIN TRAN


INSERT INTO dbo.Tips

(Tip_id,Tip_name,Tip_description,File_type_id,File_location,Modified_by,Modified_date,Post)
VALUES(@Tip_id,@Tip_name,@Tip_description,@File_type_id,@File_location,@Modified_by,@Modified_date,@Post)
if @@ERROR<>0
BEGIN
ROLLBACK TRAN
SET @retval='-1'
RETURN
END
COMMIT TRAN
SET @retval=@Tip_id
RETURN
END
GO

/******object: Table dbo.sp_update_tips  Script Date: 14/11/2011 ******/
IF exists (SELECT * FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_update_tips_wiz')
and OBJECTPROPERTY(id,N'IsPROCEDURE')=1)
DROP PROCEDURE dbo.sp_update_tips_wiz
GO

CREATE PROCEDURE dbo.sp_update_tips_wiz(
	@Tip_id varchar(10) ,
	@Tip_name varchar(75),
	@Tip_description varchar(500),
	@File_type_id tinyint ,
	@File_location varchar(50),
	@Modified_by varchar(10),
	@Modified_date datetime,	
	@Post char(1),
	@retval Varchar(20) output
)
AS
BEGIN
BEGIN TRAN


UPDATE dbo.Tips SET
	Tip_id=@Tip_id, 
	Tip_name =@Tip_name ,
	Tip_description =@Tip_description ,
	File_type_id=@File_type_id ,
	File_location=@File_location,
	Modified_by=@Modified_by ,
	Modified_date =@Modified_date ,
	Post=@Post
	
	
WHERE Tip_id=@Tip_id

IF @@ERROR <>0
	BEGIN
		ROLLBACK TRAN
		SET @retval='-1'
		RETURN
	END
	
COMMIT TRAN
SET @retval = 0
RETURN

END
GO


/******object: Table dbo.sp_delete_tips  Script Date: 14/11/2011 ******/
IF exists (SELECT * FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_delete_tips_wiz')
and OBJECTPROPERTY(id,N'IsPROCEDURE')=1)
DROP PROCEDURE dbo.sp_delete_tips_wiz
GO

CREATE PROCEDURE dbo.sp_delete_tips_wiz(
@Tip_id varchar(10),
@retval Varchar(20) output)


AS
BEGIN

BEGIN TRAN

DELETE dbo.Tips
WHERE Tip_id=@Tip_id
IF @@ERROR <>0

BEGIN

ROLLBACK TRAN
SET @retval='-1'
RETURN
END
COMMIT TRAN
SET @retval = 0
RETURN


END
GO