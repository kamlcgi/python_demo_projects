/****** Database Name:  PEvudeExamples  ******/
/****** Author:  Srinivasan  ******/
/****** Script Created Date: 14/11/2011  ******/
/****** Script Modified Date: 14/11/2011  ******/
/****** Script Version: 1.0  ******/
/****** Project: PRODUCT******/



/****** Object:  Store Procedure:  dbo.sp_get_all_Product_Image    Script Date: 14/11/2011  ******/

IF exists (SELECT * FROM dbo.sysobjects WHERE id= object_id(N'dbo.sp_get_all_Product_Image  ')and objectproperty(id,N'Isprocedure')=1)
	DROP PROCEDURE dbo.sp_get_all_Product_Images
GO

CREATE PROCEDURE dbo.sp_get_all_Product_Images 
AS 
BEGIN 
	SELECT * FROM dbo.view_all_Products
END
GO 
/***Object=Table dbo.sp_insert_Product_Images Script Date:14/11/2011***/

if exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_insert_Product_Images') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
drop procedure dbo.sp_insert_Product_Images
Go

CREATE procedure dbo.sp_insert_Product_Images(
    @Product_id	Varchar(10),
	@P_image	Image,
	
	@retval varchar(20) output)
	
As
begin
begin tran
 
 INSERT INTO dbo.Product_Images(Product_id,P_image)
 	
 values(@Product_id,@P_image)
 
 if @@ERROR <> 0
 begin
 rollback tran
 set @retval='-1'
 return
 end
 commit tran
 set @retval=0
 return
 end 
 Go
  /***Object=Table dbo.sp_update_Product_Images Script Date:14/11/2011***/
 if exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_update_Product_Images') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
 drop procedure dbo.sp_update_Product_Images
 GO
 CREATE procedure dbo.sp_update_Product_Images
 (
    @Product_id	Varchar(10),
	@P_image	Image,
	
	@retval varchar(20) output)
	
 
 as 
 
 begin
 begin tran
 UPDATE dbo.Product_Images SET
 
    Product_id=@Product_id,
	P_image=@P_image 
	
 WHERE   Product_id=@Product_id
 
  if @@ERROR <>0
       begin
       rollback tran
       set @retval='-1'
       return
 end
 commit tran
 
    set @retval=0 
    
 return
 
 end
 Go
 /***Object=Table dbo.sp_delete_Product_Images Script Date:14/11/2011***/

 if exists(select*from dbo.sysobjects where id=object_id(N'dbo.sp_delete_Product_Images') and
 OBJECTPROPERTY(id,N'IsProcedure')=1)
 drop procedure dbo.sp_delete_Product_Images
 GO
 
 CREATE procedure dbo.sp_delete_Product_Images 
 (
    @Product_id Varchar(10),
	@retval int output
)
 as 
 BEGIN

begin tran 
 
    DELETE dbo.Product_Images
    WHERE Product_id=@Product_id
    
 if @@ERROR <>0
            begin
            rollback tran
            set @retval='-1'
            return
 end
 
 commit tran
 
        set @retval=0
 end
 
 Go

 
 