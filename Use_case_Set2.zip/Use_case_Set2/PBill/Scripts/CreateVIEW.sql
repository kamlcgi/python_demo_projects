
/****** Description: All Views Create and Drop Scripts For PBill_db_xx  ******/
/****** Author:  Sreenivasan Subbanchattiar  ******/
/****** Script Created Date: 11/11/2011  ******/
/****** Script Modified Date: 11/11/2011   ******/
/****** Script Version: 1.0  ******/


/****** Object:  View dbo.view_all_sales   Script Date: 14/11/2011  ******/


if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_sales') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_sales
GO

CREATE VIEW dbo.view_all_sales
AS
SELECT	dbo.Sales.Sale_id, dbo.Sales.Billing_Contact_id, dbo.Sales.Shipping_Contact_id, dbo.Sales.Invoice_no, 
        dbo.Sales.Invoice_date, dbo.Sales.Ref_no, dbo.Sales.Due_date, 
        dbo.Sale_Description.Sale_description_id,dbo.Sale_Description.Item_no,
        dbo.Sale_Description.Product_id,dbo.Sale_Description.Unit_cost,dbo.Sale_Description.Quantity
      
FROM    dbo.Sales 
		LEFT OUTER JOIN dbo.Sale_Description ON dbo.Sales.Sale_id = dbo.Sale_Description.Sale_id
		
GO	
	
/****** Object:  View dbo.view_all_transaction   Script Date: 14/11/2011  ******/


if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_transaction') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_transaction
GO

CREATE VIEW dbo.view_all_transaction
AS
SELECT	dbo.Transactions.Transaction_id, dbo.Transactions.Transaction_type_id, dbo.Transactions.Transaction_ref_id, dbo.Transactions.Amount, 
        dbo.Transactions.Cheque_no, dbo.Transactions.Cheque_date, dbo.Transactions.Bank_name, 
        dbo.Transactions.Bank_branch,dbo.Transactions.Transcation_description,
        dbo.Transactions.Created_by,dbo.Transactions.Created_date,
        dbo.Transaction_Type_LKUP.Transaction_type_description
      
FROM    dbo.Transactions 
		LEFT OUTER JOIN dbo.Transaction_Type_LKUP ON dbo.Transactions.Transaction_type_id = dbo.Transaction_Type_LKUP.Transaction_type_id
		
		
GO	

/****** Object:  View dbo.view_all_tips  Script Date: 14/11/2011  ******/

if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_tips') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_tips
GO
CREATE VIEW dbo.view_all_tips
AS
SELECT  dbo.Tips.Tip_id,dbo.Tips.Tip_name,dbo.Tips.Tip_description,
dbo.Tips.File_type_id,dbo.Tips.File_location,dbo.Tips.Modified_by,
dbo.Tips.Modified_date,dbo.Tips.Post,dbo.File_Type_LKUP.File_type_description
from dbo.Tips
      LEFT OUTER JOIN dbo.File_Type_LKUP ON dbo.Tips.File_type_id = dbo.File_Type_LKUP.File_type_id
GO

/****** Object:  View dbo.view_all_Products  Script Date: 14/11/2011  ******/

if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_Products') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_Products
GO

CREATE VIEW dbo.view_all_Products
AS


SELECT dbo.Products.Product_id,dbo.Products.Product_short_description,dbo.Products.Product_description,dbo.Products.Product_type_id,
       dbo.Products.Created_by,dbo.Products.Created_date,dbo.Products.Modified_by,dbo.Products.Modified_date,
       dbo.Product_Type_LKUP.Product_type_description,dbo.Product_Images.P_image

 
FROM   dbo.Products

LEFT OUTER JOIN dbo.Product_Type_LKUP ON dbo.Products.Product_type_id = dbo.Product_Type_LKUP.Product_type_id
LEFT OUTER JOIN dbo.Product_Images ON dbo.Products.Product_id = dbo.Product_Images.Product_id
GO

/****** Object:  View dbo.view_all_Purchases   Script Date: 11/11/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_Purchases') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_Purchases
GO

CREATE VIEW dbo.view_all_Purchases
AS
SELECT	dbo.Purchases.Purchase_id, dbo.Purchases.Contact_id, dbo.Purchases.Invoice_no, dbo.Purchases.Invoice_date, 
        dbo.Purchases.Ref_no, dbo.Purchases.Due_date, dbo.Purchases.Created_by, 
        dbo.Purchases.Created_date, dbo.Purchases.Modified_by, dbo.Purchases.Modified_date, 
        
        
        dbo.Purchase_Description.Purchase_description_id, 
         dbo.Purchase_Description.Item_no, dbo.Purchase_Description.Product_id, dbo.Purchase_Description.Unit_cost, dbo.Purchase_Description.Quantity
FROM    dbo.Purchases 

		LEFT OUTER JOIN dbo.Purchase_Description ON dbo.Purchases.Purchase_id = dbo.Purchase_Description.Purchase_id 
		
GO

/****** Object:  View dbo.view_all_sales_wiz  Script Date: 11/11/2011  ******/	
SELECT     dbo.Contacts.Contact_id, dbo.Contacts.Contact_short_name, dbo.Contacts.Contact_type_id, dbo.Contacts.Contact_name, dbo.Contacts.Company_name, 
                      dbo.Contacts.Address_id, dbo.Contacts.Created_by AS Expr1, dbo.Contacts.Created_date AS Expr2, dbo.Contacts.Modified_date AS Expr3, 
                      dbo.Contacts.Modified_by AS Expr4, dbo.Sales.Sale_id, dbo.Sales.Billing_Contact_id, dbo.Sales.Shipping_Contact_id, dbo.Sales.Invoice_no, 
                      dbo.Sales.Invoice_date, dbo.Sales.Ref_no, dbo.Sales.Due_date, dbo.Sales.Created_by, dbo.Sales.Created_date, dbo.Sales.Modified_by, 
                      dbo.Sales.Modified_date
FROM         dbo.Contacts INNER JOIN
                      dbo.Sales ON dbo.Contacts.Contact_id = dbo.Sales.Billing_Contact_id	
                      
 
 /****** Object:  View dbo.view_all_purchase_wiz  Script Date: 11/11/2011  ******/	
 SELECT     dbo.Contacts.Contact_id AS Expr2, dbo.Purchases.Contact_id AS Expr1, dbo.Contacts.Contact_short_name, dbo.Contacts.Contact_type_id, 
                      dbo.Contacts.Contact_name, dbo.Contacts.Company_name, dbo.Contacts.Address_id, dbo.Contacts.Created_by, dbo.Contacts.Created_date, 
                      dbo.Contacts.Modified_by, dbo.Contacts.Modified_date, dbo.Purchases.Purchase_id, dbo.Purchases.Invoice_no, dbo.Purchases.Invoice_date, 
                      dbo.Purchases.Ref_no, dbo.Purchases.Due_date, dbo.Purchases.Created_by AS Expr3, dbo.Purchases.Created_date AS Expr4, 
                      dbo.Purchases.Modified_by AS Expr5, dbo.Purchases.Modified_date AS Expr6
FROM         dbo.Contacts INNER JOIN
                      dbo.Purchases ON dbo.Contacts.Contact_id = dbo.Purchases.Contact_id
                    
   /****** Object:  View dbo.view_all_transaction_wiz  Script Date: 11/11/2011  ******/	
   SELECT     dbo.Transactions.Transaction_id AS Expr1, dbo.Transactions.*, dbo.Transactions.Transaction_type_id AS Expr2, 
                      dbo.Transactions.Transaction_ref_id AS Expr3, dbo.Transactions.Amount AS Expr4, dbo.Transactions.Cheque_no AS Expr5, 
                      dbo.Transactions.Cheque_date AS Expr6, dbo.Transactions.Bank_name AS Expr7, dbo.Transactions.Bank_branch AS Expr8, 
                      dbo.Transactions.Transcation_description AS Expr9, dbo.Transactions.Created_by AS Expr10, dbo.Transactions.Created_date AS Expr11, 
                      dbo.Sales.Sale_id, dbo.Sales.Billing_Contact_id, dbo.Sales.Shipping_Contact_id, dbo.Sales.Invoice_no AS Expr14, dbo.Sales.Invoice_date AS Expr15, 
                      dbo.Sales.Ref_no AS Expr16, dbo.Sales.Due_date AS Expr17, dbo.Sales.Created_by AS Expr12, dbo.Sales.Created_date AS Expr13, 
                      dbo.Sales.Modified_by AS Expr18, dbo.Sales.Modified_date AS Expr19
FROM         dbo.Transactions INNER JOIN
                      dbo.Sales ON dbo.Transactions.Transaction_id = dbo.Sales.Sale_id