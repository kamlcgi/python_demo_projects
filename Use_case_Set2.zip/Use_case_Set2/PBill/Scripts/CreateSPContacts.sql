	

/****** Script: New/Update/Delete contacts - PBill_db_xx	******/
/****** Author: Sreenivasan Subbanchattiar		******/
/****** Script Created By: Sreenivasan Subbanchattiar   	******/
/****** Script Created Date: 11/14/2011 			******/
/****** Script Modified By: Sreenivasan Subbanchattiar		******/
/****** Script Modified Date: 11/14/2011 	  		******/
/****** Script Version: 1.0  				******/


/****** Object:Stored Procedure   dbo.sp_get_all_contacts    Script Date: 11/14/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_contacts') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_contacts
GO

CREATE procedure dbo.sp_get_all_contacts
AS
begin

 SELECT * FROM dbo.view_all_contacts  

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_contact    Script Date: 11/14/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_contact') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure  dbo.sp_get_contact
GO

CREATE procedure  dbo.sp_get_contact
        @contact_id as varchar(20)
AS
begin
  
  SELECT * FROM  dbo.view_all_contacts  WHERE contact_id = @contact_id 
  
 end
GO 


/****** Object:Stored Procedure   dbo.sp_create_contact_wiz    Script Date: 011/14/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_create_contact_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_create_contact_wiz
GO

create procedure dbo.sp_create_contact_wiz( 
	@Contact_short_name	Varchar(100),
	@Contact_type_id	Int,
	@Contact_name	Varchar(100),
	@Company_name	Varchar(100),	
	@address1 varchar(50),
	@address2 varchar(50),
	@city varchar(50),
	@state_id int,
	@zip varchar(50),
	@country_id int,
	@phone varchar(50),
	@mobile varchar(50),
	@fax varchar(50),
	@email varchar(50),	
	@website varchar(50),	
	@created_by varchar(10),
	@retval varchar(10) OUTPUT)
as
begin

declare @contact_id varchar(20)
declare @address_id varchar(20)

exec dbo.sp_new_id @contact_id OUTPUT
exec dbo.sp_new_id @address_id OUTPUT

begin tran

exec dbo.sp_new_address	
		@address_id ,
		@address1 ,
		@address2 ,
		@city ,
		@state_id,
		@zip,
		@country_id,
		@phone,
		@mobile,
		@fax,
		@email,
		@website
		
		
INSERT INTO dbo.Contacts(
		contact_id,
		Contact_short_name,
		Contact_type_id,
		Contact_name,
		Company_name,
		Address_id,
		Created_by,
		Created_date,
		Modified_by,
		Modified_date
)VALUES(
		@contact_id,
	    @Contact_short_name,
		@Contact_type_id,
		@Contact_name,
		@Company_name,
	    @address_id,	    
	    @created_by,
		GETDATE(),
	    @created_by,
		GETDATE()
)          	
     
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = @contact_id
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_update_contact_wiz    Script Date: 011/14/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_update_contact_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_update_contact_wiz
GO

create procedure dbo.sp_update_contact_wiz( 
	@contact_id varchar(20),
	@Contact_short_name	Varchar(100),
	@Contact_type_id	Int,
	@Contact_name	Varchar(100),
	@Company_name	Varchar(100),	
	@address1 varchar(50),
	@address2 varchar(50),
	@city varchar(50),
	@state_id int,
	@zip varchar(50),
	@country_id int,
	@phone varchar(50),
	@mobile varchar(50),
	@fax varchar(50),
	@email varchar(50),	
	@website varchar(50),	
	@modified_by varchar(20),
	@retval int OUTPUT)
as
begin

declare @address_id varchar(20)

 SELECT @address_id=address_id FROM dbo.contacts WHERE contact_id=@contact_id 

begin tran

exec dbo.sp_update_address	
		@address_id ,
		@address1 ,
		@address2 ,
		@city ,
		@state_id,
		@zip,
		@country_id,
		@phone,
		@mobile,
		@fax,
		@email,
		@website
		
	UPDATE dbo.Contacts SET
		Contact_short_name=@Contact_short_name,
		Contact_type_id=@Contact_type_id,
		Contact_name=@Contact_name,	
		Company_name=@Company_name,	    
		Modified_by = @modified_by,
        Modified_date = GETDATE()  
	WHERE contact_id = @contact_id
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_delete_contact_wiz    Script Date: 11/14/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_delete_contact_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_delete_contact_wiz
GO

CREATE procedure dbo.sp_delete_contact_wiz(
			@contact_id  varchar(20),
			@modified_by varchar(20),
			@retval int OUTPUT)
AS
begin

 declare @address_id varchar(20)

 SELECT @address_id=address_id FROM dbo.contacts WHERE contact_id=@contact_id 
 
 begin tran
 
 DELETE FROM  dbo.Pal_Address WHERE address_id=@address_id 
 
 DELETE FROM  dbo.contacts WHERE contact_id=@contact_id 
 
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 
