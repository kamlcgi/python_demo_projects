
/****** Object:  View dbo.view_all_tips  Script Date: 14/11/2011  ******/

IF exists (SELECT * FROM dbo.sysobjects where id = object_id(N'dbo.view_all_tips') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_tips
GO
CREATE VIEW dbo.view_all_tips
AS
SELECT  dbo.Tips.Tip_id,dbo.Tips.Tip_name,dbo.Tips.Tip_description,
dbo.Tips.File_type_id,dbo.Tips.File_location,dbo.Tips.Modified_by,
dbo.Tips.Modified_date,dbo.Tips.Post,dbo.File_Type_LKUP.File_type_description
FROM dbo.Tips
      LEFT OUTER JOIN dbo.File_Type_LKUP ON dbo.Tips.File_type_id = dbo.File_Type_LKUP.File_type_id
GO