
/****** Description: All Views Create and Drop Scripts For PBill_db_xx  ******/
/****** Author:  Sreenivasan Subbanchattiar  ******/
/****** Script Created Date: 11/11/2011  ******/
/****** Script Modified Date: 11/11/2011   ******/
/****** Script Version: 1.0  ******/


/****** Object:  View dbo.view_created_by    Script Date: 11/11/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_created_by') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_created_by
GO

CREATE VIEW dbo.view_created_by
AS
SELECT   User_id, First_name + ' ' + Last_name AS Created_by
FROM     dbo.PAL_Users
GO

/****** Object:  View dbo.view_modified_by    Script Date: 11/11/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_modified_by') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_modified_by
GO

CREATE VIEW dbo.view_modified_by
AS
SELECT   User_id, First_name + ' ' + Last_name AS Modified_by
FROM     dbo.PAL_Users
GO

/****** Object:  View dbo.view_requested_by    Script Date: 11/11/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_requested_by') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_requested_by
GO

CREATE VIEW dbo.view_requested_by
AS
SELECT   User_id, First_name + ' ' + Last_name AS Requested_by
FROM     dbo.PAL_Users
GO

/****** Object:  View dbo.view_all_user_logs    Script Date: 11/11/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_user_logs') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_user_logs
GO

CREATE VIEW dbo.view_all_user_logs
AS
SELECT	dbo.PAL_Users_Log.Log_id, dbo.PAL_Users_Log.IP_address, dbo.PAL_Users_Log.Browser, dbo.PAL_Users_Log.Log_data, dbo.view_created_by.Created_by, 
        dbo.PAL_Users_Log.Log_date, dbo.PAL_Users_Log.Log_by
FROM	dbo.PAL_Users_Log 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.PAL_Users_Log.Log_by = dbo.view_created_by.User_id
go      
         
/****** Object:  View dbo.view_all_roles    Script Date: 11/11/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_roles') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_roles
GO

CREATE VIEW dbo.view_all_roles
AS
SELECT	dbo.PAL_Role.Role_id, dbo.PAL_Role.Role_name, dbo.view_created_by.Created_by, dbo.PAL_Role.Created_date, 
        dbo.view_modified_by.Modified_by, dbo.PAL_Role.Modified_date
FROM    dbo.PAL_Role 
		LEFT OUTER JOIN   dbo.view_modified_by ON dbo.PAL_Role.Modified_by = dbo.view_modified_by.User_id 
		LEFT OUTER JOIN	  dbo.view_created_by ON dbo.PAL_Role.Created_by = dbo.view_created_by.User_id
GO


/****** Object:  View dbo.view_all_pages   Script Date: 11/11/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_pages') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_pages
GO

CREATE VIEW dbo.view_all_pages
AS
SELECT	dbo.PAL_Page.Page_id, dbo.PAL_Page.Parent_Page_id, dbo.PAL_Page.Page_title, PAL_Page_1.Page_title AS Parent_page_title, 
        dbo.PAL_Page.Navigate_url, dbo.PAL_Page.Page_description, dbo.view_created_by.Created_by, dbo.PAL_Page.Created_date, 
        dbo.view_modified_by.Modified_by, dbo.PAL_Page.Modified_date
FROM    dbo.PAL_Page 
		LEFT OUTER JOIN dbo.PAL_Page AS PAL_Page_1 ON dbo.PAL_Page.Parent_Page_id = PAL_Page_1.Page_id 
		LEFT OUTER JOIN dbo.view_modified_by ON dbo.PAL_Page.Modified_by = dbo.view_modified_by.User_id 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.PAL_Page.Created_by = dbo.view_created_by.User_id
GO

/****** Object:  View dbo.view_all_pages_by_role    Script Date: 11/11/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_pages_by_role') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_pages_by_role
GO

CREATE VIEW dbo.view_all_pages_by_role
AS
SELECT	dbo.view_all_pages.Page_id, dbo.view_all_pages.Parent_Page_id, dbo.view_all_pages.Page_title, dbo.view_all_pages.Parent_Page_title, dbo.view_all_pages.Navigate_url, 
        dbo.view_all_pages.Page_description, dbo.view_all_pages.Created_by, dbo.view_all_pages.Created_date, dbo.view_all_pages.Modified_by, 
        dbo.view_all_pages.Modified_date, dbo.PAL_Role_X_PAL_Page.Role_id, dbo.PAL_Role_X_PAL_Page.Sort_index, 
        dbo.PAL_Role_X_PAL_Page.Allow_view, dbo.PAL_Role_X_PAL_Page.Allow_modify, dbo.PAL_Role_X_PAL_Page.Allow_delete
FROM    dbo.PAL_Role_X_PAL_Page 
		INNER JOIN  dbo.view_all_pages ON dbo.PAL_Role_X_PAL_Page.Page_id = dbo.view_all_pages.Page_id
GO

                      
/****** Object:  View dbo.view_all_address    Script Date: 11/11/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_address') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_address
GO

CREATE VIEW dbo.view_all_address
AS
SELECT	dbo.PAL_Address.Address_id, dbo.PAL_Address.Address1, dbo.PAL_Address.Address2, dbo.PAL_Address.City, dbo.PAL_Address.State_id, dbo.State_LKUP.State_name, dbo.State_LKUP.State_code, 
        dbo.PAL_Address.Zip, dbo.PAL_Address.Country_id, dbo.Country_LKUP.Country_name, dbo.PAL_Address.Phone, dbo.PAL_Address.Mobile, dbo.PAL_Address.Fax, 
        dbo.PAL_Address.Email,dbo.PAL_Address.Website
FROM    dbo.PAL_Address 
		LEFT OUTER JOIN dbo.Country_LKUP ON dbo.PAL_Address.Country_id = dbo.Country_LKUP.Country_id 
		LEFT OUTER JOIN dbo.State_LKUP ON dbo.PAL_Address.State_id = dbo.State_LKUP.State_id
GO

                      
/****** Object:  View dbo.view_all_users    Script Date: 11/11/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_users') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_users
GO

CREATE VIEW dbo.view_all_users
AS
SELECT	dbo.PAL_Users.User_id, dbo.PAL_Users.User_name, dbo.PAL_Users.Passwd, dbo.PAL_Users.First_name, dbo.PAL_Users.Last_name, 
        dbo.PAL_Users.Active_user, dbo.PAL_Users.Role_id, dbo.view_all_roles.Role_name, dbo.PAL_Users.Last_login_date, dbo.PAL_Users.Address_id, 
        dbo.view_all_address.Address1, dbo.view_all_address.Address2, dbo.view_all_address.City, dbo.view_all_address.State_id, 
        dbo.view_all_address.State_name, dbo.view_all_address.State_code, dbo.view_all_address.Zip, dbo.view_all_address.Country_id, dbo.view_all_address.Country_name, 
        dbo.view_all_address.Phone, dbo.view_all_address.Mobile, dbo.view_all_address.Fax, dbo.view_all_address.Email,  dbo.view_all_address.Website, 
        dbo.view_created_by.Created_by, dbo.view_modified_by.Modified_by, dbo.PAL_Users.Created_date, dbo.PAL_Users.Modified_date
FROM    dbo.PAL_Users 
		LEFT OUTER JOIN dbo.view_modified_by ON dbo.PAL_Users.User_id = dbo.view_modified_by.User_id 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.PAL_Users.User_id = dbo.view_created_by.User_id 
		LEFT OUTER JOIN dbo.view_all_roles ON dbo.PAL_Users.Role_id = dbo.view_all_roles.Role_id 
		LEFT OUTER JOIN dbo.view_all_address ON dbo.PAL_Users.Address_id = dbo.view_all_address.Address_id
GO
                  
                      
/****** Object:  View dbo.view_all_country    Script Date: 11/11/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_country') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_country
GO

CREATE VIEW dbo.view_all_country
AS
SELECT	Country_id, Country_name, Country_code
FROM	dbo.Country_LKUP
GO 

/****** Object:  View dbo.view_all_states_by_country    Script Date: 11/11/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_states_by_country') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_states_by_country
GO

CREATE VIEW dbo.view_all_states_by_country
AS
SELECT   dbo.State_LKUP.State_id, dbo.State_LKUP.State_name, dbo.State_LKUP.State_code, dbo.Country_X_State.Country_id
FROM     dbo.State_LKUP 
		 INNER JOIN  dbo.Country_X_State ON dbo.State_LKUP.State_id = dbo.Country_X_State.State_id
GO          

/****** Object:  View dbo.view_all_contacts    Script Date: 11/11/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_contacts') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_contacts
GO

CREATE VIEW dbo.view_all_contacts
AS
SELECT	dbo.Contacts.Contact_id, dbo.Contacts.Contact_short_name, dbo.Contacts.Contact_type_id, dbo.Contact_Type_LKUP.Contact_type_description, 
        dbo.Contacts.Contact_name, dbo.Contacts.Company_name, dbo.Contacts.Address_id, 
        dbo.view_all_address.Address1, dbo.view_all_address.Address2, dbo.view_all_address.City, dbo.view_all_address.State_id, 
        dbo.view_all_address.State_name, dbo.view_all_address.State_code, dbo.view_all_address.Zip, dbo.view_all_address.Country_id, dbo.view_all_address.Country_name, 
        dbo.view_all_address.Phone, dbo.view_all_address.Mobile, dbo.view_all_address.Fax, dbo.view_all_address.Email,  dbo.view_all_address.Website, 
        dbo.view_created_by.Created_by, dbo.view_modified_by.Modified_by, dbo.Contacts.Created_date, dbo.Contacts.Modified_date
FROM    dbo.Contacts 
		LEFT OUTER JOIN dbo.view_modified_by ON dbo.Contacts.Modified_by = dbo.view_modified_by.User_id 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.Contacts.Created_by = dbo.view_created_by.User_id 		
		LEFT OUTER JOIN dbo.view_all_address ON dbo.Contacts.Address_id = dbo.view_all_address.Address_id
		LEFT OUTER JOIN dbo.Contact_Type_LKUP ON dbo.Contacts.Contact_type_id = dbo.Contact_Type_LKUP.Contact_type_id
GO		