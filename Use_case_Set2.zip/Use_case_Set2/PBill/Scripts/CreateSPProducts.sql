/******Database Name:Database.mdf*****/
/****** Author:Rolina Nayak*****/
/****** Script Created Date:14/11/2011*****/
/******Script Modified Date:14/11/2011*****/
/******Script Version:1.0 *****/

 /***Object=Table  dbo.sp_get_all_products Script Date:14/11/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_all_products') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_all_products	
GO

CREATE PROCEDURE dbo.sp_get_all_products
AS
 BEGIN
	 SELECT * FROM dbo.view_all_products
 END
GO 
 
 
 /***Object=Table  dbo.sp_get_product Script Date:14/11/2011***/
IF exists (SELECT * FROM dbo.sysobjects WHERE id =OBJECT_ID(N'dbo.sp_get_product') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_get_product
GO

CREATE PROCEDURE dbo.sp_get_product
				 @Product_id	VARCHAR(10)
AS
BEGIN
	SELECT * FROM dbo.view_all_products WHERE Product_id=@Product_id
END
GO
 
/***Object=Table dbo.sp_create_product_wiz Script Date:14/11/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_create_product_wiz') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_create_product_wiz
GO

CREATE PROCEDURE dbo.sp_create_product_wiz(    
	@Product_short_description	VARCHAR(100),
	@Product_description	VARCHAR(100),
	@Product_type_id	INT,
	@Created_by	VARCHAR(10),	
	@retval VARCHAR(20) OUTPUT
) AS
BEGIN

declare @product_id varchar(20)

exec dbo.sp_new_id @product_id OUTPUT

BEGIN TRAN
 
 INSERT INTO dbo.Products(
	  Product_id,
	  Product_short_description,
	  Product_description,
	  Product_type_id,
	  Created_by,
	  Created_date,
	  Modified_by,
	  Modified_date  
  )VALUES(
	  @Product_id,
	  @Product_short_description,
	  @Product_description,
	  @Product_type_id,
	  @Created_by,
	  GETDATE(),
	  @Created_by,
	  GETDATE() 
  )
 
 IF @@ERROR <> 0
 BEGIN
	 ROLLBACK TRAN
	 SET @retval='-1'
	 RETURN
 END
 
	 COMMIT TRAN
	 SET @retval=0
	 RETURN
	 
 END 
 GO
 
 /***Object=Table dbo.sp_update_product Script Date:14/11/2011***/
 IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_update_product_wiz') and OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_update_product_wiz
 GO
 
 CREATE PROCEDURE dbo.sp_update_product_wiz(
    @Product_id	VARCHAR(10) ,
	@Product_short_description	VARCHAR(100), 
	@Product_description VARCHAR(100),
	@Product_type_id INT,
	@Created_by	VARCHAR(10),
	@Modified_by VARCHAR(10),
	@retval VARCHAR(20) OUTPUT
) AS  
 BEGIN
 
 BEGIN TRAN
 
 UPDATE dbo.Products SET     
	Product_short_description=@Product_short_description,
	Product_description=@Product_description,
	Product_type_id=@Product_type_id,
	Modified_by=@Modified_by,
	Modified_date=GETDATE()	
 WHERE  Product_id=@Product_id
 
 IF @@ERROR <>0
  BEGIN
   ROLLBACK TRAN
   SET @retval='-1'
   RETURN
  END
  
  COMMIT TRAN
  SET @retval=0 
    
 RETURN
 
 END
 GO
 
 
 /***Object=Table dbo.sp_delete_product Script Date:14/11/2011***/
IF exists(SELECT*FROM dbo.sysobjects WHERE id=object_id(N'dbo.sp_delete_product_wiz') and  OBJECTPROPERTY(id,N'IsProcedure')=1)
	DROP PROCEDURE dbo.sp_delete_product_wiz
GO

CREATE PROCEDURE dbo.sp_delete_product_wiz(
    @Product_id VARCHAR(10),
	@retval INT OUTPUT
) AS 
BEGIN

BEGIN TRAN 
 
	DELETE FROM dbo.Products WHERE Product_id=@Product_id
    
IF @@ERROR <>0
 BEGIN
	ROLLBACK TRAN
	SET @retval='-1'
	RETURN
 END
 
 COMMIT TRAN
 SET @retval=0

 RETURN

END 
GO

 