

/****** Script: New/Update/Delete transaction - PBill_db_xx	******/
/****** Author: Sreenivasan Subbanchattiar		******/
/****** Script Created By: Sreenivasan Subbanchattiar   	******/
/****** Script Created Date: 11/14/2011 			******/
/****** Script Modified By: Sreenivasan Subbanchattiar		******/
/****** Script Modified Date: 11/14/2011 	  		******/
/****** Script Version: 1.0  				******/


/****** Object:Stored PROCEDURE   dbo.sp_get_all_transaction    Script Date: 11/14/2011 	  ******/
IF exists (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'dbo.sp_get_all_transaction') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE dbo.sp_get_all_transaction
GO

CREATE PROCEDURE dbo.sp_get_all_transaction
AS
BEGIN

 SELECT * FROM dbo.view_all_transaction  

 END
GO 
/***********************/

exec sp_get_all_transaction


/****** Object:Stored Procedure   dbo.sp_get_transaction    Script Date: 11/14/2011 	  ******/
IF exists (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'dbo.sp_get_transaction') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE  dbo.sp_get_transaction
GO

CREATE PROCEDURE  dbo.sp_get_transaction
        @transaction_id AS varchar(20)
AS
BEGIN
  
  SELECT * FROM  dbo.view_all_transaction  WHERE transaction_id = @transaction_id 
  
 END
GO 


/****** Object:Stored Procedure   dbo.sp_create_transaction_wiz    Script Date: 011/14/2011  ******/
IF exists (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'dbo.sp_create_transaction_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE dbo.sp_create_transaction_wiz
GO

CREATE PROCEDURE dbo.sp_create_transaction_wiz( 
	
	
	@transaction_type_id	Int,
	@transaction_ref_id	Varchar(10),
	@amount	Money,	
	@cheque_no varchar(10),
	@cheque_date date,
	@bank_name varchar(100),
	@bank_branch varchar(100),
	@transcation_description varchar(100),
	@created_date Datetime,
	@created_by varchar(10),
	@retval varchar(10) OUTPUT)
AS
BEGIN
BEGIN tran
DECLARE @transaction_id UniqueIdentifier
		INSERT INTO dbo.Transactions(
		transaction_id,
		transaction_type_id,
		transaction_ref_id,
		amount,	
		cheque_no ,
		cheque_date,
		bank_name,
		bank_branch ,
		transcation_description,
		Created_by,
		Created_date
		
     )VALUES(
		@transaction_id,
		@transaction_type_id,
		@transaction_ref_id,
		@amount,	
		@cheque_no ,
		@cheque_date,
		@bank_name,
		@bank_branch ,
		@transcation_description,	    
	    @created_by,
		GETDATE()
	    
     )          	
     
	
 IF @@error <> 0
  BEGIN
     rollback  tran
     set @retval = '-1' 
     return 
  END
 
    commit  tran
    set @retval = @transaction_id
    return  
  
END 
GO


/****** Object:Stored Procedure   dbo.sp_update_transaction_wiz    Script Date: 011/14/2011  ******/
IF exists (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'dbo.sp_update_transaction_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE dbo.sp_update_transaction_wiz
GO

CREATE PROCEDURE dbo.sp_update_transaction_wiz( 
	
	@transaction_type_id	int,
	@transaction_ref_id	Varchar(10),
	@amount	Money,	
	@cheque_no varchar(10),
	@cheque_date date,
	@bank_name varchar(100),
	@bank_branch varchar(100),
	@transcation_description varchar(100),
	@created_date Datetime,
	@created_by varchar(10),
	@retval int OUTPUT)
AS
BEGIN

DECLARE @transaction_id UniqueIdentifier

 
BEGIN tran

	UPDATE dbo.Transactions SET
				transaction_type_id=@transaction_type_id,
				transaction_ref_id=@transaction_ref_id,
				amount=@amount	,	
				cheque_no=@cheque_no ,
				cheque_date=@cheque_date,
				bank_name=@bank_name ,
				bank_branch=@bank_branch ,
				transcation_description=@transcation_description ,
				created_date=GETDATE() ,
				created_by=@created_by 
		
		
	WHERE transaction_id = @transaction_id
	
 IF @@error <> 0
  BEGIN
     rollback  tran
     set @retval = -1 
     return 
  END
 
    commit  tran
    set @retval = 0
    return  
  
END 
GO


/****** Object:Stored Procedure   dbo.sp_delete_transaction_wiz    Script Date: 11/14/2011 	  ******/
IF exists (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'dbo.sp_delete_transaction_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE dbo.sp_delete_transaction_wiz
GO

CREATE PROCEDURE dbo.sp_delete_transaction_wiz(
			@transaction_id  varchar(20),
			
			@retval int OUTPUT)
AS
BEGIN

 
 
 BEGIN tran
 
 
 
 DELETE FROM  dbo.transactions WHERE transaction_id=@transaction_id 
 
 IF @@error <> 0
  BEGIN
     rollback  tran
     set @retval = -1 
     return 
  END
 
    commit  tran
    set @retval = 0
    return  
    
 END
GO 
