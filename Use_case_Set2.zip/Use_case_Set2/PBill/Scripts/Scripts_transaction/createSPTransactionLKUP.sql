
/****** Object:Stored Procedure   dbo.sp_get_all_transaction_type_lkup  Script Date: 11/11/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_transaction_type_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_transaction_type_lkup
GO

CREATE procedure dbo.sp_get_all_transaction_type_lkup
AS
begin

 SELECT * FROM  dbo.Transaction_Type_LKUP

end
GO
/***************/
exec sp_get_all_transaction_type_lkup




/****** Object:Stored Procedure   dbo.sp_get_all_transaction_mode_lkup  Script Date: 11/11/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_transaction_mode_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_transaction_mode_lkup
GO

CREATE procedure dbo.sp_get_all_transaction_mode_lkup
AS
begin

 SELECT * FROM  dbo.Transaction_Mode_LKUP

end
GO