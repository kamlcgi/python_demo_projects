/****** Object:  View dbo.view_all_transaction   Script Date: 14/11/2011  ******/


if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_transaction') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_transaction
GO

CREATE VIEW dbo.view_all_transaction
AS
SELECT	dbo.Transactions.Transaction_id, dbo.Transactions.Transaction_type_id, dbo.Transactions.Transaction_ref_id, dbo.Transactions.Amount, 
        dbo.Transactions.Cheque_no, dbo.Transactions.Cheque_date, dbo.Transactions.Bank_name, 
        dbo.Transactions.Bank_branch,dbo.Transactions.Transcation_description,
        dbo.Transactions.Created_by,dbo.Transactions.Created_date,
        dbo.Transaction_Type_LKUP.Transaction_type_description
      
FROM    dbo.Transactions 
		LEFT OUTER JOIN dbo.Transaction_Type_LKUP ON dbo.Transactions.Transaction_type_id = dbo.Transaction_Type_LKUP.Transaction_type_id
		
		
GO	
