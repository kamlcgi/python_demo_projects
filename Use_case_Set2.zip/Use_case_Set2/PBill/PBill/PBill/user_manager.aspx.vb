﻿Public Class user_manager
    Inherits System.Web.UI.Page

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        setRolePermission()

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        getAllUsers()

    End Sub

    Private Sub setRolePermission()

        Dim T_Security As New PAL_Security

        T_Security.Role_Id = Session("Role_Id")
        T_Security.Navigate_Url = T_Security.Get_Page(Request)
        T_Security.GV_Data = GV_User_Manager
        T_Security.setGVUserPermission("User_id", "_user.aspx", "id", "User_id")

        T_Security = Nothing

    End Sub

    Private Sub getAllUsers()

        Dim T_Security As New PAL_Security

        T_Security.DS_Data = DS_User_Manager
        T_Security.selectAllUsers()

        T_Security = Nothing

    End Sub



End Class