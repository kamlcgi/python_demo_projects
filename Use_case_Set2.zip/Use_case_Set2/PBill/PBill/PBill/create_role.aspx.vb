﻿Public Class create_role
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        getAllPages()
    End Sub

    Protected Sub create_role(ByVal sender As Object, ByVal e As EventArgs) Handles btn_create_role.Click

        createRole()

    End Sub

    Private Sub getAllPages()

        Dim T_Security As New PAL_Security

        T_Security.DS_Data = DS_Page_Manager
        T_Security.selectAllPages()

        T_Security = Nothing

    End Sub

    Sub createRole()

        Dim T_Security As New PAL_Security
        Dim T_Msg As String = ""

        Try

            T_Security.Role_Name = txt_role_name.Text
            T_Security.GV_Data = GV_Page_Manager
            T_Security.By = Session("User_Id")
            T_Security.executeCreateRole()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Creating Role Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Creating Role Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("role_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

End Class