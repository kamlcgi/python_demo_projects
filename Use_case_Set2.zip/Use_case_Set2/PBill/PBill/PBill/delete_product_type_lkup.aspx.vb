﻿Public Class delete_product_type_lkup
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            getProductTypeLkupInformation()

        End If
    End Sub
    Protected Sub delete_Product_Type_Lkup(ByVal sender As Object, ByVal e As EventArgs) Handles btn_delete.Click

        deleteProductTypeLkupInformation()

    End Sub
    Sub getProductTypeLkupInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_lookup As New PLookup

        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_lookup.Product_Type_Id = T_Id
            T_lookup.executeSelectPLookup()

            If T_lookup.Error_Id = 0 Then

                lbl_text.Text = T_lookup.Product_Type_Description

            Else

                T_Msg = "Error Retrieving Product Type Lookup Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Product Type Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_lookup = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub
    Sub deleteProductTypeLkupInformation()

        Dim T_lookup As New PLookup
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try
            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_lookup.Product_Type_Id = T_Id
            T_lookup.By = Session("User_Id")
            T_lookup.executeDeletePLookup()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Deleting Product Type Lookup Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Deleting Product Type Lookup Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_lookup = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("product_type_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

End Class
