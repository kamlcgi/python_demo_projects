﻿Public Class view_tips
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        getTipsInformation()


    End Sub

    Sub getTipsInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Tips As New Tips
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Tips.Tip_id = T_Id
            T_Tips.executeSelectTips()

            If T_Tips.Error_Id = 0 Then

                txt_Tips_name.Text = T_Tips.Tip_name
                txt_Tips_description.Text = T_Tips.Tip_description
                txt_File_type_id.Text = T_Tips.File_type_id
                txt_File_location.Text = T_Tips.File_location
                txt_Post.Text = T_Tips.Post
           



            Else

                T_Msg = "Error Retrieving Tips Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Tips Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Tips = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

End Class