﻿Public Class transaction_manager
    Inherits System.Web.UI.Page

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        setRolePermission()
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        getAlltransactions()

    End Sub
    Private Sub setRolePermission()

        Dim T_Security As New PAL_Security

        T_Security.Role_Id = Session("Role_Id")
        T_Security.Navigate_Url = T_Security.Get_Page(Request)
        T_Security.GV_Data = GV_transaction_Manager
        T_Security.setGVUserPermission("transaction_id", "_transaction.aspx", "id", "transaction_id")

        T_Security = Nothing

    End Sub

    Private Sub getAlltransactions()

        Dim T_transaction As New transaction

        T_transaction.DS_Data = DS_transaction_Manager
        T_transaction.selectAllTransaction()

        T_transaction = Nothing

    End Sub
End Class