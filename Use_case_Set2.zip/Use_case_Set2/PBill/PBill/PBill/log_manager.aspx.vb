﻿Public Class log_manager
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        getAllUserLogs()

    End Sub

    Protected Sub clear_log(ByVal sender As Object, ByVal e As EventArgs) Handles btn_clear.Click

        clearLog()

    End Sub

    Sub clearLog()

        Dim T_Security As New PAL_Security

        T_Security.executeClearUserLog()
        GV_Log_Manager.DataBind()

        T_Security = Nothing

        getAllUserLogs()

    End Sub

    Private Sub getAllUserLogs()

        Dim T_Security As New PAL_Security

        T_Security.DS_Data = DS_Log_Manager
        T_Security.selectAllUserLogs()

        T_Security = Nothing

    End Sub

End Class