﻿Public Class modify_product
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            getProductInformation()
            setLookups()
        End If

    End Sub

    Protected Sub save_Product(ByVal sender As Object, ByVal e As EventArgs) Handles btn_save.Click

        saveProductInformation()

    End Sub

    Sub getProductInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Product As New Product
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Product.Product_Id = T_Id
            T_Product.executeSelectProduct()

            If T_Product.Error_Id = 0 Then

                txt_Product_short_description.Text = T_Product.Product_Short_Description
                txt_Product_description.Text = T_Product.Product_Description
                ddl_Product_type_id.SelectedValue = T_Product.Product_Type_Id

            Else

                T_Msg = "Error Retrieving Product Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If


        Catch ex As Exception

            T_Msg = "Error Decoding Product Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Product = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If
    End Sub

    Sub saveProductInformation()

        Dim T_Product As New Product
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Product.Product_Id = T_Id
            T_Product.Product_Short_Description = txt_Product_short_description.Text
            T_Product.Product_Description = txt_Product_description.Text
            T_Product.Product_Type_Id = ddl_Product_type_id.SelectedValue

            T_Product.By = Session("User_Id")
            T_Product.executeUpdateProduct()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Updating Product Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Updating Product Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Product = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("product_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindProductTypeList(ddl_product_type_id)

        T_Lookup = Nothing

    End Sub


End Class