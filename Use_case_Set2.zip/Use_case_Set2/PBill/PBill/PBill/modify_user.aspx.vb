﻿Public Class modify_user
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            setLookups()
            getUserInformation()

        End If

    End Sub

    Protected Sub save_user(ByVal sender As Object, ByVal e As EventArgs) Handles btn_save.Click

        saveUserInformation()

    End Sub

    Sub getUserInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_User_Id As String = ""

        Try

            T_User_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Security.User_Id = T_User_Id
            T_Security.executeSelectUser()

            If T_Security.Error_Id = 0 Then

                txt_first_name.Text = T_Security.First_Name
                txt_last_name.Text = T_Security.Last_Name
                txt_address1.Text = T_Security.Address1
                txt_address2.Text = T_Security.Address2
                txt_city.Text = T_Security.City
                txt_zip.Text = T_Security.Zip
                ddl_state.SelectedValue = T_Security.State_Id
                ddl_country.SelectedValue = T_Security.Country_Id
                txt_phone.Text = T_Security.Phone
                txt_mobile.Text = T_Security.Mobile
                txt_fax.Text = T_Security.Fax
                txt_email.Text = T_Security.Email
                txt_website.Text = T_Security.Website

                txt_user_name.Text = T_Security.User_Name
                txt_password.Text = T_Security.Password

                If T_Security.Active_User = "1" Then
                    chk_active_user.Checked = True
                Else
                    chk_active_user.Checked = False
                End If

                ddl_role.SelectedValue = T_Security.Role_Id

            Else

                T_Msg = "Error Retrieving User Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding User Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub saveUserInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_User_Id As String = ""

        Try

            T_User_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Security.User_Id = T_User_Id

            T_Security.First_Name = txt_first_name.Text
            T_Security.Last_Name = txt_last_name.Text
            T_Security.Address1 = txt_address1.Text
            T_Security.Address2 = txt_address2.Text
            T_Security.City = txt_city.Text
            T_Security.Zip = txt_zip.Text
            T_Security.State_Id = ddl_state.SelectedValue
            T_Security.Country_Id = ddl_country.SelectedValue
            T_Security.Phone = txt_phone.Text
            T_Security.Mobile = txt_mobile.Text
            T_Security.Fax = txt_fax.Text
            T_Security.Email = txt_email.Text
            T_Security.Website = txt_website.Text

            T_Security.User_Name = txt_user_name.Text
            T_Security.Password = txt_password.Text
            T_Security.Role_Id = ddl_role.SelectedValue

            If chk_active_user.Checked Then
                T_Security.Active_User = "1"
            Else
                T_Security.Active_User = "0"
            End If

            T_Security.By = Session("User_Id")
            T_Security.executeUpdateUser()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Updating User Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding User Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("user_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindCountryList(ddl_country)
        T_Lookup.bindStateList(ddl_state, 1)
        T_Lookup.bindRoleList(ddl_role)

        T_Lookup = Nothing

    End Sub

End Class