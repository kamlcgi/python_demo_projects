﻿Public Class product_type_manager
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        getAllProducts()
    End Sub

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        setRolePermission()

    End Sub
    Private Sub setRolePermission()

        Dim T_Security As New PAL_Security

        T_Security.Role_Id = Session("Role_Id")
        T_Security.Navigate_Url = T_Security.Get_Page(Request)
        T_Security.GV_Data = GV_Product_Type_Manager
        T_Security.setGVUserPermission("Product_type_id", "_Product.aspx", "id", "Product_type_id")

        T_Security = Nothing


    End Sub

    Private Sub getAllProducts()

        Dim T_Product As New Product

        T_Product.DS_Data = DS_Product_Type_Manager
        T_Product.selectAllProducts()

        T_Product = Nothing

    End Sub

End Class
