﻿
'Component Name: Contact
'Description: Used to Create, Update, View and Delete Contact Information
'Author:  Srinivasan Subbanchattiar 
'Created By: Srinivasan Subbanchattiar 
'Created Date: 11/14/2011 
'Modified By: Srinivasan Subbanchattiar 
'Modified Date: 11/14/2011 
'Version: 1.0

Imports System.Web
Imports System.Data
Imports System.Data.SqlClient

Public Class Contact



    Protected intErr As Integer
    Protected strErr As String
    Protected strBy As String

    Protected strContactId As String
    Protected strContactShortName As String
    Protected intContactTypeId As Integer
    Protected strContactTypeDescription As String
    Protected strContactName As String
    Protected strCompanyName As String


    Protected strAddress1 As String
    Protected strAddress2 As String
    Protected strCity As String

    Protected intStateId As Integer
    Protected strStateName As String

    Protected intCountryId As Integer
    Protected strCountryName As String
    Protected strZip As String
    Protected strPhone As String
    Protected strMobile As String
    Protected strFax As String
    Protected strEmail As String
    Protected strWebsite As String

    Protected gvData As GridView
    Protected dsData As SqlDataSource

    'for view purpose only
    Protected strCreatedBy As String
    Protected dtCreatedDate As Date
    Protected strModifiedBy As String
    Protected dtModifiedDate As Date


    Public Sub New()

        Clear()

    End Sub


    Public Sub Clear()

        intErr = Nothing
        strErr = Nothing
        strBy = Nothing

        strContactId = Nothing
        strContactShortName = Nothing
        intContactTypeId = Nothing
        strContactTypeDescription = Nothing
        strContactName = Nothing
        strCompanyName = Nothing

        strAddress1 = Nothing
        strAddress2 = Nothing
        strCity = Nothing

        intStateId = Nothing
        strStateName = Nothing

        intCountryId = Nothing
        strCountryName = Nothing
        strZip = Nothing
        strPhone = Nothing
        strMobile = Nothing
        strFax = Nothing
        strEmail = Nothing

        gvData = Nothing
        dsData = Nothing

        strCreatedBy = Nothing
        dtCreatedDate = Nothing
        strModifiedBy = Nothing
        dtModifiedDate = Nothing


    End Sub

    Public Property Error_Id() As Integer
        Get
            Return intErr
        End Get
        Set(ByVal Value As Integer)
            intErr = Value
        End Set
    End Property

    Public Property Error_Message() As String
        Get
            Return strErr
        End Get
        Set(ByVal Value As String)
            strErr = Value
        End Set
    End Property

    Public Property Contact_Id() As String
        Get
            Return strContactId
        End Get
        Set(ByVal Value As String)
            strContactId = Value
        End Set
    End Property

    Public Property Contact_Short_Name() As String
        Get
            Return strContactShortName
        End Get
        Set(ByVal Value As String)
            strContactShortName = Value
        End Set
    End Property

    Public Property Contact_Type_Id() As Integer
        Get
            Return intContactTypeId
        End Get
        Set(ByVal Value As Integer)
            intContactTypeId = Value
        End Set
    End Property


    Public Property Contact_Type_Description() As String
        Get
            Return strContactTypeDescription
        End Get
        Set(ByVal Value As String)
            strContactTypeDescription = Value
        End Set
    End Property

    Public Property Contact_Name() As String
        Get
            Return strContactName
        End Get
        Set(ByVal Value As String)
            strContactName = Value
        End Set
    End Property

    Public Property Company_Name() As String
        Get
            Return strCompanyName
        End Get
        Set(ByVal Value As String)
            strCompanyName = Value
        End Set
    End Property

    Public Property Address1() As String
        Get
            Return strAddress1
        End Get
        Set(ByVal Value As String)
            strAddress1 = Value
        End Set
    End Property

    Public Property Address2() As String
        Get
            Return strAddress2
        End Get
        Set(ByVal Value As String)
            strAddress2 = Value
        End Set
    End Property

    Public Property City() As String
        Get
            Return strCity
        End Get
        Set(ByVal Value As String)
            strCity = Value
        End Set
    End Property

    Public Property State_Id() As Integer
        Get
            Return intStateId
        End Get
        Set(ByVal Value As Integer)
            intStateId = Value
        End Set
    End Property

    Public Property State_Name() As String
        Get
            Return strStateName
        End Get
        Set(ByVal Value As String)
            strStateName = Value
        End Set
    End Property

    Public Property Zip() As String
        Get
            Return strZip
        End Get
        Set(ByVal Value As String)
            strZip = Value
        End Set
    End Property

    Public Property Country_Id() As Integer
        Get
            Return intCountryId
        End Get
        Set(ByVal Value As Integer)
            intCountryId = Value
        End Set
    End Property

    Public Property Country_Name() As String
        Get
            Return strCountryName
        End Get
        Set(ByVal Value As String)
            strCountryName = Value
        End Set
    End Property


    Public Property Phone() As String
        Get
            Return strPhone
        End Get
        Set(ByVal Value As String)
            strPhone = Value
        End Set
    End Property

    Public Property Mobile() As String
        Get
            Return strMobile
        End Get
        Set(ByVal Value As String)
            strMobile = Value
        End Set
    End Property

    Public Property Fax() As String
        Get
            Return strFax
        End Get
        Set(ByVal Value As String)
            strFax = Value
        End Set
    End Property

    Public Property Email() As String
        Get
            Return strEmail
        End Get
        Set(ByVal Value As String)
            strEmail = Value
        End Set
    End Property

    Public Property Website() As String
        Get
            Return strWebsite
        End Get
        Set(ByVal Value As String)
            strWebsite = Value
        End Set
    End Property

    Public Property DS_Data() As SqlDataSource
        Get
            Return dsData
        End Get
        Set(ByVal Value As SqlDataSource)
            dsData = Value
        End Set
    End Property

    Public Property GV_Data() As GridView
        Get
            Return gvData
        End Get
        Set(ByVal Value As GridView)
            gvData = Value
        End Set
    End Property

    Public Property By() As String
        Get
            Return strBy
        End Get
        Set(ByVal Value As String)
            strBy = Value
        End Set
    End Property

    Public Property Created_By() As String
        Get
            Return strCreatedBy
        End Get
        Set(ByVal Value As String)
            strCreatedBy = Value
        End Set
    End Property

    Public Property Modified_By() As String
        Get
            Return strModifiedBy
        End Get
        Set(ByVal Value As String)
            strModifiedBy = Value
        End Set
    End Property

    Public Property Created_Date() As Date
        Get
            Return dtCreatedDate
        End Get
        Set(ByVal Value As Date)
            dtCreatedDate = Value
        End Set
    End Property

    Public Property Modified_Date() As Date
        Get
            Return dtModifiedDate
        End Get
        Set(ByVal Value As Date)
            dtModifiedDate = Value
        End Set
    End Property

    Public Sub selectAllContacts()

        Dim dbCon As New DBAccess

        'Get all the User information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_contacts"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub executeSelectContact()

        If Not IsDBNull(strContactId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the user information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_contact", _
                         New SqlParameter("@Contact_id", strContactId))

            If dbRs.Read Then

                
                If Not IsDBNull(dbRs("Contact_short_name")) Then
                    strContactShortName = dbRs("Contact_short_name")
                End If

                If Not IsDBNull(dbRs("Contact_type_id")) Then
                    intContactTypeId = dbRs("Contact_type_id")
                End If

                If Not IsDBNull(dbRs("Contact_type_description")) Then
                    strContactTypeDescription = dbRs("Contact_type_description")
                End If

                If Not IsDBNull(dbRs("Contact_name")) Then
                    strContactName = dbRs("Contact_name")
                End If

                If Not IsDBNull(dbRs("Company_name")) Then
                    strCompanyName = dbRs("Company_name")
                End If

                If Not IsDBNull(dbRs("Address1")) Then
                    strAddress1 = dbRs("Address1")
                End If

                If Not IsDBNull(dbRs("Address2")) Then
                    strAddress2 = dbRs("Address2")
                End If

                If Not IsDBNull(dbRs("City")) Then
                    strCity = dbRs("City")
                End If

                If Not IsDBNull(dbRs("State_Id")) Then
                    intStateId = dbRs("State_Id")
                End If
                If Not IsDBNull(dbRs("State_Name")) Then
                    strStateName = dbRs("State_Name")
                End If
                If Not IsDBNull(dbRs("Country_Id")) Then
                    intCountryId = dbRs("Country_Id")
                End If
                If Not IsDBNull(dbRs("Country_Name")) Then
                    strCountryName = dbRs("Country_Name")
                End If
                If Not IsDBNull(dbRs("Zip")) Then
                    strZip = dbRs("Zip")
                End If
                If Not IsDBNull(dbRs("Phone")) Then
                    strPhone = dbRs("Phone")
                End If
                If Not IsDBNull(dbRs("Mobile")) Then
                    strMobile = dbRs("Mobile")
                End If
                If Not IsDBNull(dbRs("Fax")) Then
                    strFax = dbRs("Fax")
                End If

                If Not IsDBNull(dbRs("Email")) Then
                    strEmail = dbRs("Email")
                End If

                If Not IsDBNull(dbRs("Website")) Then
                    strWebsite = dbRs("Website")
                End If

                If Not IsDBNull(dbRs("Created_by")) Then
                    strCreatedBy = dbRs("Created_by")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                If Not IsDBNull(dbRs("Created_date")) Then
                    dtCreatedDate = dbRs("Created_date")
                End If

                If Not IsDBNull(dbRs("Modified_date")) Then
                    dtModifiedDate = dbRs("Modified_date")
                End If

                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 'Id is Nothing
            strErr = "UserId is Nothing"

        End If

    End Sub 'executeSelectContact()


    Public Sub executeCreateContact()


        Dim dbCon As New DBAccess
        Dim T_User_id As String

        'Create New Contact to the database 

        T_User_id = dbCon.RunSPReturnId("dbo.sp_create_contact_wiz", _
                         New SqlParameter("@Contact_short_name", strContactShortName), _
                         New SqlParameter("@Contact_type_id", intContactTypeId), _
                         New SqlParameter("@Contact_name", strContactName), _
                         New SqlParameter("@Company_name", strCompanyName), _
                         New SqlParameter("@address1", strAddress1), _
                         New SqlParameter("@address2", strAddress2), _
                         New SqlParameter("@city", strCity), _
                         New SqlParameter("@state_id", intStateId), _
                         New SqlParameter("@zip", strZip), _
                         New SqlParameter("@country_id", intCountryId), _
                         New SqlParameter("@phone", strPhone), _
                         New SqlParameter("@mobile", strMobile), _
                         New SqlParameter("@fax", strFax), _
                         New SqlParameter("@email", strEmail), _
                         New SqlParameter("@website", strWebsite), _
                         New SqlParameter("@created_by", strBy))

        If T_User_id = "-1" Then

            intErr = -1 'Create New Contact Failed
            strErr = "Create New Contact Failed"

        Else

            intErr = 0 'New Contact Created Successfully
            strErr = "New Contact Created Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeCreateContact()


    Public Sub executeUpdateContact()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Save Contact Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_contact_wiz", _
                         New SqlParameter("@Contact_id", strContactId), _
                         New SqlParameter("@Contact_short_name", strContactShortName), _
                         New SqlParameter("@Contact_type_id", intContactTypeId), _
                         New SqlParameter("@Contact_name", strContactName), _
                         New SqlParameter("@Company_name", strCompanyName), _
                         New SqlParameter("@address1", strAddress1), _
                         New SqlParameter("@address2", strAddress2), _
                         New SqlParameter("@city", strCity), _
                         New SqlParameter("@state_id", intStateId), _
                         New SqlParameter("@zip", strZip), _
                         New SqlParameter("@country_id", intCountryId), _
                         New SqlParameter("@phone", strPhone), _
                         New SqlParameter("@mobile", strMobile), _
                         New SqlParameter("@fax", strFax), _
                         New SqlParameter("@email", strEmail), _
                         New SqlParameter("@website", strWebsite), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = -1 Then

            intErr = -1 'Update Contact Failed
            strErr = "Update Contact Failed"

        Else

            intErr = 0 'Contact Information Saved Successfully
            strErr = "Contact Information Saved Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateContact()



    Public Sub executeDeleteContact()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Delete Contact Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_delete_contact_wiz", _
                         New SqlParameter("@Contact_id", strContactId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Delete Contact Failed
            strErr = "Delete Contact Failed"

        Else

            intErr = 0 'Contact Information Deleted Successfully
            strErr = "Contact Information Deleted Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeleteContact()

End Class
