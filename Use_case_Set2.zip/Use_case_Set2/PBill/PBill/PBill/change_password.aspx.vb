﻿Public Class change_password
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub change_password(ByVal sender As Object, ByVal e As EventArgs) Handles btn_change.Click

        Call changePassword()

    End Sub

    Sub changePassword()

        Dim T_Security As New PAL_Security
        Dim T_Msg As String

        T_Security.User_Id = Session("User_Id")
        T_Security.Password = txt_password.Text
        T_Security.By = Session("User_Id")
        T_Security.executeChangeUserPassword()

        T_Msg = T_Security.Error_Message

        If T_Security.Error_Id = 0 Then

            T_Security = Nothing
            Response.Redirect("msg.aspx?msg=" & T_Msg)

        Else

            T_Security = Nothing
            Response.Redirect("msg.aspx?msg=" & T_Msg)

        End If

    End Sub

End Class