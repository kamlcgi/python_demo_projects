﻿Public Class view_product
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        getProductInformation()


    End Sub

    Sub getProductInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Product As New Product
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Product.Product_Id = T_Id
            T_Product.executeSelectProduct()

            If T_Product.Error_Id = 0 Then


                txt_Product_short_description.Text = T_Product.Product_Short_Description
                txt_Product_description.Text = T_Product.Product_Description
                txt_Product_type_id.Text = T_Product.Product_Type_Id
             
          

            Else

                T_Msg = "Error Retrieving Product Information."
                T_Security.Browser(Request)
                T_Security.By = Session("Product_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Product Id."
            T_Security.Browser(Request)
            T_Security.By = Session("Product_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Product = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


End Class