﻿Public Class login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


    End Sub

    Protected Sub btn_logon_Click(ByVal sender As Object, ByVal e As EventArgs) Handles LoginButton.Click

        Call Logon()

    End Sub


    Sub Logon()

        Dim T_Security As New PAL_Security

        FailureText.Text = ""

        T_Security.User_Name = UserName.Text
        T_Security.Password = Password.Text

        T_Security.executeValidateUser()

        If T_Security.Error_Id = 0 Then

            Session("User_Id") = T_Security.User_Id
            Session("First_Name") = T_Security.First_Name & " " & T_Security.Last_Name
            Session("Role_Id") = T_Security.Role_Id

            T_Security.Browser(Request)
            T_Security.Log_Data = "Logged In UserName:" & UserName.Text
            T_Security.By = T_Security.User_Id
            T_Security.executeCreateUserLog()

            T_Security = Nothing

            Session("PMenu") = createMenu(Session("Role_Id"))

            FormsAuthentication.RedirectFromLoginPage(UserName.Text, False)

        Else

            T_Security.Browser(Request)
            T_Security.Log_Data = "Log In Failed UserName:" & UserName.Text & " Password:" & Password.Text
            T_Security.By = ""
            T_Security.executeCreateUserLog()

            UserName.Text = ""
            Password.Text = ""
            FailureText.Text = "Log In Failed, Enter Correct UserName And Password"
            T_Security = Nothing

        End If

    End Sub

    Function createMenu(ByVal Role_Id As Integer) As String

        Dim T_Menu As New PAL_Security
        Dim T_Menu_Content As String

        T_Menu_Content = " <div> "
        T_Menu_Content += " <ul class='menu'> "

        Dim T_DataSet As System.Data.DataSet = T_Menu.getMenuData(Role_Id)

        For Each masterRow As System.Data.DataRow In T_DataSet.Tables(0).Rows()

            T_Menu_Content += " <li class='top'><a href='" + masterRow("Navigate_url").ToString() + "' target='_self' class='top_link'><span> " + masterRow("Page_title").ToString() + "</span></a>"


            Dim T_Sub_menu As Boolean = False
            For Each childRow As System.Data.DataRow In masterRow.GetChildRows("Sub_Menu")

                If Not T_Sub_menu Then
                    T_Menu_Content += " <ul class='sub'> "
                    T_Sub_menu = True
                End If

                T_Menu_Content += "<li><a href='" + childRow("Navigate_url").ToString() + "' target='_self'>" + childRow("Page_title").ToString() + "</a></li> "

            Next

            If T_Sub_menu Then
                T_Menu_Content += " </ul>"
            End If

            T_Menu_Content += "</li>"

        Next

        T_Menu_Content += " </ul> </div>"

        T_Menu = Nothing

        Return T_Menu_Content

    End Function

End Class