﻿Public Class modify_product_type
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

   
        getProductTypeInformation()

    End Sub


    Protected Sub modify_Product(ByVal sender As Object, ByVal e As EventArgs) Handles btn_save.Click

        saveProduct()

    End Sub

    Protected Sub add_page(ByVal sender As Object, ByVal e As EventArgs) Handles btn_add_page.Click

        addProduct()

    End Sub

    Protected Sub remove_page(ByVal sender As Object, ByVal e As GridViewCommandEventArgs) Handles GV_Product_type_Manager.RowCommand

        If e.CommandName = "remove" Then

            removeProduct(e.CommandArgument)

        End If

    End Sub

    Sub getProductTypeInformation()

        Dim T_lookup As New PLookup
        Dim T_Security As New PAL_Security
        Dim T_ProductTypeLkup As New Product
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Product_Id As String = ""

        Try

            T_Product_Id = T_Encryption.decode(Request.QueryString("id"))
            T_ProductTypeLkup.Product_Id = T_Product_Id

            If Not Page.IsPostBack Then

                T_ProductTypeLkup.executeSelectProduct()

                If T_ProductTypeLkup.Error_Id = 0 Then

                    txt_Product_description.Text = T_ProductTypeLkup.Product_Description


                    T_ProductTypeLkup.DS_Data = DS_Product_type_Manager
                    T_ProductTypeLkup.selectAllProducts()
                Else

                    T_Msg = "Error Retrieving Product Information."
                    T_security.Browser(Request)
                    T_Security.By = Session("User_Id")
                    T_Security.Log_Data = T_Msg
                    T_Security.executeCreateUserLog()

                End If

            Else

                T_ProductTypeLkup.DS_Data = DS_Product_type_Manager
                T_ProductTypeLkup.selectAllProducts()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Product Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_lookup = Nothing
        T_Encryption = Nothing
        T_ProductTypeLkup = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub addProduct()

        Dim T_lookup As New PLookup
        Dim T_Security As New PAL_Security
        Dim T_ProductTypeLkup As New Product
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Product_Id As String = ""

        Try



            T_Product_Id = T_Encryption.decode(Request.QueryString("id"))

            T_ProductTypeLkup.Product_Id = T_Product_Id

            T_Security.By = Session("User_Id")
            T_Security.executeUpdateUser()

            If T_Security.Error_Id = 0 Then


                T_Security.DS_Data = DS_Product_type_Manager
                T_Security.executeCreateUserLog()

            Else

                T_Msg = "Error Updating Product Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If



        Catch ex As Exception

            T_Msg = "Error Decoding Product Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_lookup = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub removeProduct(ByVal page_id As Integer)

        Dim T_lookup As New PLookup
        Dim T_Security As New PAL_Security
        Dim T_ProductTypeLkup As New Product
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Product_Id As String = ""

        Try

            T_Product_Id = T_Encryption.decode(Request.QueryString("id"))

            T_ProductTypeLkup.Product_Type_Id = T_Product_Id
            T_Security.Page_Id = page_id
            T_Security.By = Session("User_Id")
            T_Security.executeDeleteUser()

            If T_Security.Error_Id = 0 Then

                T_Security.Browser(Request)
                T_Security.Log_Data = "Page Id:" & page_id & " Removed from Product Id:" & T_Product_Id & " by User Id:" & T_Security.By
                T_Security.executeCreateUserLog()
                T_Security.DS_Data = DS_Product_type_Manager
                T_Security.executeDeleteUser()

            Else

                T_Msg = "Error Updating Product Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If



        Catch ex As Exception

            T_Msg = "Error Decoding Product Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_lookup = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub saveProduct()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_ProductTypeLkup As New Product
        Dim T_Msg As String = ""
        Dim T_Product_Id As String = ""

        Try

            T_Product_Id = T_Encryption.decode(Request.QueryString("id"))

            T_ProductTypeLkup.Product_Id = T_Product_Id
            T_Security.Page_Description = txt_Product_description.Text
            T_Security.GV_Data = GV_Product_type_Manager
            T_Security.By = Session("User_Id")
            T_Security.executeUpdateUser()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Updating Product Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeUpdateUser()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Product Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("Product_type_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


End Class