﻿Public Class modify_role
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        getRoleInformation()

    End Sub


    Protected Sub modify_role(ByVal sender As Object, ByVal e As EventArgs) Handles btn_save.Click

        saveRole()

    End Sub

    Protected Sub add_page(ByVal sender As Object, ByVal e As EventArgs) Handles btn_add_page.Click

        addPage()

    End Sub

    Protected Sub remove_page(ByVal sender As Object, ByVal e As GridViewCommandEventArgs) Handles GV_Page_Manager.RowCommand

        If e.CommandName = "remove" Then

            removePage(e.CommandArgument)

        End If

    End Sub

    Sub getRoleInformation()

        Dim T_lookup As New PLookup
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Role_Id As String = ""

        Try

            T_Role_Id = T_Encryption.decode(Request.QueryString("id"))
            T_Security.Role_Id = T_Role_Id

            If Not Page.IsPostBack Then

                T_Security.executeSelectRole()

                If T_Security.Error_Id = 0 Then

                    txt_role_name.Text = T_Security.Role_Name
                    T_lookup.bindPageNotInRoleList(ddl_page_list, T_Security.Role_Id)

                    T_Security.DS_Data = DS_Page_Manager
                    T_Security.selectAllPagesByRole()
                Else

                    T_Msg = "Error Retrieving Role Information."
                    T_Security.Browser(Request)
                    T_Security.By = Session("User_Id")
                    T_Security.Log_Data = T_Msg
                    T_Security.executeCreateUserLog()

                End If

            Else

                T_Security.DS_Data = DS_Page_Manager
                T_Security.selectAllPagesByRole()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Role Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_lookup = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub addPage()

        Dim T_lookup As New PLookup
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Role_Id As String = ""

        Try

            If ddl_page_list.SelectedIndex <> -1 Then

                T_Role_Id = T_Encryption.decode(Request.QueryString("id"))

                T_Security.Role_Id = T_Role_Id
                 T_Security.Page_Id = ddl_page_list.SelectedValue
                T_Security.By = Session("User_Id")
                T_Security.executeAddPage()

                If T_Security.Error_Id = 0 Then

                    T_lookup.bindPageNotInRoleList(ddl_page_list, T_Security.Role_Id)
                    T_Security.DS_Data = DS_Page_Manager
                    T_Security.selectAllPagesByRole()

                Else

                    T_Msg = "Error Updating Role Information."
                    T_Security.Browser(Request)
                    T_Security.By = Session("User_Id")
                    T_Security.Log_Data = T_Msg
                    T_Security.executeCreateUserLog()

                End If

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Role Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_lookup = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub removePage(ByVal page_id As Integer)

        Dim T_lookup As New PLookup
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Role_Id As String = ""

        Try

            T_Role_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Security.Role_Id = T_Role_Id
            T_Security.Page_Id = page_id
            T_Security.By = Session("User_Id")
            T_Security.executeRemovePage()

            If T_Security.Error_Id = 0 Then

                T_Security.Browser(Request)
                T_Security.Log_Data = "Page Id:" & page_id & " Removed from Role Id:" & T_Role_Id & " by User Id:" & T_Security.By
                T_Security.executeCreateUserLog()
                T_lookup.bindPageNotInRoleList(ddl_page_list, T_Security.Role_Id)
                T_Security.DS_Data = DS_Page_Manager
                T_Security.selectAllPagesByRole()

            Else

                T_Msg = "Error Updating Role Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If



        Catch ex As Exception

            T_Msg = "Error Decoding Role Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_lookup = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub saveRole()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Role_Id As String = ""

        Try

            T_Role_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Security.Role_Id = T_Role_Id
            T_Security.Role_Name = txt_role_name.Text
            T_Security.GV_Data = GV_Page_Manager
            T_Security.By = Session("User_Id")
            T_Security.executeUpdateRole()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Updating Role Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Role Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("role_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


End Class