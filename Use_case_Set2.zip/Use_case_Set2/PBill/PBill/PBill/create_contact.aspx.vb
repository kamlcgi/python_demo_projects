﻿Public Class create_contact
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            setLookups()

        End If

    End Sub

    Protected Sub create_contact(ByVal sender As Object, ByVal e As EventArgs) Handles btn_create_contact.Click

        createContactInformation()

    End Sub

    Sub createContactInformation()

        Dim T_Contact As New Contact
        Dim T_Security As New PAL_Security
        Dim T_Msg As String = ""

        Try

            T_Contact.Contact_Type_Id = ddl_contact_type.SelectedValue
            T_Contact.Contact_Short_Name = txt_contact_short_name.Text

            T_Contact.Contact_Name = txt_contact_name.Text
            T_Contact.Company_Name = txt_company_name.Text
            T_Contact.Address1 = txt_address1.Text
            T_Contact.Address2 = txt_address2.Text
            T_Contact.City = txt_city.Text
            T_Contact.Zip = txt_zip.Text
            T_Contact.State_Id = ddl_state.SelectedValue
            T_Contact.Country_Id = ddl_country.SelectedValue
            T_Contact.Phone = txt_phone.Text
            T_Contact.Mobile = txt_mobile.Text
            T_Contact.Fax = txt_fax.Text
            T_Contact.Email = txt_email.Text
            T_Contact.Website = txt_website.Text

            T_Contact.By = Session("User_Id")
            T_Contact.executeCreateContact()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Creating New Contact Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Creating New Contact Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("contact_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindCountryList(ddl_country)
        T_Lookup.bindStateList(ddl_state, 1)
        T_Lookup.bindContactTypeList(ddl_contact_type)

        T_Lookup = Nothing

    End Sub

End Class