﻿Public Class view_transaction
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        gettransactionInformation()


    End Sub

    Sub gettransactionInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_transaction As New Transaction
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_transaction.transaction_Id = T_Id
            T_transaction.executeSelecttransaction()

            If T_transaction.Error_Id = 0 Then

                txt_transaction_type_id.Text = T_transaction.transaction_Type_id
                txt_transaction_ref_id.Text = T_transaction.transaction_ref_id
                txt_amount.Text = T_transaction.amount
                txt_cheque_no.Text = T_transaction.Cheque_no
                txt_cheque_date.Text = T_transaction.cheque_date
                txt_bank_name.Text = T_transaction.bank_name
                txt_bank_branch.Text = T_transaction.bank_branch
                txt_transcation_description.Text = T_transaction.transcation_description
                


            Else

                T_Msg = "Error Retrieving transaction Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding transaction Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_transaction = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


End Class