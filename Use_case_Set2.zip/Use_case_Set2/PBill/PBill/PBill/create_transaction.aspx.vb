﻿Public Class create_transaction
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            setLookups()

        End If
    End Sub

    Protected Sub create_Product(ByVal sender As Object, ByVal e As EventArgs) Handles btn_create_transaction.Click

        createProductInformation()

    End Sub

    Sub createProductInformation()

        Dim T_Transaction As New Transaction
        Dim T_Security As New PAL_Security
        Dim T_Msg As String = ""

        Try

            T_Transaction.Transaction_id = ddl_transaction_id.SelectedValue
            T_Transaction.Transaction_type_id = ddl_transaction_type_id.SelectedValue
            T_Transaction.Transaction_ref_id = ddl_transaction_ref_id.SelectedValue

            T_Transaction.Amount = txt_amount.Text
            T_Transaction.Cheque_no = txt_cheque_no.Text
            T_Transaction.Bank_name = txt_bank_name.Text
            T_Transaction.Bank_branch = txt_bank_branch.Text
            T_Transaction.Transcation_description = txt_transcation_description.Text

            T_Transaction.By = Session("user_Id")
            T_Transaction.executeCreateTransaction()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Creating New Transaction Information."
                T_Security.Browser(Request)
                T_Security.By = Session("user_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Creating New Transaction Information."
            T_Security.Browser(Request)
            T_Security.By = Session("user_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("Transaction_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindTransactionTypeList(ddl_transaction_type_id)

        T_Lookup = Nothing

    End Sub
End Class