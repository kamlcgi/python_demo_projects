﻿Public Class modify_Transaction
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            setLookups()
            getTransactionInformation()

        End If
    End Sub
    Protected Sub save_Transaction(ByVal sender As Object, ByVal e As EventArgs) Handles btn_save.Click

        saveTransactionInformation()

    End Sub
    Sub getTransactionInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Transaction As New Transaction
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Transaction.Transaction_Id = T_Id
            T_Transaction.executeSelectTransaction()

            If T_Transaction.Error_Id = 0 Then

                ddl_Transaction_id.SelectedValue = T_Transaction.Transaction_Id
                ddl_Transaction_type_id.SelectedValue = T_Transaction.Transaction_type_id
                txt_Transaction_ref_id.Text = T_Transaction.Transaction_ref_id

                txt_Amount.Text = T_Transaction.Amount
                txt_Cheque_no.Text = T_Transaction.Cheque_no
                txt_Cheque_date.Text = T_Transaction.Cheque_date
                txt_Bank_name.Text = T_Transaction.Bank_name
                txt_Bank_branch.Text = T_Transaction.Bank_branch
                txt_Transcation_description.Text = T_Transaction.Transcation_description
                txt_Created_by.Text = T_Transaction.Created_by
                txt_Created_date.Text = T_Transaction.Created_date


            Else

                T_Msg = "Error Retrieving Transaction Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If


        Catch ex As Exception

            T_Msg = "Error Decoding Transaction Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Transaction = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If
    End Sub
    Sub saveTransactionInformation()

        Dim T_Transaction As New Transaction
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try
            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Transaction.Transaction_Id = T_Id

            T_Transaction.Transaction_Type_Id = ddl_Transaction_type_id.SelectedValue
            T_Transaction.Transaction_ref_id = txt_Transaction_ref_id.Text

            T_Transaction.Amount = txt_Amount.Text
            T_Transaction.Cheque_no = txt_Cheque_no.Text
            T_Transaction.Cheque_date = txt_Cheque_date.Text
            T_Transaction.Bank_name = txt_Bank_name.Text
            T_Transaction.Bank_branch = txt_Bank_branch.Text
            T_Transaction.Transcation_description = txt_Transcation_description.Text
            T_Transaction.Created_by = txt_Created_by.Text
            T_Transaction.Created_date = txt_Created_date.Text
           
            T_Transaction.By = Session("User_Id")
            T_Transaction.executeUpdateTransaction()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Updating Transaction Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Updating Transaction Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Transaction = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("Transaction_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub
    Sub setLookups()

        Dim T_Lookup As New PLookup


        T_Lookup.bindTransactionTypeList(ddl_Transaction_type_id)


        T_Lookup = Nothing

    End Sub
End Class