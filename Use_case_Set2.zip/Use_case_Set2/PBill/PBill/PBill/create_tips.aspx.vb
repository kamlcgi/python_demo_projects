﻿Public Class create_tips
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            setLookups()

        End If
    End Sub

    Protected Sub create_Tips(ByVal sender As Object, ByVal e As EventArgs) Handles btn_create_Tips.Click

        createTipsInformation()

    End Sub

    Sub createTipsInformation()

        Dim T_Tips As New Tips
        Dim T_Security As New PAL_Security
        Dim T_Msg As String = ""

        Try

            T_Tips.Tip_id = ddl_Tips_id.SelectedValue
            T_Tips.Tip_name = txt_Tips_name.Text
            T_Tips.Tip_description = txt_Tips_description.Text

            T_Tips.File_type_id = ddl_File_type_id.SelectedValue
            T_Tips.File_location = txt_File_location.Text
          

            T_Tips.By = Session("user_Id")
            T_Tips.executeCreateTips()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Creating New Tips Information."
                T_Security.Browser(Request)
                T_Security.By = Session("user_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Creating New Tips Information."
            T_Security.Browser(Request)
            T_Security.By = Session("user_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("tips_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindFileTypeList(ddl_Tips_id)

        T_Lookup = Nothing

    End Sub

End Class