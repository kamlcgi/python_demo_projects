﻿Imports Microsoft.VisualBasic

Imports System.Web
Imports System.Data
Imports System.Data.SqlClient

Public Class Transaction

    Protected intErr As Integer
    Protected strErr As String
    Protected strBy As String


    Protected strTransactionId As String
    Protected intTransactionTypeId As Integer
    Protected strTransactionRefId As String
    Protected intAmount As Integer
    Protected strChequeNo As String
    Protected dtChequeDate As Date

    Protected strBankName As String
    Protected strBankBranch As String
    Protected strTranscationDescription As String
    Protected strCreatedBy As String
    Protected dtCreatedDate As Date


    Protected gvData As GridView
    Protected dsData As SqlDataSource
    Public Sub Clear()
        intErr = Nothing
        strErr = Nothing
        strBy = Nothing
        strTransactionId = Nothing
        intTransactionTypeId = Nothing
        strTransactionRefId = Nothing
        intAmount = Nothing
        strChequeNo = Nothing
        dtChequeDate = Nothing

        strBankName = Nothing
        strBankBranch = Nothing
        strTranscationDescription = Nothing
        strCreatedBy = Nothing
        dtCreatedDate = Nothing

        gvData = Nothing
        dsData = Nothing
    End Sub
    Public Property Error_Id() As Integer
        Get
            Return intErr
        End Get
        Set(ByVal Value As Integer)
            intErr = Value
        End Set
    End Property

    Public Property Error_Message() As String
        Get
            Return strErr
        End Get
        Set(ByVal Value As String)
            strErr = Value
        End Set
    End Property
    Public Property By() As String
        Get
            Return strBy
        End Get
        Set(ByVal Value As String)
            strBy = Value
        End Set
    End Property
    Public Property Transaction_id() As String
        Get
            Return strTransactionId
        End Get
        Set(ByVal Value As String)
            strTransactionId = Value
        End Set
    End Property
    Public Property Transaction_type_id() As Integer
        Get
            Return intTransactionTypeId
        End Get
        Set(ByVal Value As Integer)
            intTransactionTypeId = Value
        End Set
    End Property
    Public Property Transaction_ref_id() As String
        Get
            Return strTransactionRefId
        End Get
        Set(ByVal Value As String)
            strTransactionRefId = Value
        End Set
    End Property
    Public Property Amount() As Integer
        Get
            Return intAmount
        End Get
        Set(ByVal Value As Integer)
            intAmount = Value
        End Set
    End Property
    Public Property Cheque_no() As String
        Get
            Return strChequeNo
        End Get
        Set(ByVal Value As String)
            strChequeNo = Value
        End Set
    End Property

    Public Property Cheque_date() As Date
        Get
            Return dtChequeDate
        End Get
        Set(ByVal Value As Date)
            dtChequeDate = Value
        End Set
    End Property
    Public Property Bank_name() As String
        Get
            Return strBankName
        End Get
        Set(ByVal Value As String)
            strBankName = Value
        End Set
    End Property
    Public Property Bank_branch() As String
        Get
            Return strBankBranch
        End Get
        Set(ByVal Value As String)
            strBankBranch = Value
        End Set
    End Property
    Public Property Transcation_description() As String
        Get
            Return strTranscationDescription
        End Get
        Set(ByVal Value As String)
            strTranscationDescription = Value
        End Set
    End Property
    Public Property Created_By() As String
        Get
            Return strCreatedBy
        End Get
        Set(ByVal Value As String)
            strCreatedBy = Value
        End Set
    End Property
    Public Property Created_Date() As Date
        Get
            Return dtCreatedDate
        End Get
        Set(ByVal Value As Date)
            dtCreatedDate = Value
        End Set
    End Property


    Public Property DS_Data() As SqlDataSource
        Get
            Return dsData
        End Get
        Set(ByVal Value As SqlDataSource)
            dsData = Value
        End Set
    End Property

    Public Property GV_Data() As GridView
        Get
            Return gvData
        End Get
        Set(ByVal Value As GridView)
            gvData = Value
        End Set
    End Property
    Public Sub executeSelectTransaction()

        If Not IsDBNull(strTransactionId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the user information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_transaction", _
                         New SqlParameter("@Transaction_id", strTransactionId))

            If dbRs.Read Then

                If Not IsDBNull(dbRs("Transaction_type_id")) Then
                    intTransactionTypeId = dbRs("Transaction_type_id")
                End If

                If Not IsDBNull(dbRs("Transaction_ref_id")) Then
                    strTransactionRefId = dbRs("Transaction_ref_id")
                End If

                If Not IsDBNull(dbRs("Amount")) Then
                    intAmount = dbRs("Amount")
                End If

                If Not IsDBNull(dbRs("Cheque_no")) Then
                    strChequeNo = dbRs("Cheque_no")
                End If
                If Not IsDBNull(dbRs("Cheque_date")) Then
                    dtChequeDate = dbRs("Cheque_date")
                End If

                If Not IsDBNull(dbRs("Bank_name")) Then
                    strBankName = dbRs("Bank_name")
                End If

                If Not IsDBNull(dbRs("Bank_branch")) Then
                    strBankBranch = dbRs("Bank_branch")
                End If
                If Not IsDBNull(dbRs("Transcation_description")) Then
                    strTranscationDescription = dbRs("Transcation_description")
                End If


                If Not IsDBNull(dbRs("Created_by")) Then
                    strCreatedBy = dbRs("Created_by")
                End If

                If Not IsDBNull(dbRs("Created_date")) Then
                    dtCreatedDate = dbRs("Created_date")
                End If


                intErr = 0 'Record found
                strErr = ""

            Else
                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 'Id is Nothing
            strErr = "UserId is Nothing"

        End If

    End Sub 'executeSelectTransaction()
    Public Sub executeCreateTransaction()


        Dim dbCon As New DBAccess
        Dim T_id As String

        'Create New Transaction  to the database 

        T_id = dbCon.RunSPReturnId("dbo.sp_create_transaction_wiz", _
                                          New SqlParameter("@Transaction_id", strTransactionId), _
                                          New SqlParameter("@Transaction_type_id", intTransactionTypeId), _
                                          New SqlParameter("@Transaction_ref_id", strTransactionRefId), _
                                          New SqlParameter("@Amount", intAmount), _
                                          New SqlParameter("@Cheque_no", strChequeNo),
                                          New SqlParameter("@Cheque_date", dtChequeDate),
                                          New SqlParameter("@Bank_name", strBankName),
                                          New SqlParameter("@Bank_branch", strBankBranch),
                                          New SqlParameter("@Transcation_description", strTranscationDescription),
                                          New SqlParameter("@Created_by", strCreatedBy),
                                          New SqlParameter("@Created_date", dtCreatedDate))

        If T_id = "-1" Then

            intErr = -1 'Create New Transaction Failed
            strErr = "Create New Transaction Failed"

        Else

            intErr = 0 'New Transaction Created Successfully
            strErr = "New Transaction Created Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeCreateTransaction()
    Public Sub executeUpdateTransaction()


        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Save Transaction  Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_transaction_wiz", _
                                         New SqlParameter("@Transaction_id", strTransactionId), _
                                          New SqlParameter("@Transaction_type_id", intTransactionTypeId), _
                                          New SqlParameter("@Transaction_ref_id", strTransactionRefId), _
                                          New SqlParameter("@Amount", intAmount), _
                                          New SqlParameter("@Cheque_no", strChequeNo),
                                          New SqlParameter("@Cheque_date", dtChequeDate),
                                          New SqlParameter("@Bank_name", strBankName),
                                          New SqlParameter("@Bank_branch", strBankBranch),
                                          New SqlParameter("@Transcation_description", strTranscationDescription),
                                          New SqlParameter("@Created_by", strCreatedBy),
                                          New SqlParameter("@Created_date", dtCreatedDate))




        If T_id = "-1" Then

            intErr = -1 'Update Transaction  Failed
            strErr = "Update Transaction  Failed"

        Else

            intErr = 0 'Transaction  Information Saved Successfully
            strErr = "Transaction Information Saved Successfully"

        End If

        dbCon = Nothing


    End Sub ' executeUpdateTransaction()
    Public Sub executeDeleteTransaction()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Delete Transaction Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_delete_transaction_wiz", _
                         New SqlParameter("@Transaction_id", strTransactionId))


        If T_id = "-1" Then

            intErr = -1 'Delete Transaction Failed
            strErr = "Delete Transaction Failed"

        Else

            intErr = 0 'Transaction Information Deleted Successfully
            strErr = "Transaction Information Deleted Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeleteTransaction()
    Public Sub selectAllTransaction()

        Dim dbCon As New DBAccess

        'Get all the Transaction information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_transaction	"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub


End Class

