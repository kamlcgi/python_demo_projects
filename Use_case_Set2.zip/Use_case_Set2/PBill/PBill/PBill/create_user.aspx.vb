﻿Public Class create_user
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            setLookups()

        End If

    End Sub

    Protected Sub create_user(ByVal sender As Object, ByVal e As EventArgs) Handles btn_create_user.Click

        createUserInformation()

    End Sub

    Sub createUserInformation()

        Dim T_Security As New PAL_Security
        Dim T_Msg As String = ""

        Try

            T_Security.First_Name = txt_first_name.Text
            T_Security.Last_Name = txt_last_name.Text
            T_Security.Address1 = txt_address1.Text
            T_Security.Address2 = txt_address2.Text
            T_Security.City = txt_city.Text
            T_Security.Zip = txt_zip.Text
            T_Security.State_Id = ddl_state.SelectedValue
            T_Security.Country_Id = ddl_country.SelectedValue
            T_Security.Phone = txt_phone.Text
            T_Security.Mobile = txt_mobile.Text
            T_Security.Fax = txt_fax.Text
            T_Security.Email = txt_email.Text
            T_Security.Website = txt_website.Text

            T_Security.User_Name = txt_user_name.Text
            T_Security.Password = txt_password.Text
            T_Security.Role_Id = ddl_role.SelectedValue
            T_Security.By = Session("User_Id")
            T_Security.executeCreateUser()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Creating New User Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Creating New User Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("user_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindCountryList(ddl_country)
        T_Lookup.bindStateList(ddl_state, 1)
        T_Lookup.bindRoleList(ddl_role)

        T_Lookup = Nothing

    End Sub

End Class