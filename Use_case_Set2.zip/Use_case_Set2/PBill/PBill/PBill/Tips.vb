﻿
'Component Name: Tips
'Description: Used to Create, Update, View and Delete Tips Information
'Author:  Srinivasan Subbanchattiar 
'Created By: Arpita das 
'Created Date: 15/11/2011 
'Modified By:  Arpita das 
'Modified Date: 15/11/2011 
'Version: 1.0

Imports System.Web
Imports System.Data
Imports System.Data.SqlClient



Public Class Tips
    Protected intErr As Integer
    Protected strErr As String
    Protected strBy As String

    Protected strTipId As String
    Protected strTipName As String
    Protected strTipDescription As String
    Protected intFileTypeId As Integer
    Protected strFileLocation As String
    Protected dtModifiedDate As Date
    Protected strModifiedBy As String
    Protected charPost As Char

    Protected gvData As GridView
    Protected dsData As SqlDataSource

    Public Sub New()

        Clear()

    End Sub

    Public Sub Clear()

        intErr = Nothing
        strErr = Nothing
        strBy = Nothing

        strTipId = Nothing
        strTipName = Nothing
        strTipDescription = Nothing
        intFileTypeId = Nothing
        strFileLocation = Nothing
        dtModifiedDate = Nothing
        strModifiedBy = Nothing
        charPost = Nothing

        gvData = Nothing
        dsData = Nothing
    End Sub
    Public Property Error_Id() As Integer
        Get
            Return intErr
        End Get
        Set(ByVal Value As Integer)
            intErr = Value
        End Set
    End Property

    Public Property Error_Message() As String
        Get
            Return strErr
        End Get
        Set(ByVal Value As String)
            strErr = Value
        End Set
    End Property
   
    Public Property By() As String
        Get
            Return strBy
        End Get
        Set(ByVal Value As String)
            strBy = Value
        End Set
    End Property
    Public Property Tip_id() As String
        Get
            Return strTipId
        End Get
        Set(ByVal Value As String)
            strTipId = Value
        End Set
    End Property
    Public Property Tip_name() As String
        Get
            Return strTipName
        End Get
        Set(ByVal Value As String)
            strTipName = Value
        End Set
    End Property
    Public Property Tip_description() As String
        Get
            Return strTipDescription
        End Get
        Set(ByVal Value As String)
            strTipDescription = Value
        End Set
    End Property
    Public Property File_type_id() As Integer
        Get
            Return intFileTypeId
        End Get
        Set(ByVal Value As Integer)
            intFileTypeId = Value
        End Set
    End Property
    Public Property File_location() As String
        Get
            Return strFileLocation
        End Get
        Set(ByVal Value As String)
            strFileLocation = Value
        End Set
    End Property

    Public Property Modified_date() As Date
        Get
            Return dtModifiedDate
        End Get
        Set(ByVal Value As Date)
            dtModifiedDate = Value
        End Set
    End Property
    Public Property Modified_by() As String
        Get
            Return strModifiedBy
        End Get
        Set(ByVal Value As String)
            strModifiedBy = Value
        End Set
    End Property
    Public Property Post() As Char
        Get
            Return charPost
        End Get
        Set(ByVal Value As Char)
            charPost = Value
        End Set
    End Property
    Public Property DS_Data() As SqlDataSource
        Get
            Return dsData
        End Get
        Set(ByVal Value As SqlDataSource)
            dsData = Value
        End Set
    End Property

    Public Property GV_Data() As GridView
        Get
            Return gvData
        End Get
        Set(ByVal Value As GridView)
            gvData = Value
        End Set
    End Property
    Public Sub selectAllTips()

        Dim dbCon As New DBAccess

        'Get all the Tips information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_tips"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub
    Public Sub executeSelectTips()

        If Not IsDBNull(strTipId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the Tips information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_tips", _
                         New SqlParameter("@Tip_id", strTipId))

            If dbRs.Read Then

                If Not IsDBNull(dbRs("Tip_name")) Then
                    strTipName = dbRs("Tip_name")
                End If

                If Not IsDBNull(dbRs("Tip_description")) Then
                    strTipDescription = dbRs("Tip_description")
                End If

                If Not IsDBNull(dbRs("File_type_id")) Then
                    intFileTypeId = dbRs("File_type_id")
                End If

                If Not IsDBNull(dbRs("File_location")) Then
                    strFileLocation = dbRs("File_location")
                End If
                If Not IsDBNull(dbRs("Modified_date")) Then
                    dtModifiedDate = dbRs("Modified_date")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 'Id is Nothing
            strErr = "TipsId is Nothing"

        End If

    End Sub 'executeSelectTips()

    Public Sub executeCreateTips()


        Dim dbCon As New DBAccess
        Dim T_Tip_id As String

        'Create New Tips to the database         

        T_Tip_id = dbCon.RunSPReturnId("dbo.sp_insert_tips_wiz", _
                                        New SqlParameter("@Tip_id", strTipId), _
                                        New SqlParameter("@Tip_name", strTipName), _
                                        New SqlParameter("@Tip_description", strTipDescription), _
                                        New SqlParameter("@File_type_id", intFileTypeId), _
                                        New SqlParameter("@File_location", strTipDescription), _
                                        New SqlParameter("@Modified_date", dtModifiedDate), _
                                        New SqlParameter("@Modified_by", strModifiedBy), _
                                        New SqlParameter("@strModifiedBy", Modified_by))


        If T_Tip_id = "-1" Then

            intErr = -1 'Create New Tips Failed
            strErr = "Create New Tips Failed"

        Else

            intErr = 0 'New Tips Created Successfully
            strErr = "New Tips Created Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeCreateTips()


    Public Sub executeUpdateTips()

        Dim dbCon As New DBAccess
        Dim T_Tip_id As Integer

        'Save Tips Information to the database 

        T_Tip_id = dbCon.RunSPReturnInteger("dbo.sp_update_tips_wiz", _
                                        New SqlParameter("@Tip_id", strTipId), _
                                        New SqlParameter("@Tip_name", strTipName), _
                                        New SqlParameter("@Tip_description", strTipDescription), _
                                        New SqlParameter("@File_type_id", intFileTypeId), _
                                        New SqlParameter("@File_location", strTipDescription), _
                                        New SqlParameter("@Modified_date", dtModifiedDate), _
                                        New SqlParameter("@Modified_by", strModifiedBy), _
                                        New SqlParameter("@strModifiedBy", Modified_by))

        If T_Tip_id = -1 Then

            intErr = -1 'Update Tips Failed
            strErr = "Update Tip Failed"

        Else

            intErr = 0 'Tips Information Saved Successfully
            strErr = "Tip Information Saved Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateTips()



    Public Sub executeDeleteTips()

        Dim dbCon As New DBAccess
        Dim T_Tip_id As Integer

        'Delete Tips Information from the database 

        T_Tip_id = dbCon.RunSPReturnInteger("dbo.sp_delete_tips_wiz", _
                         New SqlParameter("@Tip_id", strTipId), _
                         New SqlParameter("@modified_by", strBy))

        If T_Tip_id = "-1" Then

            intErr = -1 'Delete Tips Failed
            strErr = "Delete Tips Failed"

        Else

            intErr = 0 'Tips Information Deleted Successfully
            strErr = "Tips Information Deleted Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeleteTips()
End Class


