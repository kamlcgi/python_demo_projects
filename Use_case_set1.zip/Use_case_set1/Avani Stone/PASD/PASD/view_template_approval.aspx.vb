﻿Public Class view_template_approval
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            getWorkOrderInformation()

        End If

    End Sub

    Protected Sub approve_template(ByVal sender As Object, ByVal e As EventArgs) Handles btn_approve.Click

        saveTemplateInformation("1")

    End Sub

    Protected Sub reject_template(ByVal sender As Object, ByVal e As EventArgs) Handles btn_reject.Click

        saveTemplateInformation("0")

    End Sub

    Sub saveTemplateInformation(ByVal T_Approve As String)

        Dim T_Work_Order As New Work_Order
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Work_Order.Work_Order_Id = T_Id

            T_Work_Order.Template_Accepted = T_Approve
           
            T_Work_Order.By = Session("User_Id")
            T_Work_Order.executeUpdateTemplateAccepted()

            If T_Work_Order.Error_Id <> 0 Then

                T_Msg = "Error Approving Template Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Approving Template Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Work_Order = Nothing
        T_Security = Nothing
        T_Encryption = Nothing

        If T_Msg = "" Then
            Response.Redirect("template_approval_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub getWorkOrderInformation()

        Dim T_Work_Order As New Work_Order
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Work_Order.Work_Order_Id = T_Id

            T_Work_Order.executeSelectWorkOrder()

            If T_Work_Order.Error_Id = 0 Then
                T_Work_Order.executeSelectWorkOrderTemplate()
            End If

            If T_Work_Order.Error_Id = 0 Then

                txt_work_order_number.Text = T_Work_Order.Work_Order_Number
                txt_purchase_order_no.Text = T_Work_Order.Purchase_Order_Number
                txt_purchase_order_date.Text = T_Work_Order.Purchase_Order_Date
                txt_requested_start_date.Text = T_Work_Order.Requested_Start_Date
                txt_work_order_comments.Text = T_Work_Order.Comments

                txt_sink_status.Text = T_Work_Order.Sink_Status_Description
                txt_faucet_status.Text = T_Work_Order.Faucet_Status_Description
                txt_kitchen_island.Text = T_Work_Order.Kitchen_Island
                txt_cabinets.Text = T_Work_Order.Cabinets

                txt_quote_detail_no.Text = T_Work_Order.Quote_Detail_No
                txt_quote_name.Text = T_Work_Order.Quote_Name
                txt_quote_description.Text = T_Work_Order.Quote_Description
                txt_address1.Text = T_Work_Order.Address1
                txt_address2.Text = T_Work_Order.Address2
                txt_city.Text = T_Work_Order.City
                txt_zip.Text = T_Work_Order.Zip

                txt_state.Text = T_Work_Order.State_Name
                txt_country.Text = T_Work_Order.Country_Name

                txt_phone.Text = T_Work_Order.Phone
                txt_mobile.Text = T_Work_Order.Mobile
                txt_fax.Text = T_Work_Order.Fax
                txt_email.Text = T_Work_Order.Email
                txt_floor.Text = T_Work_Order.Floor

                txt_template_type.Text = T_Work_Order.Template_Type_Description
                txt_construction_type.Text = T_Work_Order.Construction_Type_Description
                txt_sink_type.Text = T_Work_Order.Sink_Type_Descrption
                txt_no_of_sink.Text = T_Work_Order.No_of_Sink

                If T_Work_Order.Back_Splash = "1" Then
                    txt_back_splash.Text = "Yes"
                Else
                    txt_back_splash.Text = "No"
                End If

                txt_back_splash_details.Text = T_Work_Order.Back_Splash_Details

                If T_Work_Order.Mill_Down = "1" Then
                    txt_mill_down.Text = "Yes"
                Else
                    txt_mill_down.Text = "No"
                End If

                txt_mill_down_details.Text = T_Work_Order.Mill_Down_Details

                txt_stove_type.Text = T_Work_Order.Stove_Type_Descrption

                txt_faucet_type.Text = T_Work_Order.Faucet_Type_Descrption
                img_edge_type_file.ImageUrl = "./images/" + T_Work_Order.Edge_Type_File

                txt_edge_type_details.Text = T_Work_Order.Edge_Type_Details

                If T_Work_Order.Cutouts = "1" Then
                    txt_cutouts.Text = "Yes"
                Else
                    txt_cutouts.Text = "No"
                End If

                txt_cutouts_qty.Text = T_Work_Order.Cutouts_Quantity

                txt_material.Text = T_Work_Order.Material_Name
                txt_thickness.Text = T_Work_Order.Thickness_Description

                If T_Work_Order.Top_Removal = "1" Then
                    txt_top_removal.Text = "Yes"
                Else
                    txt_top_removal.Text = "No"
                End If

                txt_work_order_comments.Text = T_Work_Order.Work_Order_Comments

                txt_template_date.Text = T_Work_Order.Template_Date
                txt_time_slot.Text = T_Work_Order.Time_Slot_Description
                txt_template_by.Text = T_Work_Order.Template_By
                txt_estimate_sqft.Text = T_Work_Order.Estimate_SQFT
                txt_actual_sqft.Text = T_Work_Order.Actual_SQFT

                If T_Work_Order.Template_Completed = "1" Then
                    txt_template_completed.Text = "Yes"
                Else
                    txt_template_completed.Text = "No"
                End If

            Else

                T_Msg = "Error Viewing Work Order Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Viewing Work Order Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Work_Order = Nothing
        T_Security = Nothing
        T_Encryption = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


End Class