﻿Public Class create_page
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            setLookups()

        End If

    End Sub

    Protected Sub create_page(ByVal sender As Object, ByVal e As EventArgs) Handles btn_create.Click

        createPageInformation()

    End Sub

    Sub createPageInformation()

        Dim T_Security As New PAL_Security
        Dim T_Msg As String = ""

        Try

            T_Security.Parent_Page_Id = ddl_page_list.SelectedValue
            T_Security.Page_Title = txt_page_title.Text
            T_Security.Page_Description = txt_page_description.Text
            T_Security.Navigate_Url = txt_navigate_url.Text

            T_Security.By = Session("User_Id")
            T_Security.executeCreatePage()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Creating New Page Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Creating New Page Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("page_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindParentPageList(ddl_page_list)
        ddl_page_list.Items.Insert(0, New ListItem("No Parent Page", "-1"))
        ddl_page_list.Items.Insert(0, New ListItem("Parent Page", "0"))

        T_Lookup = Nothing

    End Sub

End Class