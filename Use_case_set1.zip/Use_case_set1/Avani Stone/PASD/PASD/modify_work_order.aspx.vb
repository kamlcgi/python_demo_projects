﻿Public Class modify_work_order
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            setLookups()
            getWorkOrderInformation()

        End If

    End Sub

    Sub getWorkOrderInformation()

        Dim T_Work_Order As New Work_Order
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Work_Order.Work_Order_Id = T_Id

            T_Work_Order.executeSelectWorkOrder()

            If T_Work_Order.Error_Id = 0 Then

                txt_work_order_number.Text = T_Work_Order.Work_Order_Number
                txt_purchase_order_no.Text = T_Work_Order.Purchase_Order_Number
                txt_purchase_order_date.Text = T_Work_Order.Purchase_Order_Date
                txt_requested_start_date.Text = T_Work_Order.Requested_Start_Date
                txt_work_order_comments.Text = T_Work_Order.Comments

                ddl_sink_status.SelectedValue = T_Work_Order.Sink_Status_Id
                ddl_faucet_status.SelectedValue = T_Work_Order.Faucet_Status_Id
                txt_kitchen_island.Text = T_Work_Order.Kitchen_Island
                txt_cabinets.Text = T_Work_Order.Cabinets

                If T_Work_Order.Template = "1" Then
                    chk_template.Checked = True
                Else
                    chk_template.Checked = False
                End If

                If T_Work_Order.Fabrication = "1" Then
                    chk_fabrication.Checked = True
                Else
                    chk_fabrication.Checked = False
                End If

                If T_Work_Order.Installation = "1" Then
                    chk_installation.Checked = True
                Else
                    chk_installation.Checked = True = False
                End If

                If T_Work_Order.Repair = "1" Then
                    chk_repair.Checked = True
                Else
                    chk_repair.Checked = False
                End If


                txt_quote_detail_no.Text = T_Work_Order.Quote_Detail_No
                txt_quote_name.Text = T_Work_Order.Quote_Name
                txt_quote_description.Text = T_Work_Order.Quote_Description
                txt_address1.Text = T_Work_Order.Address1
                txt_address2.Text = T_Work_Order.Address2
                txt_city.Text = T_Work_Order.City
                txt_zip.Text = T_Work_Order.Zip

                txt_state.Text = T_Work_Order.State_Name
                txt_country.Text = T_Work_Order.Country_Name

                txt_phone.Text = T_Work_Order.Phone
                txt_mobile.Text = T_Work_Order.Mobile
                txt_fax.Text = T_Work_Order.Fax
                txt_email.Text = T_Work_Order.Email
                ddl_floor.SelectedValue = T_Work_Order.Floor

                ddl_template_type.SelectedValue = T_Work_Order.Template_Type_Id
                ddl_construction_type.SelectedValue = T_Work_Order.Construction_Type_Id
                ddl_sink_type.SelectedValue = T_Work_Order.Sink_Type_Id
                ddl_no_of_sink.SelectedValue = T_Work_Order.No_of_Sink

                If T_Work_Order.Back_Splash = "1" Then
                    chk_back_splash.Checked = True
                Else
                    chk_back_splash.Checked = False
                End If

                txt_back_splash_details.Text = T_Work_Order.Back_Splash_Details

                If T_Work_Order.Mill_Down = "1" Then
                    chk_mill_down.Checked = True
                Else
                    chk_mill_down.Checked = False
                End If

                txt_mill_down_details.Text = T_Work_Order.Mill_Down_Details

                ddl_stove_type.SelectedValue = T_Work_Order.Stove_Type_Id

                ddl_faucet_type.SelectedValue = T_Work_Order.Faucet_Type_Id

                ddl_edge_type.SelectedValue = T_Work_Order.Edge_Type_Id
                txt_edge_type_details.Text = T_Work_Order.Edge_Type_Details

                If T_Work_Order.Cutouts = "1" Then
                    chk_cutouts.Checked = True
                Else
                    chk_cutouts.Checked = False
                End If

                ddl_cutouts_qty.SelectedValue = T_Work_Order.Cutouts_Quantity

                ddl_material.SelectedValue = T_Work_Order.Material_Id
                ddl_thickness.SelectedValue = T_Work_Order.Thickness_Id

                If T_Work_Order.Top_Removal = "1" Then
                    chk_top_removal.Checked = True
                Else
                    chk_top_removal.Checked = False
                End If

                txt_work_order_comments.Text = T_Work_Order.Work_Order_Comments

            Else

                T_Msg = "Error Get Work Order Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Get Work Order Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Work_Order = Nothing
        T_Security = Nothing
        T_Encryption = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Protected Sub save_Work_Order(ByVal sender As Object, ByVal e As EventArgs) Handles btn_save.Click

        saveWorkOrderInformation()

    End Sub

    Sub saveWorkOrderInformation()

        Dim T_Work_Order As New Work_Order
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Work_Order.Work_Order_Id = T_Id

            T_Work_Order.Floor = ddl_floor.SelectedValue

            T_Work_Order.Template_Type_Id = ddl_template_type.SelectedValue
            T_Work_Order.Construction_Type_Id = ddl_construction_type.SelectedValue
            T_Work_Order.Sink_Type_Id = ddl_sink_type.SelectedValue

            T_Work_Order.No_of_Sink = ddl_no_of_sink.SelectedValue

            If chk_back_splash.Checked Then
                T_Work_Order.Back_Splash = "1"
            Else
                T_Work_Order.Back_Splash = "0"
            End If

            T_Work_Order.Back_Splash_Details = txt_back_splash_details.Text

            If chk_mill_down.Checked Then
                T_Work_Order.Mill_Down = "1"
            Else
                T_Work_Order.Mill_Down = "0"
            End If

            T_Work_Order.Mill_Down_Details = txt_mill_down_details.Text
            T_Work_Order.Stove_Type_Id = ddl_stove_type.SelectedValue
            T_Work_Order.Faucet_Type_Id = ddl_faucet_type.SelectedValue
            T_Work_Order.Edge_Type_Id = ddl_edge_type.SelectedValue
            T_Work_Order.Edge_Type_Details = txt_edge_type_details.Text

            If chk_cutouts.Checked Then
                T_Work_Order.Cutouts = "1"
            Else
                T_Work_Order.Cutouts = "0"
            End If

            T_Work_Order.Cutouts_Quantity = ddl_cutouts_qty.SelectedValue

            T_Work_Order.Material_Id = ddl_material.SelectedValue
            T_Work_Order.Thickness_Id = ddl_thickness.SelectedValue

            If chk_top_removal.Checked Then
                T_Work_Order.Top_Removal = "1"
            Else
                T_Work_Order.Top_Removal = "0"
            End If

            T_Work_Order.Sink_Status_Id = ddl_sink_status.SelectedValue
            T_Work_Order.Faucet_Status_Id = ddl_faucet_status.SelectedValue
            T_Work_Order.Kitchen_Island = txt_kitchen_island.Text
            T_Work_Order.Cabinets = txt_cabinets.Text

            If chk_template.Checked Then
                T_Work_Order.Template = "1"
            Else
                T_Work_Order.Template = "0"
            End If

            If chk_fabrication.Checked Then
                T_Work_Order.Fabrication = "1"
            Else
                T_Work_Order.Fabrication = "0"
            End If

            If chk_installation.Checked Then
                T_Work_Order.Installation = "1"
            Else
                T_Work_Order.Installation = "0"
            End If

            If chk_repair.Checked Then
                T_Work_Order.Repair = "1"
            Else
                T_Work_Order.Repair = "0"
            End If

            T_Work_Order.By = Session("User_Id")
            T_Work_Order.executeUpdateWorkOrder()

            If T_Work_Order.Error_Id <> 0 Then

                T_Msg = "Error Updating Work Order Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Updating Work Order Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Work_Order = Nothing
        T_Security = Nothing
        T_Encryption = Nothing

        If T_Msg = "" Then
            Response.Redirect("work_order_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindConstructionTypeList(ddl_construction_type)
        T_Lookup.bindTemplateTypeList(ddl_template_type)
        T_Lookup.bindSinkTypeList(ddl_sink_type)
        T_Lookup.bindStoveTypeList(ddl_stove_type)
        T_Lookup.bindFaucetTypeList(ddl_faucet_type)
        T_Lookup.bindEdgeTypeList(ddl_edge_type)
        T_Lookup.bindMaterialList(ddl_material)
        T_Lookup.bindThicknessList(ddl_thickness)

        ddl_edge_type.SelectedValue = 1
        T_Lookup.bindSinkStatusList(ddl_sink_status)
        T_Lookup.bindFaucetStatusList(ddl_faucet_status)

        T_Lookup = Nothing

    End Sub

End Class