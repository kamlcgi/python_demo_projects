﻿Public Class modify_quote
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            getQuoteInformation()

        End If

    End Sub

    Protected Sub view_Quote_Layout(ByVal sender As Object, ByVal e As EventArgs) Handles btn_quote.Click

        getQuoteLayout()

    End Sub


    Protected Sub modify_Quote(ByVal sender As Object, ByVal e As EventArgs) Handles btn_modify_quote.Click

        modifyQuoteInformation()

    End Sub


    Sub modifyQuoteInformation()

        Dim T_Quote As New Quote
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""


        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Quote.Quote_Detail_Id = T_Id
            T_Quote.By = Session("User_Id")

            If upl_estimate.HasFile Then

                T_Quote.Estimate_File_Name = upl_estimate.FileName
                T_Quote.Estimate_File = upl_estimate.PostedFile
                T_Quote.executeAttachEstimate()

            End If

        Catch ex As Exception

            T_Msg = "Error Modify Quote Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Quote = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then

            Response.Redirect("error_message.aspx?msg=" & T_Msg)

        End If

    End Sub

    Sub getQuoteLayout()


        Dim T_Quote As New Quote
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""


        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Quote.Quote_Detail_Id = T_Id
            T_Quote.executeSelectLayout(Response)

        Catch ex As Exception

            T_Msg = "Error Retriving Quote Layout Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Quote = Nothing
        T_Security = Nothing

    End Sub

    Sub getQuoteInformation()

        Dim T_Quote As New Quote
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""


        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Quote.Quote_Detail_Id = T_Id
            T_Quote.executeSelectQuote()

            If T_Quote.Error_Id = 0 Then

                txt_quote_no.Text = T_Quote.Quote_No
                txt_quote_detail_no.Text = T_Quote.Quote_Detail_No
                txt_account_name.Text = T_Quote.Account_Name
                txt_quote_name.Text = T_Quote.Quote_Name
                txt_quote_description.Text = T_Quote.Quote_Description
                txt_address1.Text = T_Quote.Address1
                txt_address2.Text = T_Quote.Address2
                txt_city.Text = T_Quote.City
                txt_zip.Text = T_Quote.Zip

                txt_state.Text = T_Quote.State_Name
                txt_country.Text = T_Quote.Country_Name

                txt_phone.Text = T_Quote.Phone
                txt_mobile.Text = T_Quote.Mobile
                txt_fax.Text = T_Quote.Fax
                txt_email.Text = T_Quote.Email
                txt_floor.Text = T_Quote.Floor

                txt_template_type.Text = T_Quote.Template_Type_Description
                txt_construction_type.Text = T_Quote.Construction_Type_Description
                txt_sink_type.Text = T_Quote.Sink_Type_Descrption
                txt_no_of_sink.Text = T_Quote.No_of_Sink

                If T_Quote.Back_Splash = "1" Then
                    txt_back_splash.Text = "Yes"
                Else
                    txt_back_splash.Text = "No"
                End If

                txt_back_splash_details.Text = T_Quote.Back_Splash_Details

                If T_Quote.Mill_Down = "1" Then
                    txt_mill_down.Text = "Yes"
                Else
                    txt_mill_down.Text = "No"
                End If

                txt_mill_down_details.Text = T_Quote.Mill_Down_Details

                txt_stove_type.Text = T_Quote.Stove_Type_Descrption

                txt_faucet_type.Text = T_Quote.Faucet_Type_Descrption
                img_edge_type_file.ImageUrl = "./images/" + T_Quote.Edge_Type_File

                txt_edge_type_details.Text = T_Quote.Edge_Type_Details

                If T_Quote.Cutouts = "1" Then
                    txt_cutouts.Text = "Yes"
                Else
                    txt_cutouts.Text = "No"
                End If

                txt_cutouts_qty.Text = T_Quote.Cutouts_Quantity

                txt_material.Text = T_Quote.Material_Name
                txt_thickness.Text = T_Quote.Thickness_Description

                If T_Quote.Top_Removal = "1" Then
                    txt_top_removal.Text = "Yes"
                Else
                    txt_top_removal.Text = "No"
                End If

                txt_comments.Text = T_Quote.Comments
                'T_Quote.Requested_By

            Else

                T_Msg = "Error Retriving Quote Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Retriving Quote Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Quote = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

End Class