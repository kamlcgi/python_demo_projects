﻿
Imports System.Web
Imports System.Data
Imports System.Data.SqlClient

Public Class showfile
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try

            Dim T_Encryption As New PAL_Encryption
            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader
            Dim T_File_Name As String = ""
            Dim T_Id As String

            'Get all the file information from the database
            T_Id = T_Encryption.decode(Request.QueryString("id"))

            Const T_SQL As String = "SELECT Quote_Filename, Quote_File FROM dbo.Quote_Detail_File WHERE Quote_detail_id = @ID"

            dbRs = dbCon.RunSQLReturnRS(T_SQL, _
                         New SqlParameter("@ID", T_Id))

            If dbRs.Read Then

                If Not IsDBNull(dbRs("Quote_filename")) Then
                    T_File_Name = dbRs("Quote_filename")
                End If

                Context.Response.ContentType = "image/jpeg"
                Context.Response.AddHeader("content-disposition", "attachment;filename=Tr.jpeg")

                'Response.ContentType = "Application/pdf"

                If Not IsDBNull(dbRs("Quote_file")) Then
                    Response.BinaryWrite(dbRs("Quote_file"))
                End If

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Catch ex As Exception
            Response.Write(ex.ToString())
        End Try

    End Sub




End Class