﻿Public Class customer_manager
    Inherits System.Web.UI.Page

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        setRolePermission()

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        getAllCustomers()

    End Sub

    Private Sub setRolePermission()

        Dim T_Security As New PAL_Security

        T_Security.Role_Id = Session("Role_Id")
        T_Security.Navigate_Url = T_Security.Get_Page(Request)
        T_Security.GV_Data = GV_Customer_Manager
        T_Security.setGVUserPermission("Customer_id", "_Customer.aspx", "id", "Customer_id")

        T_Security = Nothing

    End Sub

    Private Sub getAllCustomers()

        Dim T_Customer As New Customer

        T_Customer.DS_Data = DS_Customer_Manager
        T_Customer.selectAllCustomers()

        T_Customer = Nothing

    End Sub

End Class