﻿Public Class material_manager
    Inherits System.Web.UI.Page


    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        setRolePermission()

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        getAllMaterials()

    End Sub

    Private Sub setRolePermission()

        Dim T_Security As New PAL_Security

        T_Security.Role_Id = Session("Role_Id")
        T_Security.Navigate_Url = T_Security.Get_Page(Request)
        T_Security.GV_Data = GV_Material_Manager
        T_Security.setGVUserPermission("Material_id", "_material.aspx", "id", "Material_id")

        T_Security = Nothing

    End Sub

    Private Sub getAllMaterials()

        Dim T_Material As New Material

        T_Material.DS_Data = DS_Material_Manager
        T_Material.selectAllMaterials()

        T_Material = Nothing

    End Sub

End Class