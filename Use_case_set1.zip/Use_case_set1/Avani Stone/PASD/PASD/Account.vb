﻿
'Component Name: Account
'Description: Used to Create, Update, View and Delete Account Information
'Author:  Srinivasan Subbanchattiar 
'Created By: Srinivasan Subbanchattiar 
'Created Date: 08/01/2011 
'Modified By: Srinivasan Subbanchattiar 
'Modified Date: 08/01/2011 
'Version: 1.0

Imports System.Web
Imports System.Data
Imports System.Data.SqlClient

Public Class Account



    Protected intErr As Integer
    Protected strErr As String
    Protected strBy As String

    Protected strAccountId As String
    Protected strAccountName As String

    Protected strAddressId As String
    Protected strAddress1 As String
    Protected strAddress2 As String
    Protected strCity As String

    Protected intStateId As Integer
    Protected strStateName As String

    Protected intCountryId As Integer
    Protected strCountryName As String
    Protected strZip As String
    Protected strPhone As String
    Protected strMobile As String
    Protected strFax As String
    Protected strEmail As String

    Protected strUserId As String

    Protected gvData As GridView
    Protected dsData As SqlDataSource

    'for view purpose only
    Protected strCreatedBy As String
    Protected dtCreatedDate As Date
    Protected strModifiedBy As String
    Protected dtModifiedDate As Date


    Public Sub New()

        Clear()

    End Sub


    Public Sub Clear()

        intErr = Nothing
        strErr = Nothing
        strBy = Nothing

        strAccountId = Nothing
        strAccountName = Nothing

        strAddressId = Nothing
        strAddress1 = Nothing
        strAddress2 = Nothing
        strCity = Nothing

        intStateId = Nothing
        strStateName = Nothing

        intCountryId = Nothing
        strCountryName = Nothing
        strZip = Nothing
        strPhone = Nothing
        strMobile = Nothing
        strFax = Nothing
        strEmail = Nothing

        strUserId = Nothing

        gvData = Nothing
        dsData = Nothing

        strCreatedBy = Nothing
        dtCreatedDate = Nothing
        strModifiedBy = Nothing
        dtModifiedDate = Nothing


    End Sub

    Public Property Error_Id() As Integer
        Get
            Return intErr
        End Get
        Set(ByVal Value As Integer)
            intErr = Value
        End Set
    End Property

    Public Property Error_Message() As String
        Get
            Return strErr
        End Get
        Set(ByVal Value As String)
            strErr = Value
        End Set
    End Property

    Public Property Account_Id() As String
        Get
            Return strAccountId
        End Get
        Set(ByVal Value As String)
            strAccountId = Value
        End Set
    End Property

    Public Property Account_Name() As String
        Get
            Return strAccountName
        End Get
        Set(ByVal Value As String)
            strAccountName = Value
        End Set
    End Property

    Public Property AddressId() As String
        Get
            Return strAddressId
        End Get
        Set(ByVal Value As String)
            strAddressId = Value
        End Set
    End Property

    Public Property Address1() As String
        Get
            Return strAddress1
        End Get
        Set(ByVal Value As String)
            strAddress1 = Value
        End Set
    End Property

    Public Property Address2() As String
        Get
            Return strAddress2
        End Get
        Set(ByVal Value As String)
            strAddress2 = Value
        End Set
    End Property

    Public Property City() As String
        Get
            Return strCity
        End Get
        Set(ByVal Value As String)
            strCity = Value
        End Set
    End Property

    Public Property State_Id() As Integer
        Get
            Return intStateId
        End Get
        Set(ByVal Value As Integer)
            intStateId = Value
        End Set
    End Property

    Public Property State_Name() As String
        Get
            Return strStateName
        End Get
        Set(ByVal Value As String)
            strStateName = Value
        End Set
    End Property

    Public Property Zip() As String
        Get
            Return strZip
        End Get
        Set(ByVal Value As String)
            strZip = Value
        End Set
    End Property

    Public Property Country_Id() As Integer
        Get
            Return intCountryId
        End Get
        Set(ByVal Value As Integer)
            intCountryId = Value
        End Set
    End Property

    Public Property Country_Name() As String
        Get
            Return strCountryName
        End Get
        Set(ByVal Value As String)
            strCountryName = Value
        End Set
    End Property


    Public Property Phone() As String
        Get
            Return strPhone
        End Get
        Set(ByVal Value As String)
            strPhone = Value
        End Set
    End Property

    Public Property Mobile() As String
        Get
            Return strMobile
        End Get
        Set(ByVal Value As String)
            strMobile = Value
        End Set
    End Property

    Public Property Fax() As String
        Get
            Return strFax
        End Get
        Set(ByVal Value As String)
            strFax = Value
        End Set
    End Property

    Public Property Email() As String
        Get
            Return strEmail
        End Get
        Set(ByVal Value As String)
            strEmail = Value
        End Set
    End Property

    Public Property User_Id() As String
        Get
            Return strUserId
        End Get
        Set(ByVal Value As String)
            strUserId = Value
        End Set
    End Property

    Public Property DS_Data() As SqlDataSource
        Get
            Return dsData
        End Get
        Set(ByVal Value As SqlDataSource)
            dsData = Value
        End Set
    End Property

    Public Property GV_Data() As GridView
        Get
            Return gvData
        End Get
        Set(ByVal Value As GridView)
            gvData = Value
        End Set
    End Property

    Public Property By() As String
        Get
            Return strBy
        End Get
        Set(ByVal Value As String)
            strBy = Value
        End Set
    End Property

    Public Property Created_By() As String
        Get
            Return strCreatedBy
        End Get
        Set(ByVal Value As String)
            strCreatedBy = Value
        End Set
    End Property

    Public Property Modified_By() As String
        Get
            Return strModifiedBy
        End Get
        Set(ByVal Value As String)
            strModifiedBy = Value
        End Set
    End Property

    Public Property Created_Date() As Date
        Get
            Return dtCreatedDate
        End Get
        Set(ByVal Value As Date)
            dtCreatedDate = Value
        End Set
    End Property

    Public Property Modified_Date() As Date
        Get
            Return dtModifiedDate
        End Get
        Set(ByVal Value As Date)
            dtModifiedDate = Value
        End Set
    End Property

    Public Sub selectAllAccounts()

        Dim dbCon As New DBAccess

        'Get all the User information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_Accounts"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub selectAllUsersByAccount()

        Dim dbCon As New DBAccess

        'Get all the User information from the database
        DS_Data.SelectParameters.Clear()
        DS_Data.SelectCommand = "dbo.sp_get_all_users_by_account"
        DS_Data.SelectParameters.Add(New Parameter("Account_id", DbType.String, strAccountId))
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub executeSelectAccount()

        If Not IsDBNull(strAccountId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the user information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_account", _
                         New SqlParameter("@Account_id", strAccountId))

            If dbRs.Read Then

                If Not IsDBNull(dbRs("Account_name")) Then
                    strAccountName = dbRs("Account_name")
                End If

                If Not IsDBNull(dbRs("Address_Id")) Then
                    strAddressId = dbRs("Address_Id")
                End If

                If Not IsDBNull(dbRs("Address1")) Then
                    strAddress1 = dbRs("Address1")
                End If

                If Not IsDBNull(dbRs("Address2")) Then
                    strAddress2 = dbRs("Address2")
                End If

                If Not IsDBNull(dbRs("City")) Then
                    strCity = dbRs("City")
                End If

                If Not IsDBNull(dbRs("State_Id")) Then
                    intStateId = dbRs("State_Id")
                End If
                If Not IsDBNull(dbRs("State_Name")) Then
                    strStateName = dbRs("State_Name")
                End If
                If Not IsDBNull(dbRs("Country_Id")) Then
                    intCountryId = dbRs("Country_Id")
                End If
                If Not IsDBNull(dbRs("Country_Name")) Then
                    strCountryName = dbRs("Country_Name")
                End If
                If Not IsDBNull(dbRs("Zip")) Then
                    strZip = dbRs("Zip")
                End If
                If Not IsDBNull(dbRs("Phone")) Then
                    strPhone = dbRs("Phone")
                End If
                If Not IsDBNull(dbRs("Mobile")) Then
                    strMobile = dbRs("Mobile")
                End If
                If Not IsDBNull(dbRs("Fax")) Then
                    strFax = dbRs("Fax")
                End If
                If Not IsDBNull(dbRs("Email")) Then
                    strEmail = dbRs("Email")
                End If

                If Not IsDBNull(dbRs("Created_by")) Then
                    strCreatedBy = dbRs("Created_by")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                If Not IsDBNull(dbRs("Created_date")) Then
                    dtCreatedDate = dbRs("Created_date")
                End If

                If Not IsDBNull(dbRs("Modified_date")) Then
                    dtModifiedDate = dbRs("Modified_date")
                End If

                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 'Id is Nothing
            strErr = "UserId is Nothing"

        End If

    End Sub 'executeSelectAccount()


    Public Sub executeCreateAccount()


        Dim dbCon As New DBAccess
        Dim T_User_id As String

        'Create New Account to the database 

        T_User_id = dbCon.RunSPReturnId("dbo.sp_create_account_wiz", _
                         New SqlParameter("@Account_name", strAccountName), _
                         New SqlParameter("@address1", strAddress1), _
                         New SqlParameter("@address2", strAddress2), _
                         New SqlParameter("@city", strCity), _
                         New SqlParameter("@state_id", intStateId), _
                         New SqlParameter("@zip", strZip), _
                         New SqlParameter("@country_id", intCountryId), _
                         New SqlParameter("@phone", strPhone), _
                         New SqlParameter("@mobile", strMobile), _
                         New SqlParameter("@fax", strFax), _
                         New SqlParameter("@email", strEmail), _
                         New SqlParameter("@created_by", strBy))

        If T_User_id = "-1" Then

            intErr = -1 'Create New Account Failed
            strErr = "Create New Account Failed"

        Else

            intErr = 0 'New Account Created Successfully
            strErr = "New Account Created Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeCreateAccount()


    Public Sub executeUpdateAccount()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Save Account Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_account_wiz", _
                         New SqlParameter("@Account_id", strAccountId), _
                         New SqlParameter("@Account_name", strAccountName), _
                         New SqlParameter("@address1", strAddress1), _
                         New SqlParameter("@address2", strAddress2), _
                         New SqlParameter("@city", strCity), _
                         New SqlParameter("@state_id", intStateId), _
                         New SqlParameter("@zip", strZip), _
                         New SqlParameter("@country_id", intCountryId), _
                         New SqlParameter("@phone", strPhone), _
                         New SqlParameter("@mobile", strMobile), _
                         New SqlParameter("@fax", strFax), _
                         New SqlParameter("@email", strEmail), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = -1 Then

            intErr = -1 'Update Account Failed
            strErr = "Update Account Failed"

        Else

            intErr = 0 'Account Information Saved Successfully
            strErr = "Account Information Saved Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateAccount()



    Public Sub executeDeleteAccount()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Delete Account Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_delete_account_wiz", _
                         New SqlParameter("@Account_id", strAccountId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Delete Account Failed
            strErr = "Delete Account Failed"

        Else

            intErr = 0 'Account Information Deleted Successfully
            strErr = "Account Information Deleted Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeleteAccount()



    Public Sub executeAddContactToAccount()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Add Contact to Account Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_add_contact_to_account", _
                         New SqlParameter("@Account_id", strAccountId), _
                         New SqlParameter("@User_id", strUserId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Add Contact to Account Failed
            strErr = "Add Contact to Account Failed"

        Else

            intErr = 0 'Add Contact to Account Successfully
            strErr = "Add Contact to Account Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeAddContactToAccount()


    Public Sub executeRemoveContactAccount()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Add Contact to Account Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_remove_contact_from_account", _
                         New SqlParameter("@Account_id", strAccountId), _
                         New SqlParameter("@User_id", strUserId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Remove Contact from Account Failed
            strErr = "Remove Contact from Account Failed"

        Else

            intErr = 0 'Remove Contact from Account Successfully
            strErr = "Remove Contact from Account Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeRemoveContactAccount()

End Class
