﻿Public Class Site
    Inherits System.Web.UI.MasterPage

    Protected WithEvents PMain_Menu As Menu

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Check_Page()
        End If

    End Sub

    Sub Check_Page()

        Dim T_Menu As New PAL_Security

        If T_Menu.Check_Page(Session("Role_Id"), Request) <= 0 Then
            Response.Redirect("no_access.aspx")
        Else
            ltl_menu_content.Text = Session("PMenu")
        End If

        T_Menu = Nothing

    End Sub

End Class