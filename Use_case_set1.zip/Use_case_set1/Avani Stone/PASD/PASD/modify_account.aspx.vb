﻿Public Class modify_account
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            setLookups()
            getAccountInformation()
            getAllUsersByAccount()

        End If

    End Sub

    Protected Sub modify_account(ByVal sender As Object, ByVal e As EventArgs) Handles btn_modify_account.Click

        updateAccountInformation()

    End Sub

    Protected Sub add_user(ByVal sender As Object, ByVal e As EventArgs) Handles btn_add.Click

        addContactToAccount()

    End Sub


    Protected Sub gv_rowcommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs) Handles GV_User_Manager.RowCommand

        If e.CommandName = "Remove" Then
            removeContactFromAccount(e.CommandArgument)
        End If

    End Sub

    Protected Sub gv_sorting(ByVal sender As Object, ByVal e As GridViewSortEventArgs) Handles GV_User_Manager.Sorting

          getAllUsersByAccount()

    End Sub



    Sub getAccountInformation()

        Dim T_account As New Account
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_account_Id As String = ""

        Try

            T_account_Id = T_Encryption.decode(Request.QueryString("id"))

            T_account.Account_Id = T_account_Id
            T_account.executeSelectAccount()

            If T_account.Error_Id = 0 Then

                txt_account_name.Text = T_account.Account_Name
                txt_address1.Text = T_account.Address1
                txt_address2.Text = T_account.Address2
                txt_city.Text = T_account.City
                txt_zip.Text = T_account.Zip
                ddl_state.SelectedValue = T_account.State_Id
                ddl_country.SelectedValue = T_account.Country_Id
                txt_phone.Text = T_account.Phone
                txt_mobile.Text = T_account.Mobile
                txt_email.Text = T_account.Email
                txt_fax.Text = T_account.Fax

            Else

                T_Msg = "Error Retrieving Account Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Account Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_account = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub updateAccountInformation()

        Dim T_account As New Account
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""

        Dim T_account_Id As String = ""

        Try

            T_account_Id = T_Encryption.decode(Request.QueryString("id"))

            T_account.Account_Id = T_account_Id

            T_account.Account_Name = txt_account_name.Text
            T_account.Address1 = txt_address1.Text
            T_account.Address2 = txt_address2.Text
            T_account.City = txt_city.Text
            T_account.Zip = txt_zip.Text
            T_account.State_Id = ddl_state.SelectedValue
            T_account.Country_Id = ddl_country.SelectedValue
            T_account.Phone = txt_phone.Text
            T_account.Mobile = txt_mobile.Text
            T_account.Email = txt_email.Text
            T_account.Fax = txt_fax.Text

            T_account.By = Session("User_Id")
            T_account.executeUpdateAccount()

            If T_account.Error_Id <> 0 Then

                T_Msg = "Error Updating Account Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Account Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_account = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("account_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Sub addContactToAccount()

        Dim T_account As New Account
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""

        Dim T_account_Id As String = ""

        Try

            T_account_Id = T_Encryption.decode(Request.QueryString("id"))

            T_account.Account_Id = T_account_Id

            T_account.User_Id = ddl_user_list.SelectedValue
            
            T_account.By = Session("User_Id")
            T_account.executeAddContactToAccount()

            If T_account.Error_Id = 0 Then

                setLookups()
                getAccountInformation()
                getAllUsersByAccount()

            Else

                T_Msg = "Error Adding Contact Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Account Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_account = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub



    Sub removeContactFromAccount(ByVal T_User_id As String)

        Dim T_account As New Account
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""

        Dim T_account_Id As String = ""

        Try

            T_account_Id = T_Encryption.decode(Request.QueryString("id"))

            T_account.Account_Id = T_account_Id
            T_account.User_Id = T_User_id

            T_account.By = Session("User_Id")
            T_account.executeRemoveContactAccount()

            If T_account.Error_Id = 0 Then

                setLookups()
                getAccountInformation()
                getAllUsersByAccount()

            Else


                T_Msg = "Error Removing Contact Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Account Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_account = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Private Sub getAllUsersByAccount()

        Dim T_account As New Account
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_account_Id As String = ""

        Try

            T_account_Id = T_Encryption.decode(Request.QueryString("id"))

            T_account.Account_Id = T_account_Id
            T_account.DS_Data = DS_User_Manager
            T_account.selectAllUsersByAccount()

        Catch ex As Exception

            T_Msg = "Error Decoding Account Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_account = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Sub setLookups()

        Dim T_Lookup As New PLookup
        Dim T_account As New Account
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_account_Id As String = ""

        Try

            T_account_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Lookup.bindCountryList(ddl_country)
            T_Lookup.bindStateList(ddl_state, 1)
            T_Lookup.bindAllUserNotInAccountList(ddl_user_list, T_account_Id)
            ddl_user_list.Items.Insert(0, "-Select-")

        Catch ex As Exception

            T_Msg = "Error Decoding Account Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_account = Nothing
        T_Encryption = Nothing
        T_Security = Nothing
        T_Lookup = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

End Class