﻿Public Class quote_manager_by_user
    Inherits System.Web.UI.Page


    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        setRolePermission()

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        getAllQuotes()

    End Sub

    Private Sub setRolePermission()

        Dim T_Security As New PAL_Security

        T_Security.Role_Id = Session("Role_Id")
        T_Security.Navigate_Url = T_Security.Get_Page(Request)
        T_Security.GV_Data = GV_Quote_Manager
        T_Security.setGVUserPermission("Quote_detail_id", "_quote.aspx", "id", "Quote_detail_id")

        T_Security = Nothing

    End Sub

    Private Sub getAllQuotes()

        Dim T_Quote As New Quote

        T_Quote.By = Session("User_Id")
        T_Quote.DS_Data = DS_Quote_Manager
        T_Quote.selectAllQuotesByUser()

        T_Quote = Nothing

    End Sub

End Class