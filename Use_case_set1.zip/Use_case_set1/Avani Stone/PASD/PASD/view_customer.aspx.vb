﻿Public Class view_customer
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            getCustomerInformation()

        End If

    End Sub

    Sub getCustomerInformation()

        Dim T_Customer As New Customer
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Customer_Id As String = ""

        Try

            T_Customer_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Customer.Customer_Id = T_Customer_Id
            T_Customer.executeSelectCustomer()

            If T_Customer.Error_Id = 0 Then

                txt_first_name.Text = T_Customer.First_Name
                txt_last_name.Text = T_Customer.Last_Name
                txt_address1.Text = T_Customer.Address1
                txt_address2.Text = T_Customer.Address2
                txt_city.Text = T_Customer.City
                txt_zip.Text = T_Customer.Zip
                txt_state.Text = T_Customer.State_Name
                txt_country.Text = T_Customer.Country_Name
                txt_phone.Text = T_Customer.Phone
                txt_mobile.Text = T_Customer.Mobile
                txt_email.Text = T_Customer.Email
                txt_fax.Text = T_Customer.Fax

            Else

                T_Msg = "Error Retrieving Customer Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Customer Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

End Class