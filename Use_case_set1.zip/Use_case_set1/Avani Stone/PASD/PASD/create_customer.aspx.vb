﻿Public Class create_customer
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            setLookups()

        End If

    End Sub

    Protected Sub create_customer(ByVal sender As Object, ByVal e As EventArgs) Handles btn_create_customer.Click

        createCustomerInformation()

    End Sub

    Sub createCustomerInformation()

        Dim T_Customer As New Customer
        Dim T_Security As New PAL_Security
        Dim T_Msg As String = ""

        Try

            T_Customer.First_Name = txt_first_name.Text
            T_Customer.Last_Name = txt_last_name.Text
            T_Customer.Address1 = txt_address1.Text
            T_Customer.Address2 = txt_address2.Text
            T_Customer.City = txt_city.Text
            T_Customer.Zip = txt_zip.Text
            T_Customer.State_Id = ddl_state.SelectedValue
            T_Customer.Country_Id = ddl_country.SelectedValue
            T_Customer.Phone = txt_phone.Text
            T_Customer.Mobile = txt_mobile.Text
            T_Customer.Email = txt_email.Text
            T_Customer.Fax = txt_fax.Text

            T_Customer.By = Session("User_Id")
            T_Customer.executeCreateCustomer()

            If T_Customer.Error_Id <> 0 Then

                T_Msg = "Error Creating New Customer Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Creating New Customer Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Customer = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("customer_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindCountryList(ddl_country)
        T_Lookup.bindStateList(ddl_state, 1)

        T_Lookup = Nothing

    End Sub

End Class