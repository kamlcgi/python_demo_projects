﻿Public Class delete_project
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            getProjectInformation()

        End If

    End Sub

    Protected Sub delete_Project(ByVal sender As Object, ByVal e As EventArgs) Handles btn_delete.Click

        deleteProjectInformation()

    End Sub


    Sub getProjectInformation()

        Dim T_Project As New Project
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Project_Id As String = ""

        Try

            T_Project_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Project.Project_Id = T_Project_Id
            T_Project.executeSelectProject()

            If T_Project.Error_Id = 0 Then

                lbl_text.Text = T_Project.Project_Name

            Else

                T_Msg = "Error Retrieving Project Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Project Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub deleteProjectInformation()

        Dim T_Project As New Project
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Project_Id As String = ""

        Try

            T_Project_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Project.Project_Id = T_Project_Id
            T_Project.By = Session("User_Id")
            T_Project.executeDeleteProject()

            If T_Project.Error_Id <> 0 Then

                T_Msg = "Error Deleting Project Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Deleting Project Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("Project_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

End Class