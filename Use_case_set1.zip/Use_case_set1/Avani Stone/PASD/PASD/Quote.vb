﻿
'Component Name: Quote
'Description: Used to Create, Update, View and Delete Quote Information
'Author:  Srinivasan Subbanchattiar 
'Created By: Srinivasan Subbanchattiar 
'Created Date: 08/01/2011 
'Modified By: Srinivasan Subbanchattiar 
'Modified Date: 08/01/2011 
'Version: 1.0

Imports System.Web
Imports System.Data
Imports System.Data.SqlClient

Public Class Quote


    Protected intErr As Integer
    Protected strErr As String
    Protected strBy As String

    Protected strQuoteId As String
    Protected strQuoteName As String
    Protected strQuoteDescription As String

    Protected strQuoteNo As String
    Protected strQuoteDetailNo As String

    Protected strQuoteDetailId As String

    Protected strAddress1 As String
    Protected strAddress2 As String
    Protected strCity As String

    Protected intStateId As Integer
    Protected strStateName As String

    Protected intCountryId As Integer
    Protected strCountryName As String
    Protected strZip As String
    Protected strPhone As String
    Protected strMobile As String
    Protected strFax As String
    Protected strEmail As String

    Protected strFloor As String

    Protected intTemplateTypeId As Integer
    Protected strTemplateTypeDescription As String

    Protected intConstructionTypeId As Integer
    Protected strConstructionTypeDescription As String

    Protected intSinkTypeId As Integer
    Protected strSinkTypeDescrption As String

    Protected intNoofSink As Integer

    Protected strBackSplash As String
    Protected strBackSplashDetails As String

    Protected strMillDown As String
    Protected strMillDownDetails As String

    Protected intStoveTypeId As Integer
    Protected strStoveTypeDescrption As String

    Protected intFaucetTypeId As Integer
    Protected strFaucetTypeDescrption As String

    Protected intEdgeTypeId As Integer
    Protected strEdgeTypeDescription As String
    Protected strEdgeTypeFile As String
    Protected strEdgeTypeDetails As String

    Protected strCutouts As String
    Protected intCutoutsQuantity As Integer

    Protected strMaterialId As String
    Protected strMaterialName As String

    Protected intThicknessId As Integer
    Protected strThicknessDescription As String

    Protected hpfQuoteFile As HttpPostedFile
    Protected strQuoteFileName As String
    Protected strQuoteFileMime As String

    Protected hpfEstimateFile As HttpPostedFile
    Protected strEstimateFileName As String
    Protected strEstimateFileMime As String

    Protected strTopRemoval As String
    Protected strComments As String

    Protected strRequestedBy As String

    Protected strAccountName As String

    Protected gvData As GridView
    Protected dsData As SqlDataSource

    'for view purpose only
    Protected strCreatedBy As String
    Protected dtCreatedDate As Date
    Protected strModifiedBy As String
    Protected dtModifiedDate As Date


    Public Sub New()

        Clear()

    End Sub


    Public Sub Clear()

        intErr = Nothing
        strErr = Nothing
        strBy = Nothing

        strQuoteId = Nothing
        strQuoteName = Nothing
        strQuoteDescription = Nothing

        strQuoteNo = Nothing
        strQuoteDetailNo = Nothing

        strQuoteDetailId = Nothing

        strAddress1 = Nothing
        strAddress2 = Nothing
        strCity = Nothing

        intStateId = Nothing
        strStateName = Nothing

        intCountryId = Nothing
        strCountryName = Nothing
        strZip = Nothing
        strPhone = Nothing
        strMobile = Nothing
        strFax = Nothing
        strEmail = Nothing

        strFloor = Nothing
        intTemplateTypeId = Nothing
        strTemplateTypeDescription = Nothing

        intConstructionTypeId = Nothing
        strConstructionTypeDescription = Nothing

        intSinkTypeId = Nothing
        strSinkTypeDescrption = Nothing

        intNoofSink = Nothing

        strBackSplash = Nothing
        strBackSplashDetails = Nothing

        strMillDown = Nothing
        strMillDownDetails = Nothing

        intStoveTypeId = Nothing
        strStoveTypeDescrption = Nothing

        intFaucetTypeId = Nothing
        strFaucetTypeDescrption = Nothing

        intEdgeTypeId = Nothing
        strEdgeTypeDescription = Nothing
        strEdgeTypeFile = Nothing
        strEdgeTypeDetails = Nothing

        strCutouts = Nothing
        intCutoutsQuantity = Nothing

        strMaterialId = Nothing
        strMaterialName = Nothing

        intThicknessId = Nothing
        strThicknessDescription = Nothing

        hpfQuoteFile = Nothing
        strQuoteFileName = Nothing
        strQuoteFileMime = Nothing

        hpfEstimateFile = Nothing
        strEstimateFileName = Nothing
        strEstimateFileMime = Nothing

        strTopRemoval = Nothing
        strComments = Nothing
        strRequestedBy = Nothing
        strAccountName = Nothing

        gvData = Nothing
        dsData = Nothing

        strCreatedBy = Nothing
        dtCreatedDate = Nothing
        strModifiedBy = Nothing
        dtModifiedDate = Nothing


    End Sub

    Public Property Error_Id() As Integer
        Get
            Return intErr
        End Get
        Set(ByVal Value As Integer)
            intErr = Value
        End Set
    End Property

    Public Property Error_Message() As String
        Get
            Return strErr
        End Get
        Set(ByVal Value As String)
            strErr = Value
        End Set
    End Property

    Public Property Quote_Id() As String
        Get
            Return strQuoteId
        End Get
        Set(ByVal Value As String)
            strQuoteId = Value
        End Set
    End Property

    Public Property Quote_Detail_Id() As String
        Get
            Return strQuoteDetailId
        End Get
        Set(ByVal Value As String)
            strQuoteDetailId = Value
        End Set
    End Property

    Public Property Quote_No() As String
        Get
            Return strQuoteNo
        End Get
        Set(ByVal Value As String)
            strQuoteNo = Value
        End Set
    End Property


    Public Property Quote_Detail_No() As String
        Get
            Return strQuoteDetailNo
        End Get
        Set(ByVal Value As String)
            strQuoteDetailNo = Value
        End Set
    End Property

    Public Property Account_Name() As String
        Get
            Return strAccountName
        End Get
        Set(ByVal Value As String)
            strAccountName = Value
        End Set
    End Property

    Public Property Quote_Name() As String
        Get
            Return strQuoteName
        End Get
        Set(ByVal Value As String)
            strQuoteName = Value
        End Set
    End Property

    Public Property Quote_Description() As String
        Get
            Return strQuoteDescription
        End Get
        Set(ByVal Value As String)
            strQuoteDescription = Value
        End Set
    End Property

    Public Property Address1() As String
        Get
            Return strAddress1
        End Get
        Set(ByVal Value As String)
            strAddress1 = Value
        End Set
    End Property

    Public Property Address2() As String
        Get
            Return strAddress2
        End Get
        Set(ByVal Value As String)
            strAddress2 = Value
        End Set
    End Property

    Public Property City() As String
        Get
            Return strCity
        End Get
        Set(ByVal Value As String)
            strCity = Value
        End Set
    End Property

    Public Property State_Id() As Integer
        Get
            Return intStateId
        End Get
        Set(ByVal Value As Integer)
            intStateId = Value
        End Set
    End Property

    Public Property State_Name() As String
        Get
            Return strStateName
        End Get
        Set(ByVal Value As String)
            strStateName = Value
        End Set
    End Property

    Public Property Zip() As String
        Get
            Return strZip
        End Get
        Set(ByVal Value As String)
            strZip = Value
        End Set
    End Property

    Public Property Country_Id() As Integer
        Get
            Return intCountryId
        End Get
        Set(ByVal Value As Integer)
            intCountryId = Value
        End Set
    End Property

    Public Property Country_Name() As String
        Get
            Return strCountryName
        End Get
        Set(ByVal Value As String)
            strCountryName = Value
        End Set
    End Property


    Public Property Phone() As String
        Get
            Return strPhone
        End Get
        Set(ByVal Value As String)
            strPhone = Value
        End Set
    End Property

    Public Property Mobile() As String
        Get
            Return strMobile
        End Get
        Set(ByVal Value As String)
            strMobile = Value
        End Set
    End Property

    Public Property Fax() As String
        Get
            Return strFax
        End Get
        Set(ByVal Value As String)
            strFax = Value
        End Set
    End Property

    Public Property Email() As String
        Get
            Return strEmail
        End Get
        Set(ByVal Value As String)
            strEmail = Value
        End Set
    End Property

    Public Property Floor() As String
        Get
            Return strFloor
        End Get
        Set(ByVal Value As String)
            strFloor = Value
        End Set
    End Property

    Public Property Template_Type_Id() As Integer
        Get
            Return intTemplateTypeId
        End Get
        Set(ByVal Value As Integer)
            intTemplateTypeId = Value
        End Set
    End Property

    Public Property Template_Type_Description() As String
        Get
            Return strTemplateTypeDescription
        End Get
        Set(ByVal Value As String)
            strTemplateTypeDescription = Value
        End Set
    End Property

    Public Property Construction_Type_Id() As Integer
        Get
            Return intConstructionTypeId
        End Get
        Set(ByVal Value As Integer)
            intConstructionTypeId = Value
        End Set
    End Property

    Public Property Construction_Type_Description() As String
        Get
            Return strConstructionTypeDescription
        End Get
        Set(ByVal Value As String)
            strConstructionTypeDescription = Value
        End Set
    End Property

    Public Property Sink_Type_Id() As Integer
        Get
            Return intSinkTypeId
        End Get
        Set(ByVal Value As Integer)
            intSinkTypeId = Value
        End Set
    End Property

    Public Property Sink_Type_Descrption() As String
        Get
            Return strSinkTypeDescrption
        End Get
        Set(ByVal Value As String)
            strSinkTypeDescrption = Value
        End Set
    End Property

    Public Property No_of_Sink() As Integer
        Get
            Return intNoofSink
        End Get
        Set(ByVal Value As Integer)
            intNoofSink = Value
        End Set
    End Property

    Public Property Back_Splash() As String
        Get
            Return strBackSplash
        End Get
        Set(ByVal Value As String)
            strBackSplash = Value
        End Set
    End Property

    Public Property Back_Splash_Details() As String
        Get
            Return strBackSplashDetails
        End Get
        Set(ByVal Value As String)
            strBackSplashDetails = Value
        End Set
    End Property


    Public Property Mill_Down() As String
        Get
            Return strMillDown
        End Get
        Set(ByVal Value As String)
            strMillDown = Value
        End Set
    End Property

    Public Property Mill_Down_Details() As String
        Get
            Return strMillDownDetails
        End Get
        Set(ByVal Value As String)
            strMillDownDetails = Value
        End Set
    End Property

    Public Property Stove_Type_Id() As Integer
        Get
            Return intStoveTypeId
        End Get
        Set(ByVal Value As Integer)
            intStoveTypeId = Value
        End Set
    End Property

    Public Property Stove_Type_Descrption() As String
        Get
            Return strStoveTypeDescrption
        End Get
        Set(ByVal Value As String)
            strStoveTypeDescrption = Value
        End Set
    End Property


    Public Property Faucet_Type_Id() As Integer
        Get
            Return intFaucetTypeId
        End Get
        Set(ByVal Value As Integer)
            intFaucetTypeId = Value
        End Set
    End Property

    Public Property Faucet_Type_Descrption() As String
        Get
            Return strFaucetTypeDescrption
        End Get
        Set(ByVal Value As String)
            strFaucetTypeDescrption = Value
        End Set
    End Property

    Public Property Edge_Type_Id() As Integer
        Get
            Return intEdgeTypeId
        End Get
        Set(ByVal Value As Integer)
            intEdgeTypeId = Value
        End Set
    End Property

    Public Property Edge_Type_Description() As String
        Get
            Return strEdgeTypeDescription
        End Get
        Set(ByVal Value As String)
            strEdgeTypeDescription = Value
        End Set
    End Property

    Public Property Edge_Type_File() As String
        Get
            Return strEdgeTypeFile
        End Get
        Set(ByVal Value As String)
            strEdgeTypeFile = Value
        End Set
    End Property

    Public Property Edge_Type_Details() As String
        Get
            Return strEdgeTypeDetails
        End Get
        Set(ByVal Value As String)
            strEdgeTypeDetails = Value
        End Set
    End Property


    Public Property Cutouts() As String
        Get
            Return strCutouts
        End Get
        Set(ByVal Value As String)
            strCutouts = Value
        End Set
    End Property

    Public Property Cutouts_Quantity() As Integer
        Get
            Return intCutoutsQuantity
        End Get
        Set(ByVal Value As Integer)
            intCutoutsQuantity = Value
        End Set
    End Property


    Public Property Material_Id() As String
        Get
            Return strMaterialId
        End Get
        Set(ByVal Value As String)
            strMaterialId = Value
        End Set
    End Property

    Public Property Material_Name() As String
        Get
            Return strMaterialName
        End Get
        Set(ByVal Value As String)
            strMaterialName = Value
        End Set
    End Property

    Public Property Thickness_Id() As Integer
        Get
            Return intThicknessId
        End Get
        Set(ByVal Value As Integer)
            intThicknessId = Value
        End Set
    End Property

    Public Property Thickness_Description() As String
        Get
            Return strThicknessDescription
        End Get
        Set(ByVal Value As String)
            strThicknessDescription = Value
        End Set
    End Property

    Public Property Quote_File() As HttpPostedFile
        Get
            Return hpfQuoteFile
        End Get
        Set(ByVal Value As HttpPostedFile)
            hpfQuoteFile = Value
        End Set
    End Property

    Public Property Quote_File_Name() As String
        Get
            Return strQuoteFileName
        End Get
        Set(ByVal Value As String)
            strQuoteFileName = Value
        End Set
    End Property

    Public Property Quote_File_Mime() As String
        Get
            Return strQuoteFileMime
        End Get
        Set(ByVal Value As String)
            strQuoteFileMime = Value
        End Set
    End Property

    Public Property Estimate_File() As HttpPostedFile
        Get
            Return hpfEstimateFile
        End Get
        Set(ByVal Value As HttpPostedFile)
            hpfEstimateFile = Value
        End Set
    End Property

    Public Property Estimate_File_Name() As String
        Get
            Return strEstimateFileName
        End Get
        Set(ByVal Value As String)
            strEstimateFileName = Value
        End Set
    End Property

    Public Property Estimate_File_Mime() As String
        Get
            Return strEstimateFileMime
        End Get
        Set(ByVal Value As String)
            strEstimateFileMime = Value
        End Set
    End Property

    Public Property Top_Removal() As String
        Get
            Return strTopRemoval
        End Get
        Set(ByVal Value As String)
            strTopRemoval = Value
        End Set
    End Property


    Public Property Comments() As String
        Get
            Return strComments
        End Get
        Set(ByVal Value As String)
            strComments = Value
        End Set
    End Property


    Public Property Requested_By() As String
        Get
            Return strRequestedBy
        End Get
        Set(ByVal Value As String)
            strRequestedBy = Value
        End Set
    End Property


    Public Property DS_Data() As SqlDataSource
        Get
            Return dsData
        End Get
        Set(ByVal Value As SqlDataSource)
            dsData = Value
        End Set
    End Property

    Public Property GV_Data() As GridView
        Get
            Return gvData
        End Get
        Set(ByVal Value As GridView)
            gvData = Value
        End Set
    End Property

    Public Property By() As String
        Get
            Return strBy
        End Get
        Set(ByVal Value As String)
            strBy = Value
        End Set
    End Property

    Public Property Created_By() As String
        Get
            Return strCreatedBy
        End Get
        Set(ByVal Value As String)
            strCreatedBy = Value
        End Set
    End Property

    Public Property Modified_By() As String
        Get
            Return strModifiedBy
        End Get
        Set(ByVal Value As String)
            strModifiedBy = Value
        End Set
    End Property

    Public Property Created_Date() As Date
        Get
            Return dtCreatedDate
        End Get
        Set(ByVal Value As Date)
            dtCreatedDate = Value
        End Set
    End Property

    Public Property Modified_Date() As Date
        Get
            Return dtModifiedDate
        End Get
        Set(ByVal Value As Date)
            dtModifiedDate = Value
        End Set
    End Property

    Public Sub selectAllQuotes()

        Dim dbCon As New DBAccess

        'Get all the User information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_quotes"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub selectAllQuotesByUser()

        Dim dbCon As New DBAccess

        'Get all the User information from the database

        DS_Data.SelectParameters.Clear()
        DS_Data.SelectCommand = "dbo.sp_get_all_quotes_by_user"
        DS_Data.SelectParameters.Add("User_id", strBy)
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub executeSelectQuote()

        If Not IsDBNull(strQuoteDetailId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the user information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_quote", _
                         New SqlParameter("@Quote_Detail_id", strQuoteDetailId))

            If dbRs.Read Then

                If Not IsDBNull(dbRs("Quote_no")) Then
                    strQuoteNo = dbRs("Quote_no")
                End If

                If Not IsDBNull(dbRs("Quote_detail_no")) Then
                    strQuoteDetailNo = dbRs("Quote_detail_no")
                End If

                If Not IsDBNull(dbRs("Account_name")) Then
                    strAccountName = dbRs("Account_name")
                End If

                If Not IsDBNull(dbRs("Quote_Name")) Then
                    strQuoteName = dbRs("Quote_Name")
                End If

                If Not IsDBNull(dbRs("Quote_Description")) Then
                    strQuoteDescription = dbRs("Quote_Description")
                End If

                If Not IsDBNull(dbRs("Address1")) Then
                    strAddress1 = dbRs("Address1")
                End If

                If Not IsDBNull(dbRs("Address2")) Then
                    strAddress2 = dbRs("Address2")
                End If

                If Not IsDBNull(dbRs("City")) Then
                    strCity = dbRs("City")
                End If

                If Not IsDBNull(dbRs("State_Id")) Then
                    intStateId = dbRs("State_Id")
                End If
                If Not IsDBNull(dbRs("State_Name")) Then
                    strStateName = dbRs("State_Name")
                End If
                If Not IsDBNull(dbRs("Country_Id")) Then
                    intCountryId = dbRs("Country_Id")
                End If
                If Not IsDBNull(dbRs("Country_Name")) Then
                    strCountryName = dbRs("Country_Name")
                End If
                If Not IsDBNull(dbRs("Zip")) Then
                    strZip = dbRs("Zip")
                End If
                If Not IsDBNull(dbRs("Phone")) Then
                    strPhone = dbRs("Phone")
                End If
                If Not IsDBNull(dbRs("Mobile")) Then
                    strMobile = dbRs("Mobile")
                End If
                If Not IsDBNull(dbRs("Fax")) Then
                    strFax = dbRs("Fax")
                End If
                If Not IsDBNull(dbRs("Email")) Then
                    strEmail = dbRs("Email")
                End If

                If Not IsDBNull(dbRs("Floor")) Then
                    strFloor = dbRs("Floor")
                End If

                If Not IsDBNull(dbRs("Template_type_id")) Then
                    intTemplateTypeId = dbRs("Template_type_id")
                End If
                If Not IsDBNull(dbRs("Template_type_description")) Then
                    strTemplateTypeDescription = dbRs("Template_type_description")
                End If
                If Not IsDBNull(dbRs("Construction_type_id")) Then
                    intConstructionTypeId = dbRs("Construction_type_id")
                End If
                If Not IsDBNull(dbRs("Construction_type_description")) Then
                    strConstructionTypeDescription = dbRs("Construction_type_description")
                End If
                If Not IsDBNull(dbRs("Sink_type_id")) Then
                    intSinkTypeId = dbRs("Sink_type_id")
                End If
                If Not IsDBNull(dbRs("Sink_type_description")) Then
                    strSinkTypeDescrption = dbRs("Sink_type_description")
                End If

                If Not IsDBNull(dbRs("No_of_sink")) Then
                    intNoofSink = dbRs("No_of_sink")
                End If

                If Not IsDBNull(dbRs("Back_splash")) Then
                    strBackSplash = dbRs("Back_splash")
                End If

                If Not IsDBNull(dbRs("Back_splash_details")) Then
                    strBackSplashDetails = dbRs("Back_splash_details")
                End If

                If Not IsDBNull(dbRs("Mill_down")) Then
                    strMillDown = dbRs("Mill_down")
                End If

                If Not IsDBNull(dbRs("Mill_down_details")) Then
                    strMillDownDetails = dbRs("Mill_down_details")
                End If

                If Not IsDBNull(dbRs("Stove_type_id")) Then
                    intStoveTypeId = dbRs("Stove_type_id")
                End If

                If Not IsDBNull(dbRs("Stove_type_description")) Then
                    strStoveTypeDescrption = dbRs("Stove_type_description")
                End If

                If Not IsDBNull(dbRs("Faucet_type_id")) Then
                    intFaucetTypeId = dbRs("Faucet_type_id")
                End If

                If Not IsDBNull(dbRs("Faucet_type_description")) Then
                    strFaucetTypeDescrption = dbRs("Faucet_type_description")
                End If

                If Not IsDBNull(dbRs("Edge_type_id")) Then
                    intEdgeTypeId = dbRs("Edge_type_id")
                End If

                If Not IsDBNull(dbRs("Edge_type_description")) Then
                    strEdgeTypeDescription = dbRs("Edge_type_description")
                End If

                If Not IsDBNull(dbRs("Edge_type_file")) Then
                    strEdgeTypeFile = dbRs("Edge_type_file")
                End If

                If Not IsDBNull(dbRs("Edge_type_details")) Then
                    strEdgeTypeDetails = dbRs("Edge_type_details")
                End If

                If Not IsDBNull(dbRs("Cutouts")) Then
                    strCutouts = dbRs("Cutouts")
                End If


                If Not IsDBNull(dbRs("Cutouts_quantity")) Then
                    intCutoutsQuantity = dbRs("Cutouts_quantity")
                End If

                If Not IsDBNull(dbRs("Material_id")) Then
                    strMaterialId = dbRs("Material_id")
                End If

                If Not IsDBNull(dbRs("Material_name")) Then
                    strMaterialName = dbRs("Material_name")
                End If

                If Not IsDBNull(dbRs("Thickness_id")) Then
                    intThicknessId = dbRs("Thickness_id")
                End If

                If Not IsDBNull(dbRs("Thickness_description")) Then
                    strThicknessDescription = dbRs("Thickness_description")
                End If

                If Not IsDBNull(dbRs("Top_removal")) Then
                    strTopRemoval = dbRs("Top_removal")
                End If

                If Not IsDBNull(dbRs("Comments")) Then
                    strComments = dbRs("Comments")
                End If

                If Not IsDBNull(dbRs("Requested_by")) Then
                    strRequestedBy = dbRs("Requested_by")
                End If

                If Not IsDBNull(dbRs("Created_by")) Then
                    strCreatedBy = dbRs("Created_by")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                If Not IsDBNull(dbRs("Created_date")) Then
                    dtCreatedDate = dbRs("Created_date")
                End If

                If Not IsDBNull(dbRs("Modified_date")) Then
                    dtModifiedDate = dbRs("Modified_date")
                End If

                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 'Id is Nothing
            strErr = "Quote Id is Nothing"

        End If

    End Sub 'executeSelectQuote()


    Public Sub executeCreateQuote()


        Dim dbCon As New DBAccess
        Dim T_id As String

        'Create New Quote to the database      


        T_id = dbCon.RunSPReturnId("dbo.sp_create_quote_wiz", _
                         New SqlParameter("@Quote_name", strQuoteName), _
                         New SqlParameter("@Quote_description", strQuoteDescription), _
                         New SqlParameter("@address1", strAddress1), _
                         New SqlParameter("@address2", strAddress2), _
                         New SqlParameter("@city", strCity), _
                         New SqlParameter("@state_id", intStateId), _
                         New SqlParameter("@zip", strZip), _
                         New SqlParameter("@country_id", intCountryId), _
                         New SqlParameter("@phone", strPhone), _
                         New SqlParameter("@mobile", strMobile), _
                         New SqlParameter("@fax", strFax), _
                         New SqlParameter("@email", strEmail), _
                         New SqlParameter("@Floor", strFloor), _
                         New SqlParameter("@Template_type_id", intTemplateTypeId), _
                         New SqlParameter("@Construction_type_id", intConstructionTypeId), _
                         New SqlParameter("@Sink_type_id", intSinkTypeId), _
                         New SqlParameter("@No_of_Sink", intNoofSink), _
                         New SqlParameter("@Back_splash", strBackSplash), _
                         New SqlParameter("@Back_splash_details", strBackSplashDetails), _
                         New SqlParameter("@Mill_down", strMillDown), _
                         New SqlParameter("@Mill_down_details", strMillDownDetails), _
                         New SqlParameter("@Stove_type_id", intStoveTypeId), _
                         New SqlParameter("@Faucet_type_id", intFaucetTypeId), _
                         New SqlParameter("@Edge_type_id", intEdgeTypeId), _
                         New SqlParameter("@Edge_type_details", strEdgeTypeDetails), _
                         New SqlParameter("@Cutouts", strCutouts), _
                         New SqlParameter("@Cutouts_quantity", intCutoutsQuantity), _
                         New SqlParameter("@Material_id", strMaterialId), _
                         New SqlParameter("@Thickness_id", intThicknessId), _
                         New SqlParameter("@Top_removal", strTopRemoval), _
                         New SqlParameter("@Comments", strComments), _
                         New SqlParameter("@Requested_by", strRequestedBy), _
                         New SqlParameter("@created_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Create New Quote Failed
            strErr = "Create New Quote Failed"

        Else

            strQuoteDetailId = T_id
            intErr = 0 'New Quote Created Successfully
            strErr = "New Quote Created Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeCreateQuote()

    Public Sub executeAddRoom()


        Dim dbCon As New DBAccess
        Dim T_id As String

        'Add a New Room to the database      


        T_id = dbCon.RunSPReturnId("dbo.sp_add_room_quote_wiz", _
                         New SqlParameter("@Quote_detail_id", strQuoteDetailId), _
                         New SqlParameter("@Floor", strFloor), _
                         New SqlParameter("@Template_type_id", intTemplateTypeId), _
                         New SqlParameter("@Construction_type_id", intConstructionTypeId), _
                         New SqlParameter("@Sink_type_id", intSinkTypeId), _
                         New SqlParameter("@No_of_Sink", intNoofSink), _
                         New SqlParameter("@Back_splash", strBackSplash), _
                         New SqlParameter("@Back_splash_details", strBackSplashDetails), _
                         New SqlParameter("@Mill_down", strMillDown), _
                         New SqlParameter("@Mill_down_details", strMillDownDetails), _
                         New SqlParameter("@Stove_type_id", intStoveTypeId), _
                         New SqlParameter("@Faucet_type_id", intFaucetTypeId), _
                         New SqlParameter("@Edge_type_id", intEdgeTypeId), _
                         New SqlParameter("@Edge_type_details", strEdgeTypeDetails), _
                         New SqlParameter("@Cutouts", strCutouts), _
                         New SqlParameter("@Cutouts_quantity", intCutoutsQuantity), _
                         New SqlParameter("@Material_id", strMaterialId), _
                         New SqlParameter("@Thickness_id", intThicknessId), _
                         New SqlParameter("@Top_removal", strTopRemoval), _
                         New SqlParameter("@Comments", strComments), _
                         New SqlParameter("@created_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Adding New Room Failed
            strErr = "Adding New Room Failed"

        Else

            strQuoteDetailId = T_id
            intErr = 0 'Added New Room Successfully
            strErr = "Added New Room Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeAddRoom()

    Public Sub executeAttachLayout()


        Dim dbCon As New DBAccess
        Dim T_id As String

        'Create New Quote to the database 

        Dim imgByte As Byte() = Nothing
        imgByte = New Byte(hpfQuoteFile.ContentLength - 1) {}

        hpfQuoteFile.InputStream.Read(imgByte, 0, hpfQuoteFile.ContentLength)

        Dim sqp_quote_file As New SqlParameter("@Quote_file", SqlDbType.Image, hpfQuoteFile.ContentLength)
        sqp_quote_file.Value = imgByte

        T_id = dbCon.RunSPReturnId("dbo.sp_quote_attach_layout_wiz", _
                                        New SqlParameter("@Quote_detail_id", strQuoteDetailId), _
                                        New SqlParameter("@Quote_file_name", strQuoteFileName), _
                                        sqp_quote_file, _
                                        New SqlParameter("@created_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Update Quote Attachment Failed
            strErr = "Update Quote Attachment Failed"

        Else

            intErr = 0 'Updated Quote Layout Successfully
            strErr = "Updated Quote Layout Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeAttachLayout()

    Public Sub executeAttachEstimate()


        Dim dbCon As New DBAccess
        Dim T_id As String

        'Create New Estimate to the database 

        Dim imgByte As Byte() = Nothing
        imgByte = New Byte(hpfEstimateFile.ContentLength - 1) {}

        hpfEstimateFile.InputStream.Read(imgByte, 0, hpfEstimateFile.ContentLength)

        Dim sqp_estimate_file As New SqlParameter("@Estimate_file", SqlDbType.Image, hpfEstimateFile.ContentLength)
        sqp_estimate_file.Value = imgByte

        T_id = dbCon.RunSPReturnId("dbo.sp_quote_attach_estimate_wiz", _
                                        New SqlParameter("@Quote_detail_id", strQuoteDetailId), _
                                        New SqlParameter("@Estimate_file_name", strEstimateFileName), _
                                        sqp_estimate_file, _
                                        New SqlParameter("@created_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Update Estimate Attachment Failed
            strErr = "Update Estimate Attachment Failed"

        Else

            intErr = 0 'Updated Estimate Successfully
            strErr = "Updated Estimate  Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeAttachEstimate()

    Public Sub executeSelectLayout(ByVal Response As HttpResponse)

        Dim dbCon As New DBAccess
        Dim dbRs As SqlDataReader
        Dim T_File_Name As String = ""

        'Create New Quote to the database 
        Const T_SQL As String = "SELECT Quote_file_name, Quote_file_mime, Quote_File FROM dbo.view_all_quotes WHERE Quote_detail_id = @Quote_detail_id"

        dbRs = dbCon.RunSQLReturnRS(T_SQL, _
                     New SqlParameter("@Quote_detail_id", strQuoteDetailId))

        If dbRs.Read Then

            If Not IsDBNull(dbRs("Quote_file_name")) Then
                T_File_Name = dbRs("Quote_file_name")
            End If

            If Not IsDBNull(dbRs("Quote_file_mime")) Then
                Response.ContentType = dbRs("Quote_file_mime")
            Else

                If T_File_Name.EndsWith(".doc") Or T_File_Name.EndsWith(".docx") Then

                    Response.ContentType = "application/vnd.ms-word"

                ElseIf T_File_Name.EndsWith(".xls") Or T_File_Name.EndsWith(".xlsx") Then

                    Response.ContentType = "application/vnd.ms-excel"

                ElseIf T_File_Name.EndsWith(".pdf") Then

                    Response.ContentType = "Application/pdf"

                ElseIf T_File_Name.EndsWith(".jpeg") Or T_File_Name.EndsWith(".jpg") Then

                    Response.ContentType = "image/jpeg"

                ElseIf T_File_Name.EndsWith(".gif") Then

                    Response.ContentType = "image/gif"

                End If

            End If

            Response.AddHeader("content-disposition", "attachment;filename=" + T_File_Name + """")

            If Not IsDBNull(dbRs("Quote_file")) Then
                Response.BinaryWrite(dbRs("Quote_file"))
            End If

        End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

    End Sub 'executeSelectLayout()


    Public Sub executeSelectEstimate(ByVal Response As HttpResponse)

        Dim dbCon As New DBAccess
        Dim dbRs As SqlDataReader
        Dim T_File_Name As String = ""

        'get Estimate information from the database 

        Const T_SQL As String = "SELECT Estimate_file_name, Estimate_file_mime, Estimate_File FROM dbo.view_all_quotes WHERE Quote_detail_id = @Quote_detail_id"

        dbRs = dbCon.RunSQLReturnRS(T_SQL, _
                     New SqlParameter("@Quote_detail_id", strQuoteDetailId))

        If dbRs.Read Then

            If Not IsDBNull(dbRs("Estimate_file_name")) Then
                T_File_Name = dbRs("Estimate_file_name")
            End If

            If Not IsDBNull(dbRs("Estimate_file_mime")) Then
                Response.ContentType = dbRs("Estimate_file_mime")
            Else

                If T_File_Name.EndsWith(".doc") Or T_File_Name.EndsWith(".docx") Then

                    Response.ContentType = "application/vnd.ms-word"

                ElseIf T_File_Name.EndsWith(".xls") Or T_File_Name.EndsWith(".xlsx") Then

                    Response.ContentType = "application/vnd.ms-excel"

                ElseIf T_File_Name.EndsWith(".pdf") Then

                    Response.ContentType = "Application/pdf"

                ElseIf T_File_Name.EndsWith(".jpeg") Or T_File_Name.EndsWith(".jpg") Then

                    Response.ContentType = "image/jpeg"

                ElseIf T_File_Name.EndsWith(".gif") Then

                    Response.ContentType = "image/gif"

                End If

            End If

            Response.AddHeader("content-disposition", "attachment;filename=" + T_File_Name + """")

            If Not IsDBNull(dbRs("Estimate_file")) Then
                Response.BinaryWrite(dbRs("Estimate_file"))
            End If

        End If

        dbRs.Close()
        dbRs = Nothing
        dbCon = Nothing

    End Sub 'executeSelectEstimate()

    Public Sub executeUpdateQuote()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Save Quote Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_quote_wiz", _
                         New SqlParameter("@Quote_id", strQuoteId), _
                         New SqlParameter("@Quote_name", strQuoteName), _
                         New SqlParameter("@Quote_description", strQuoteDescription), _
                         New SqlParameter("@address1", strAddress1), _
                         New SqlParameter("@address2", strAddress2), _
                         New SqlParameter("@city", strCity), _
                         New SqlParameter("@state_id", intStateId), _
                         New SqlParameter("@zip", strZip), _
                         New SqlParameter("@country_id", intCountryId), _
                         New SqlParameter("@phone", strPhone), _
                         New SqlParameter("@mobile", strMobile), _
                         New SqlParameter("@fax", strFax), _
                         New SqlParameter("@email", strEmail), _
                         New SqlParameter("@Template_type_id", intTemplateTypeId), _
                         New SqlParameter("@Construction_type_id", intConstructionTypeId), _
                         New SqlParameter("@Sink_type_id", intSinkTypeId), _
                         New SqlParameter("@No_of_Sink", intNoofSink), _
                         New SqlParameter("@Back_splash", strBackSplash), _
                         New SqlParameter("@Back_splash_details", strBackSplashDetails), _
                         New SqlParameter("@Stove_type_id", intStoveTypeId), _
                         New SqlParameter("@Faucet_type_id", intFaucetTypeId), _
                         New SqlParameter("@Edge_type_id", intEdgeTypeId), _
                         New SqlParameter("@Cutouts", strCutouts), _
                         New SqlParameter("@Material_id", strMaterialId), _
                         New SqlParameter("@Thickness_id", intThicknessId), _
                         New SqlParameter("@Requested_by", strRequestedBy), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = -1 Then

            intErr = -1 'Update Quote Failed
            strErr = "Update Quote Failed"

        Else

            intErr = 0 'Quote Information Saved Successfully
            strErr = "Quote Information Saved Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateQuote()



    Public Sub executeDeleteQuote()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Delete Quote Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_delete_quote_wiz", _
                         New SqlParameter("@Quote_id", strQuoteId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Delete Quote Failed
            strErr = "Delete Quote Failed"

        Else

            intErr = 0 'Quote Information Deleted Successfully
            strErr = "Quote Information Deleted Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeleteQuote()

End Class
