﻿Public Class template_manager
    Inherits System.Web.UI.Page


    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        setRolePermission()

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        getAllWorkOrderTemplates()

    End Sub

    Private Sub setRolePermission()

        Dim T_Security As New PAL_Security

        T_Security.Role_Id = Session("Role_Id")
        T_Security.Navigate_Url = T_Security.Get_Page(Request)
        T_Security.GV_Data = GV_Work_Order_Manager
        T_Security.setGVUserPermission("Work_Order_id", "_template.aspx", "id", "Work_Order_id")

        T_Security = Nothing

    End Sub

    Private Sub getAllWorkOrderTemplates()

        Dim T_Work_Order As New Work_Order

        T_Work_Order.By = Session("User_Id")
        T_Work_Order.DS_Data = DS_Work_Order_Manager
        T_Work_Order.selectAllWorkOrderTemplates()

        T_Work_Order = Nothing

    End Sub

End Class