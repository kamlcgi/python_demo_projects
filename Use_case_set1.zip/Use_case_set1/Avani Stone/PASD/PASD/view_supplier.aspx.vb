﻿Public Class view_supplier
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            getSupplierInformation()

        End If

    End Sub

    Sub getSupplierInformation()

        Dim T_Supplier As New Supplier
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Supplier_Id As String = ""

        Try

            T_Supplier_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Supplier.Supplier_Id = T_Supplier_Id
            T_Supplier.executeSelectSupplier()

            If T_Supplier.Error_Id = 0 Then

                txt_supplier_name.Text = T_Supplier.Supplier_Name
                txt_address1.Text = T_Supplier.Address1
                txt_address2.Text = T_Supplier.Address2
                txt_city.Text = T_Supplier.City
                txt_zip.Text = T_Supplier.Zip
                txt_state.Text = T_Supplier.State_Name
                txt_country.Text = T_Supplier.Country_Name
                txt_phone.Text = T_Supplier.Phone
                txt_mobile.Text = T_Supplier.Mobile
                txt_email.Text = T_Supplier.Email
                txt_fax.Text = T_Supplier.Fax

            Else

                T_Msg = "Error Retrieving Supplier Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Supplier Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


End Class