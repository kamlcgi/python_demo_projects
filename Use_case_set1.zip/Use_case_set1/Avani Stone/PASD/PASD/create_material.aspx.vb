﻿Public Class create_material
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            setLookups()

        End If

    End Sub

    Protected Sub create_Material(ByVal sender As Object, ByVal e As EventArgs) Handles btn_create_material.Click

        createMaterialInformation()

    End Sub

    Sub createMaterialInformation()

        Dim T_Material As New Material
        Dim T_Security As New PAL_Security
        Dim T_Msg As String = ""

        Try

            T_Material.Material_Name = txt_Material_name.Text
            T_Material.Material_Color = txt_material_color.Text
            T_Material.Material_Code_Number = txt_material_code_number.Text
            T_Material.Material_Type_Id = ddl_material_type.SelectedValue
            T_Material.File_Type_Id = ddl_file_type.SelectedValue
            T_Material.Material_Description = txt_material_description.Text
            T_Material.File_Location = txt_file_location.Text
            T_Material.Country_Id = ddl_country.SelectedValue
            
            T_Material.By = Session("User_Id")
            T_Material.executeCreateMaterial()

            If T_Material.Error_Id <> 0 Then

                T_Msg = "Error Creating New Material Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Creating New Material Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Material = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("material_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindCountryList(ddl_country)
        T_Lookup.bindMaterialTypeList(ddl_material_type)
        T_Lookup.bindFileTypeList(ddl_file_type)

        T_Lookup = Nothing

    End Sub


End Class