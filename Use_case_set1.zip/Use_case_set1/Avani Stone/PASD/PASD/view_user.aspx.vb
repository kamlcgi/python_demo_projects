﻿Public Class view_user
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            getUserInformation()

        End If

    End Sub

    Sub getUserInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_User_Id As String = ""

        Try

            T_User_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Security.User_Id = T_User_Id
            T_Security.executeSelectUser()

            If T_Security.Error_Id = 0 Then

                txt_first_name.Text = T_Security.First_Name
                txt_last_name.Text = T_Security.Last_Name
                txt_address1.Text = T_Security.Address1
                txt_address2.Text = T_Security.Address2
                txt_city.Text = T_Security.City
                txt_zip.Text = T_Security.Zip
                txt_state.Text = T_Security.State_Name
                txt_country.Text = T_Security.Country_Name
                txt_phone.Text = T_Security.Phone
                txt_mobile.Text = T_Security.Mobile
                txt_email.Text = T_Security.Email
                txt_fax.Text = T_Security.Fax

            Else

                T_Msg = "Error Retrieving User Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding User Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

End Class