﻿Public Class modify_schedule_template
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            setLookups()
            getWorkOrderInformation()

        End If

    End Sub

    Protected Sub schedule_template(ByVal sender As Object, ByVal e As EventArgs) Handles btn_schedule.Click

        scheduleTemplateInformation()

    End Sub

    Sub scheduleTemplateInformation()

        Dim T_Work_Order As New Work_Order
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Work_Order.Work_Order_Id = T_Id

            T_Work_Order.Template_Date = txt_template_date.Text
            T_Work_Order.Template_By = ddl_template_by.SelectedValue
            T_Work_Order.Time_Slot_Id = ddl_time_slot.SelectedValue
            T_Work_Order.Estimate_SQFT = txt_estimate_sqft.Text
           
            T_Work_Order.By = Session("User_Id")
            T_Work_Order.executeScheduleTemplate()

            If T_Work_Order.Error_Id <> 0 Then

                T_Msg = "Error Scheduling New Template Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Scheduling New Template Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Work_Order = Nothing
        T_Security = Nothing
        T_Encryption = Nothing

        If T_Msg = "" Then
            Response.Redirect("schedule_template_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub getWorkOrderInformation()

        Dim T_Work_Order As New Work_Order
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Work_Order.Work_Order_Id = T_Id

            T_Work_Order.executeSelectWorkOrder()

            If T_Work_Order.Error_Id = 0 Then

                txt_work_order_number.Text = T_Work_Order.Work_Order_Number
                txt_purchase_order_no.Text = T_Work_Order.Purchase_Order_Number
                txt_purchase_order_date.Text = T_Work_Order.Purchase_Order_Date
                txt_requested_start_date.Text = T_Work_Order.Requested_Start_Date
                txt_work_order_comments.Text = T_Work_Order.Comments

                txt_sink_status.Text = T_Work_Order.Sink_Status_Description
                txt_faucet_status.Text = T_Work_Order.Faucet_Status_Description
                txt_kitchen_island.Text = T_Work_Order.Kitchen_Island
                txt_cabinets.Text = T_Work_Order.Cabinets

                txt_quote_detail_no.Text = T_Work_Order.Quote_Detail_No
                txt_quote_name.Text = T_Work_Order.Quote_Name
                txt_quote_description.Text = T_Work_Order.Quote_Description
                txt_address1.Text = T_Work_Order.Address1
                txt_address2.Text = T_Work_Order.Address2
                txt_city.Text = T_Work_Order.City
                txt_zip.Text = T_Work_Order.Zip

                txt_state.Text = T_Work_Order.State_Name
                txt_country.Text = T_Work_Order.Country_Name

                txt_phone.Text = T_Work_Order.Phone
                txt_mobile.Text = T_Work_Order.Mobile
                txt_fax.Text = T_Work_Order.Fax
                txt_email.Text = T_Work_Order.Email
                txt_floor.Text = T_Work_Order.Floor

                txt_template_type.Text = T_Work_Order.Template_Type_Description
                txt_construction_type.Text = T_Work_Order.Construction_Type_Description
                txt_sink_type.Text = T_Work_Order.Sink_Type_Descrption
                txt_no_of_sink.Text = T_Work_Order.No_of_Sink

                If T_Work_Order.Back_Splash = "1" Then
                    txt_back_splash.Text = "Yes"
                Else
                    txt_back_splash.Text = "No"
                End If

                txt_back_splash_details.Text = T_Work_Order.Back_Splash_Details

                If T_Work_Order.Mill_Down = "1" Then
                    txt_mill_down.Text = "Yes"
                Else
                    txt_mill_down.Text = "No"
                End If

                txt_mill_down_details.Text = T_Work_Order.Mill_Down_Details

                txt_stove_type.Text = T_Work_Order.Stove_Type_Descrption

                txt_faucet_type.Text = T_Work_Order.Faucet_Type_Descrption
                img_edge_type_file.ImageUrl = "./images/" + T_Work_Order.Edge_Type_File

                txt_edge_type_details.Text = T_Work_Order.Edge_Type_Details

                If T_Work_Order.Cutouts = "1" Then
                    txt_cutouts.Text = "Yes"
                Else
                    txt_cutouts.Text = "No"
                End If

                txt_cutouts_qty.Text = T_Work_Order.Cutouts_Quantity

                txt_material.Text = T_Work_Order.Material_Name
                txt_thickness.Text = T_Work_Order.Thickness_Description

                If T_Work_Order.Top_Removal = "1" Then
                    txt_top_removal.Text = "Yes"
                Else
                    txt_top_removal.Text = "No"
                End If

                txt_work_order_comments.Text = T_Work_Order.Work_Order_Comments

            Else

                T_Msg = "Error Viewing Work Order Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Viewing Work Order Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Work_Order = Nothing
        T_Security = Nothing
        T_Encryption = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindTimeSlotList(ddl_time_slot)
        T_Lookup.bindTemplatorList(ddl_template_by)

        ddl_time_slot.Items.Insert(0, "-Select-")
        ddl_template_by.Items.Insert(0, "-Select-")

        T_Lookup = Nothing

    End Sub

End Class