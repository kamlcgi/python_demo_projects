﻿Public Class create_supplier
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            setLookups()

        End If

    End Sub

    Protected Sub create_supplier(ByVal sender As Object, ByVal e As EventArgs) Handles btn_create_supplier.Click

        createSupplierInformation()

    End Sub

    Sub createSupplierInformation()

        Dim T_Supplier As New Supplier
        Dim T_Security As New PAL_Security
        Dim T_Msg As String = ""

        Try

            T_Supplier.Supplier_Name = txt_supplier_name.Text
            T_Supplier.Address1 = txt_address1.Text
            T_Supplier.Address2 = txt_address2.Text
            T_Supplier.City = txt_city.Text
            T_Supplier.Zip = txt_zip.Text
            T_Supplier.State_Id = ddl_state.SelectedValue
            T_Supplier.Country_Id = ddl_country.SelectedValue
            T_Supplier.Phone = txt_phone.Text
            T_Supplier.Mobile = txt_mobile.Text
            T_Supplier.Email = txt_email.Text
            T_Supplier.Fax = txt_fax.Text

            T_Supplier.By = Session("User_Id")
            T_Supplier.executeCreateSupplier()

            If T_Supplier.Error_Id <> 0 Then

                T_Msg = "Error Creating New Supplier Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Creating New Supplier Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Supplier = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("supplier_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindCountryList(ddl_country)
        T_Lookup.bindStateList(ddl_state, 1)

        T_Lookup = Nothing

    End Sub


End Class