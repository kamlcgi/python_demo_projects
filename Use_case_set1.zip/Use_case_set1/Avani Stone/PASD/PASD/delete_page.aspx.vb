﻿Public Class delete_page
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            getPageInformation()

        End If

    End Sub

    Protected Sub delete_page(ByVal sender As Object, ByVal e As EventArgs) Handles btn_delete.Click

        deletePageInformation()

    End Sub


    Sub getPageInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Page_Id As String = ""

        Try

            T_Page_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Security.Page_Id = T_Page_Id
            T_Security.executeSelectPage()

            If T_Security.Error_Id = 0 Then

                lbl_text.Text = T_Security.Page_Title

            Else

                T_Msg = "Error Retrieving Page Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Page Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub deletePageInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim Page_Id As String = ""

        Try

            Page_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Security.Page_Id = Page_Id

            T_Security.By = Session("User_Id")
            T_Security.executeDeletePage()

            If T_Security.Error_Id <> 0 Then

                T_Msg = "Error Deleteing Page Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Page Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("page_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

End Class