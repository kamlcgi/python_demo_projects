
'Component Name: Estimate
'Description: Used to Create, Update, View and Delete Estimate Information
'Author:  Srinivasan Subbanchattiar 
'Created By: Srinivasan Subbanchattiar 
'Created Date: 08/01/2011 
'Modified By: Srinivasan Subbanchattiar 
'Modified Date: 08/01/2011 
'Version: 1.0

Imports System.Web
Imports System.Data
Imports System.Data.SqlClient

Public Class Estimate


    Protected intErr As Integer
    Protected strErr As String
    Protected strBy As String

    Protected strEstimateId As String
    Protected strEstimateNumber As String

    Protected strAccountId As String
    Protected strAccountName As String

    Protected strCustomerId As String
    Protected strCustomerName As String

    Protected strSupplierId As String
    Protected strSupplierName As String

    Protected strMaterialId As String
    Protected strMaterialName As String

    Protected intEdgeTypeId As Integer
    Protected strEdgeTypeDescription As String

    Protected intThicknessId As Integer
    Protected strThicknessTypeDescription As String

    Protected sngSquareFeet As Single
    Protected sngPricePerSqFeet As Single

    Protected strEstimateStatus As String

    Protected gvData As GridView
    Protected dsData As SqlDataSource

    'for view purpose only
    Protected strCreatedBy As String
    Protected dtCreatedDate As Date
    Protected strModifiedBy As String
    Protected dtModifiedDate As Date


    Public Sub New()

        Clear()

    End Sub


    Public Sub Clear()

        intErr = Nothing
        strErr = Nothing
        strBy = Nothing

        strEstimateId = Nothing
        strEstimateNumber = Nothing

        strAccountId = Nothing
        strAccountName = Nothing

        strCustomerId = Nothing
        strCustomerName = Nothing

        strSupplierId = Nothing
        strSupplierName = Nothing

        strMaterialid = Nothing
        strMaterialName = Nothing

        intEdgeTypeId = Nothing
        strEdgeTypeDescription = Nothing

        intThicknessId = Nothing
        strThicknessTypeDescription = Nothing

        sngSquareFeet = Nothing
        sngPricePerSqFeet = Nothing
        strEstimateStatus = Nothing

        gvData = Nothing
        dsData = Nothing

        strCreatedBy = Nothing
        dtCreatedDate = Nothing
        strModifiedBy = Nothing
        dtModifiedDate = Nothing


    End Sub

    Public Property Error_Id() As Integer
        Get
            Return intErr
        End Get
        Set(ByVal Value As Integer)
            intErr = Value
        End Set
    End Property

    Public Property Error_Message() As String
        Get
            Return strErr
        End Get
        Set(ByVal Value As String)
            strErr = Value
        End Set
    End Property

    Public Property Estimate_Id() As String
        Get
            Return strEstimateId
        End Get
        Set(ByVal Value As String)
            strEstimateId = Value
        End Set
    End Property


    Public Property Estimate_Number() As String
        Get
            Return strEstimateNumber
        End Get
        Set(ByVal Value As String)
            strEstimateNumber = Value
        End Set
    End Property

    Public Property Account_Id() As String
        Get
            Return strAccountId
        End Get
        Set(ByVal Value As String)
            strAccountId = Value
        End Set
    End Property

    Public Property Account_Name() As String
        Get
            Return strAccountName
        End Get
        Set(ByVal Value As String)
            strAccountName = Value
        End Set
    End Property

    Public Property Customer_Id() As String
        Get
            Return strCustomerId
        End Get
        Set(ByVal Value As String)
            strCustomerId = Value
        End Set
    End Property

    Public Property Customer_Name() As String
        Get
            Return strCustomerName
        End Get
        Set(ByVal Value As String)
            strCustomerName = Value
        End Set
    End Property


    Public Property Supplier_Id() As String
        Get
            Return strSupplierId
        End Get
        Set(ByVal Value As String)
            strSupplierId = Value
        End Set
    End Property

    Public Property Supplier_Name() As String
        Get
            Return strSupplierName
        End Get
        Set(ByVal Value As String)
            strSupplierName = Value
        End Set
    End Property

    Public Property Material_Id() As String
        Get
            Return strMaterialId
        End Get
        Set(ByVal Value As String)
            strMaterialId = Value
        End Set
    End Property

    Public Property Material_Name() As String
        Get
            Return strMaterialName
        End Get
        Set(ByVal Value As String)
            strMaterialName = Value
        End Set
    End Property 

    Public Property Edge_Type_Id() As Integer
        Get
            Return intEdgeTypeId
        End Get
        Set(ByVal Value As Integer)
            intEdgeTypeId = Value
        End Set
    End Property

    Public Property Edge_Type_Description() As String
        Get
            Return strEdgeTypeDescription
        End Get
        Set(ByVal Value As String)
            strEdgeTypeDescription = Value
        End Set
    End Property

    Public Property Thickness_Id() As Integer
        Get
            Return intThicknessId
        End Get
        Set(ByVal Value As Integer)
            intThicknessId = Value
        End Set
    End Property

    Public Property Thickness_Type_Description() As String
        Get
            Return strThicknessTypeDescription
        End Get
        Set(ByVal Value As String)
            strThicknessTypeDescription = Value
        End Set
    End Property
     

    Public Property Square_Feet() As Single
        Get
            Return sngSquareFeet
        End Get
        Set(ByVal Value As Single)
            sngSquareFeet = Value
        End Set
    End Property

    Public Property Price_Per_Sq_Feet() As Single
        Get
            Return sngPricePerSqFeet
        End Get
        Set(ByVal Value As Single)
            sngPricePerSqFeet = Value
        End Set
    End Property

    Public Property Estimate_Status() As String
        Get
            Return strEstimateStatus
        End Get
        Set(ByVal Value As String)
            strEstimateStatus = Value
        End Set
    End Property

    Public Property DS_Data() As SqlDataSource
        Get
            Return dsData
        End Get
        Set(ByVal Value As SqlDataSource)
            dsData = Value
        End Set
    End Property

    Public Property GV_Data() As GridView
        Get
            Return gvData
        End Get
        Set(ByVal Value As GridView)
            gvData = Value
        End Set
    End Property

    Public Property By() As String
        Get
            Return strBy
        End Get
        Set(ByVal Value As String)
            strBy = Value
        End Set
    End Property

    Public Property Created_By() As String
        Get
            Return strCreatedBy
        End Get
        Set(ByVal Value As String)
            strCreatedBy = Value
        End Set
    End Property

    Public Property Modified_By() As String
        Get
            Return strModifiedBy
        End Get
        Set(ByVal Value As String)
            strModifiedBy = Value
        End Set
    End Property

    Public Property Created_Date() As Date
        Get
            Return dtCreatedDate
        End Get
        Set(ByVal Value As Date)
            dtCreatedDate = Value
        End Set
    End Property

    Public Property Modified_Date() As Date
        Get
            Return dtModifiedDate
        End Get
        Set(ByVal Value As Date)
            dtModifiedDate = Value
        End Set
    End Property

    Public Sub selectAllEstimates()

        Dim dbCon As New DBAccess

        'Get all the User information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_estimates"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub executeSelectEstimate()

        If Not IsDBNull(strEstimateId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the user information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_estimate", _
                         New SqlParameter("@Estimate_id", strEstimateId))

            If dbRs.Read Then

               If Not IsDBNull(dbRs("Estimate_number")) Then
                    strEstimateNumber = dbRs("Estimate_number")
                End If

                If Not IsDBNull(dbRs("Account_id")) Then
                    strAccountId = dbRs("Account_id")
                End If

                If Not IsDBNull(dbRs("Account_name")) Then
                    strAccountName = dbRs("Account_name")
                End If

                If Not IsDBNull(dbRs("Customer_id")) Then
                    strCustomerId = dbRs("Customer_id")
                End If

                If Not IsDBNull(dbRs("Customer_name")) Then
                    strCustomerName = dbRs("Customer_name")
                End If

                If Not IsDBNull(dbRs("Supplier_id")) Then
                    strSupplierId = dbRs("Supplier_id")
                End If

                If Not IsDBNull(dbRs("Supplier_name")) Then
                    strSupplierName = dbRs("Supplier_name")
                End If

                If Not IsDBNull(dbRs("Material_id")) Then
                    strMaterialId = dbRs("Material_id")
                End If

                If Not IsDBNull(dbRs("Material_name")) Then
                    strMaterialName = dbRs("Material_name")
                End If

                If Not IsDBNull(dbRs("Edge_type_id")) Then
                    intEdgeTypeId = dbRs("Edge_type_id")
                End If

                If Not IsDBNull(dbRs("Thickness_id")) Then
                    intThicknessId = dbRs("Thickness_id")
                End If


                If Not IsDBNull(dbRs("Square_feet")) Then
                    sngSquareFeet = dbRs("Square_feet")
                End If

                If Not IsDBNull(dbRs("Price_per_Sq_feet")) Then
                    sngPricePerSqFeet = dbRs("Price_per_Sq_feet")
                End If

                If Not IsDBNull(dbRs("Estimate_Status")) Then
                    strEstimateStatus = dbRs("Estimate_Status")
                End If

                If Not IsDBNull(dbRs("Created_by")) Then
                    strCreatedBy = dbRs("Created_by")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                If Not IsDBNull(dbRs("Created_date")) Then
                    dtCreatedDate = dbRs("Created_date")
                End If

                If Not IsDBNull(dbRs("Modified_date")) Then
                    dtModifiedDate = dbRs("Modified_date")
                End If

                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 'Id is Nothing
            strErr = "UserId is Nothing"

        End If

    End Sub 'executeSelectEstimate()


    Public Sub executeCreateEstimate()


        Dim dbCon As New DBAccess
        Dim T_User_id As String

        'Create New Estimate to the database         

        T_User_id = dbCon.RunSPReturnId("dbo.sp_create_estimate_wiz", _
                         New SqlParameter("@Estimate_number", strEstimateNumber), _
                         New SqlParameter("@Account_id", strAccountId), _
                         New SqlParameter("@Customer_id", strCustomerId), _
                         New SqlParameter("@Supplier_id", strSupplierId), _
                         New SqlParameter("@Material_id", strMaterialId), _
                         New SqlParameter("@Edge_type_id", intEdgeTypeId), _
                         New SqlParameter("@Thickness_id", intThicknessId), _
                         New SqlParameter("@Square_feet", sngSquareFeet), _
                         New SqlParameter("@Price_per_sq_feet", sngPricePerSqFeet), _
                         New SqlParameter("@Estimate_status", strEstimateStatus), _
                         New SqlParameter("@created_by", strBy))

        If T_User_id = "-1" Then

            intErr = -1 'Create New Estimate Failed
            strErr = "Create New Estimate Failed"

        Else

            intErr = 0 'New Estimate Created Successfully
            strErr = "New Estimate Created Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeCreateEstimate()


    Public Sub executeUpdateEstimate()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Save Estimate Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_estimate_wiz", _
                         New SqlParameter("@Estimate_id", strEstimateId), _
                         New SqlParameter("@Estimate_number", strEstimateNumber), _
                         New SqlParameter("@Account_id", strAccountId), _
                         New SqlParameter("@Customer_id", strCustomerId), _
                         New SqlParameter("@Supplier_id", strSupplierId), _
                         New SqlParameter("@Material_id", strMaterialId), _
                         New SqlParameter("@Edge_type_id", intEdgeTypeId), _
                         New SqlParameter("@Thickness_id", intThicknessId), _
                         New SqlParameter("@Square_feet", sngSquareFeet), _
                         New SqlParameter("@Price_per_sq_feet", sngPricePerSqFeet), _
                         New SqlParameter("@Estimate_status", strEstimateStatus), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = -1 Then

            intErr = -1 'Update Estimate Failed
            strErr = "Update Estimate Failed"

        Else

            intErr = 0 'Estimate Information Saved Successfully
            strErr = "Estimate Information Saved Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateEstimate()



    Public Sub executeDeleteEstimate()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Delete Estimate Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_delete_estimate_wiz", _
                         New SqlParameter("@Estimate_id", strEstimateId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Delete Estimate Failed
            strErr = "Delete Estimate Failed"

        Else

            intErr = 0 'Estimate Information Deleted Successfully
            strErr = "Estimate Information Deleted Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeleteEstimate()

End Class
