﻿
Imports System.Web
Imports System.Data
Imports System.Data.SqlClient

Public Class PLookup

    Protected intErr As Integer
    Protected strErr As String
    Protected strBy As String

    Public Sub New()

        Clear()

    End Sub


    Public Sub Clear()

        intErr = Nothing
        strErr = Nothing
        strBy = Nothing

    End Sub

    Public Property Error_Id() As Integer
        Get
            Return intErr
        End Get
        Set(ByVal Value As Integer)
            intErr = Value
        End Set
    End Property

    Public Property Error_Message() As String
        Get
            Return strErr
        End Get
        Set(ByVal Value As String)
            strErr = Value
        End Set
    End Property

    Public Property By() As String
        Get
            Return strBy
        End Get
        Set(ByVal Value As String)
            strBy = Value
        End Set
    End Property


    Public Sub bindCountryList(ByVal country_list As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the country information from the database

        country_list.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_country")
        country_list.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindStateList(ByVal state_list As DropDownList, ByVal country_id As Integer)

        Dim dbCon As New DBAccess

        'Get all the state information from the database

        state_list.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_state_by_country", _
                                                         New SqlParameter("@country_id", country_id))
        state_list.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindRoleList(ByVal role_list As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the country information from the database

        role_list.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_roles")
        role_list.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindParentPageList(ByVal page_list As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the Parent Pages information from the database

        page_list.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_parent_pages")

        page_list.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindPageNotInRoleList(ByVal page_list As DropDownList, ByVal role_id As Integer)

        Dim dbCon As New DBAccess

        'Get all the pages information not in role from the database

        page_list.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_pages_not_in_role", _
                                                         New SqlParameter("@role_id", role_id))
        page_list.DataBind()

        dbCon = Nothing

    End Sub


    Public Sub bindUserList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the user information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_users_lkup")

        Plist.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindTemplatorList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the Templator user information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_templator_lkup")

        Plist.DataBind()

        dbCon = Nothing

    End Sub


    Public Sub bindFabricatorList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the Fabricator user information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_fabricator_lkup")

        Plist.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindAllUserNotInAccountList(ByVal Plist As DropDownList, ByVal account_id As String)

        Dim dbCon As New DBAccess

        'Get all the user information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_users_not_in_account_lkup", _
                                                     New SqlParameter("@account_id", account_id))

        Plist.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindAccountList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the accounts information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_accounts_lkup")

        Plist.DataBind()

        dbCon = Nothing

    End Sub


    Public Sub bindSupplierList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the suppliers information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_suppliers_lkup")

        Plist.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindCustomerList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the customers information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_customers_lkup")

        Plist.DataBind()

        dbCon = Nothing

    End Sub


    Public Sub bindMaterialList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the materials information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_materials_lkup")

        Plist.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindConstructionTypeList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_construction_type")

        Plist.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindEdgeTypeList(ByVal Plist As RadioButtonList)

        Dim dbCon As New DBAccess

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_edge_type")
        Plist.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindFaucetTypeList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_faucet_type")

        Plist.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub bindFaucetStatusList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_faucet_status")

        Plist.DataBind()

        dbCon = Nothing

    End Sub


    Public Sub bindSinkStatusList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_sink_status")

        Plist.DataBind()

        dbCon = Nothing

    End Sub


    Public Sub bindSinkTypeList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_sink_type")

        Plist.DataBind()

        dbCon = Nothing

    End Sub


    Public Sub bindThicknessList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_thickness")

        Plist.DataBind()

        dbCon = Nothing

    End Sub


    Public Sub bindStoveTypeList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_stove_type")

        Plist.DataBind()

        dbCon = Nothing

    End Sub


    Public Sub bindTemplateTypeList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_template_type")

        Plist.DataBind()
        Plist.Items.Insert(0, "-Select-")

        dbCon = Nothing

    End Sub

    Public Sub bindTimeSlotList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_time_slot")

        Plist.DataBind()

        dbCon = Nothing

    End Sub


    Public Sub bindMaterialTypeList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_material_type")

        Plist.DataBind()

        dbCon = Nothing

    End Sub


    Public Sub bindFileTypeList(ByVal Plist As DropDownList)

        Dim dbCon As New DBAccess

        'Get all the  information from the database

        Plist.DataSource = dbCon.RunSPReturnDataSet("dbo.sp_get_all_file_type")

        Plist.DataBind()

        dbCon = Nothing

    End Sub


End Class
