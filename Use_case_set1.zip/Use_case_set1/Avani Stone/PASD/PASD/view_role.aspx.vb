﻿Public Class view_role
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        getRoleInformation()

    End Sub

    Sub getRoleInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Role_Id As String = ""

        Try

            T_Role_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Security.Role_Id = T_Role_Id
            T_Security.executeSelectRole()

            If T_Security.Error_Id = 0 Then

                lbl_role_name.Text = T_Security.Role_Name

                T_Security.DS_Data = DS_Page_Manager
                T_Security.selectAllPagesByRole()

            Else

                T_Msg = "Error Retrieving Role Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Role Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


End Class