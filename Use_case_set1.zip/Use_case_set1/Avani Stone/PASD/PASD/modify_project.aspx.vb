﻿Public Class modify_project
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            setLookups()
            getProjectInformation()

        End If

    End Sub

    Protected Sub modify_Project(ByVal sender As Object, ByVal e As EventArgs) Handles btn_modify_project.Click

        updateProjectInformation()

    End Sub

    Sub getProjectInformation()

        Dim T_Project As New Project
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Project_Id As String = ""

        Try

            T_Project_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Project.Project_Id = T_Project_Id
            T_Project.executeSelectProject()

            If T_Project.Error_Id = 0 Then

                txt_project_name.Text = T_Project.Project_Name
                txt_project_description.Text = T_Project.Project_Description
                txt_address1.Text = T_Project.Address1
                txt_address2.Text = T_Project.Address2
                txt_city.Text = T_Project.City
                txt_zip.Text = T_Project.Zip
                ddl_state.SelectedValue = T_Project.State_Id
                ddl_country.SelectedValue = T_Project.Country_Id
                txt_phone.Text = T_Project.Phone
                txt_mobile.Text = T_Project.Mobile
                txt_email.Text = T_Project.Email
                txt_fax.Text = T_Project.Fax

            Else

                T_Msg = "Error Retrieving Project Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Project Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Project = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub updateProjectInformation()

        Dim T_Project As New Project
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""

        Dim T_Project_Id As String = ""

        Try

            T_Project_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Project.Project_Id = T_Project_Id


            T_Project.Project_Name = txt_project_name.Text
            T_Project.Project_Description = txt_project_description.Text
            T_Project.Address1 = txt_address1.Text
            T_Project.Address2 = txt_address2.Text
            T_Project.City = txt_city.Text
            T_Project.Zip = txt_zip.Text
            T_Project.State_Id = ddl_state.SelectedValue
            T_Project.Country_Id = ddl_country.SelectedValue
            T_Project.Phone = txt_phone.Text
            T_Project.Mobile = txt_mobile.Text
            T_Project.Email = txt_email.Text
            T_Project.Fax = txt_fax.Text

            T_Project.By = Session("User_Id")
            T_Project.executeUpdateProject()

            If T_Project.Error_Id <> 0 Then

                T_Msg = "Error Updating Project Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Updating Project Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Project = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("project_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindCountryList(ddl_country)
        T_Lookup.bindStateList(ddl_state, 1)

        T_Lookup = Nothing

    End Sub
End Class