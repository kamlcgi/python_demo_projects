﻿Public Class view_page
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        getPageInformation()
    End Sub

    Sub getPageInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Page_Id As String = ""

        Try

            T_Page_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Security.Page_Id = T_Page_Id
            T_Security.executeSelectPage()

            If T_Security.Error_Id = 0 Then

                txt_parent_page.Text = T_Security.Parent_Page_Title
                txt_page_title.Text = T_Security.Page_Title
                txt_page_description.Text = T_Security.Page_Description
                txt_navigate_url.Text = T_Security.Navigate_Url

            Else

                T_Msg = "Error Retrieving Page Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Page Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

End Class