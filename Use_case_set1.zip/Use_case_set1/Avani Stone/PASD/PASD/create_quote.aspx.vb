﻿Public Class create_quote
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            setLookups()

        End If

    End Sub

    Protected Sub create_Quote(ByVal sender As Object, ByVal e As EventArgs) Handles btn_create_quote.Click

        add_room.Value = "0"
        createQuoteInformation()

    End Sub

    Protected Sub save_Quote(ByVal sender As Object, ByVal e As EventArgs) Handles btn_save.Click

        add_room.Value = "1"
        createQuoteInformation()

    End Sub


    Sub createQuoteInformation()

        Dim T_Quote As New Quote
        Dim T_Security As New PAL_Security
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Quote.Quote_Name = txt_quote_name.Text
            T_Quote.Quote_Description = txt_quote_description.Text
            T_Quote.Address1 = txt_address1.Text
            T_Quote.Address2 = txt_address2.Text
            T_Quote.City = txt_city.Text
            T_Quote.Zip = txt_zip.Text
            T_Quote.State_Id = ddl_state.SelectedValue
            T_Quote.Country_Id = ddl_country.SelectedValue
            T_Quote.Phone = txt_phone.Text
            T_Quote.Mobile = txt_mobile.Text
            T_Quote.Fax = txt_fax.Text
            T_Quote.Email = txt_email.Text

            T_Quote.Floor = ddl_floor.SelectedValue

            T_Quote.Template_Type_Id = ddl_template_type.SelectedValue
            T_Quote.Construction_Type_Id = ddl_construction_type.SelectedValue
            T_Quote.Sink_Type_Id = ddl_sink_type.SelectedValue

            T_Quote.No_of_Sink = ddl_no_of_sink.SelectedValue
            

            If chk_back_splash.Checked Then
                T_Quote.Back_Splash = "1"
            Else
                T_Quote.Back_Splash = "0"
            End If

            T_Quote.Back_Splash_Details = txt_back_splash_details.Text

            If chk_mill_down.Checked Then
                T_Quote.Mill_Down = "1"
            Else
                T_Quote.Mill_Down = "0"
            End If

            T_Quote.Mill_Down_Details = txt_mill_down_details.Text
            T_Quote.Stove_Type_Id = ddl_stove_type.SelectedValue
            T_Quote.Faucet_Type_Id = ddl_faucet_type.SelectedValue
            T_Quote.Edge_Type_Id = ddl_edge_type.SelectedValue
            T_Quote.Edge_Type_Details = txt_edge_type_details.Text

            If chk_cutouts.Checked Then
                T_Quote.Cutouts = "1"
            Else
                T_Quote.Cutouts = "0"
            End If

            T_Quote.Cutouts_Quantity = ddl_cutouts_qty.SelectedValue

            T_Quote.Material_Id = ddl_material.SelectedValue
            T_Quote.Thickness_Id = ddl_thickness.SelectedValue


            If chk_top_removal.Checked Then
                T_Quote.Top_Removal = "1"
            Else
                T_Quote.Top_Removal = "0"
            End If

            T_Quote.Comments = txt_comments.Text
            T_Quote.Requested_By = Session("User_Id")
            T_Quote.By = Session("User_Id")
            T_Quote.executeCreateQuote()

            If T_Quote.Error_Id = 0 Then

                T_Id = T_Quote.Quote_Detail_Id

                If upl_quote.HasFile Then

                    T_Quote.Quote_File_Name = upl_quote.FileName
                    T_Quote.Quote_File = upl_quote.PostedFile
                    T_Quote.executeAttachLayout()

                End If

            Else

                T_Msg = "Error Creating New Quote Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Creating New Quote Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Quote = Nothing
        T_Security = Nothing

        If T_Msg = "" Then

            If add_room.Value = "1" Then
                Response.Redirect("add_room.aspx?id=" + T_Id)
            Else
                Response.Redirect("quote_manager.aspx")
            End If

        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindCountryList(ddl_country)
        T_Lookup.bindStateList(ddl_state, 1)
        T_Lookup.bindConstructionTypeList(ddl_construction_type)
        T_Lookup.bindTemplateTypeList(ddl_template_type)
        T_Lookup.bindSinkTypeList(ddl_sink_type)
        T_Lookup.bindStoveTypeList(ddl_stove_type)
        T_Lookup.bindFaucetTypeList(ddl_faucet_type)
        T_Lookup.bindEdgeTypeList(ddl_edge_type)
        T_Lookup.bindMaterialList(ddl_material)
        T_Lookup.bindThicknessList(ddl_thickness)

        ddl_state.Items.Insert(0, "-Select-")
        ddl_edge_type.SelectedValue = 1

        T_Lookup = Nothing

    End Sub

    Sub uploadDocument()


        'If upl_quote.HasFile Then

        '    Dim imageSize As Byte() = New Byte(upl_quote.PostedFile.ContentLength - 1) {}

        '    Dim upl_image As HttpPostedFile = upl_quote.PostedFile

        '    upl_image.InputStream.Read(imageSize, 0, CInt(upl_quote.PostedFile.ContentLength))


        '    Dim upl_image2 As New SqlParameter("@Quote_file", SqlDbType.Image, imageSize.Length)
        '    upl_image2.Value = imageSize

        'End If
    End Sub


End Class