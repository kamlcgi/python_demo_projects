﻿Public Class page_manager
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        getAllPages()

    End Sub

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        setRolePermission()

    End Sub

    Private Sub getAllPages()

        Dim T_Security As New PAL_Security

        T_Security.DS_Data = DS_Page_Manager
        T_Security.selectAllPages()

        T_Security = Nothing

    End Sub

    Private Sub setRolePermission()

        Dim T_Security As New PAL_Security

        T_Security.Role_Id = Session("Role_Id")
        T_Security.Navigate_Url = T_Security.Get_Page(Request)
        T_Security.GV_Data = GV_Page_Manager
        T_Security.setGVUserPermission("Page_id", "_page.aspx", "id", "Page_id")

        T_Security = Nothing

    End Sub


End Class