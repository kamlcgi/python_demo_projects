﻿Public Class create_work_order
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            setLookups()
            getQuoteInformation()

        End If

    End Sub

    Protected Sub create_Work_Order(ByVal sender As Object, ByVal e As EventArgs) Handles btn_create_work_order.Click

        createWorkOrderInformation()

    End Sub

    Sub createWorkOrderInformation()

        Dim T_Work_Order As New Work_Order
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Work_Order.Quote_Detail_Id = T_Id

            T_Work_Order.Purchase_Order_Number = txt_purchase_order_no.Text
            T_Work_Order.Purchase_Order_Date = txt_purchase_order_date.Text
            T_Work_Order.Requested_Start_Date = txt_requested_start_date.Text
            T_Work_Order.Work_Order_Comments = txt_work_order_comments.Text

            T_Work_Order.Floor = ddl_floor.SelectedValue

            T_Work_Order.Template_Type_Id = ddl_template_type.SelectedValue
            T_Work_Order.Construction_Type_Id = ddl_construction_type.SelectedValue
            T_Work_Order.Sink_Type_Id = ddl_sink_type.SelectedValue

            T_Work_Order.No_of_Sink = ddl_no_of_sink.SelectedValue

            If chk_back_splash.Checked Then
                T_Work_Order.Back_Splash = "1"
            Else
                T_Work_Order.Back_Splash = "0"
            End If

            T_Work_Order.Back_Splash_Details = txt_back_splash_details.Text

            If chk_mill_down.Checked Then
                T_Work_Order.Mill_Down = "1"
            Else
                T_Work_Order.Mill_Down = "0"
            End If

            T_Work_Order.Mill_Down_Details = txt_mill_down_details.Text
            T_Work_Order.Stove_Type_Id = ddl_stove_type.SelectedValue
            T_Work_Order.Faucet_Type_Id = ddl_faucet_type.SelectedValue
            T_Work_Order.Edge_Type_Id = ddl_edge_type.SelectedValue
            T_Work_Order.Edge_Type_Details = txt_edge_type_details.Text

            If chk_cutouts.Checked Then
                T_Work_Order.Cutouts = "1"
            Else
                T_Work_Order.Cutouts = "0"
            End If

            T_Work_Order.Cutouts_Quantity = ddl_cutouts_qty.SelectedValue

            T_Work_Order.Material_Id = ddl_material.SelectedValue
            T_Work_Order.Thickness_Id = ddl_thickness.SelectedValue

            If chk_top_removal.Checked Then
                T_Work_Order.Top_Removal = "1"
            Else
                T_Work_Order.Top_Removal = "0"
            End If

            T_Work_Order.Sink_Status_Id = ddl_sink_status.SelectedValue
            T_Work_Order.Faucet_Status_Id = ddl_faucet_status.SelectedValue
            T_Work_Order.Kitchen_Island = txt_kitchen_island.Text
            T_Work_Order.Cabinets = txt_cabinets.Text

            T_Work_Order.By = Session("User_Id")
            T_Work_Order.executeCreateWorkOrder()

            If T_Work_Order.Error_Id <> 0 Then

                T_Msg = "Error Creating New Work Order Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Creating New Work Order Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Work_Order = Nothing
        T_Security = Nothing
        T_Encryption = Nothing

        If T_Msg = "" Then
            Response.Redirect("work_order_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub
     

    Sub getQuoteInformation()

        Dim T_Quote As New Quote
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Id As String = ""


        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Quote.Quote_Detail_Id = T_Id
            T_Quote.executeSelectQuote()

            If T_Quote.Error_Id = 0 Then

                txt_quote_detail_no.Text = T_Quote.Quote_Detail_No
                txt_quote_name.Text = T_Quote.Quote_Name
                txt_quote_description.Text = T_Quote.Quote_Description
                txt_address1.Text = T_Quote.Address1
                txt_address2.Text = T_Quote.Address2
                txt_city.Text = T_Quote.City
                txt_zip.Text = T_Quote.Zip

                txt_state.Text = T_Quote.State_Name
                txt_country.Text = T_Quote.Country_Name

                txt_phone.Text = T_Quote.Phone
                txt_mobile.Text = T_Quote.Mobile
                txt_fax.Text = T_Quote.Fax
                txt_email.Text = T_Quote.Email
                ddl_floor.SelectedValue = T_Quote.Floor

                ddl_template_type.SelectedValue = T_Quote.Template_Type_Id
                ddl_construction_type.SelectedValue = T_Quote.Construction_Type_Id
                ddl_sink_type.SelectedValue = T_Quote.Sink_Type_Id
                ddl_no_of_sink.SelectedValue = T_Quote.No_of_Sink

                If T_Quote.Back_Splash = "1" Then
                    chk_back_splash.Checked = True
                Else
                    chk_back_splash.Checked = False
                End If

                txt_back_splash_details.Text = T_Quote.Back_Splash_Details

                If T_Quote.Mill_Down = "1" Then
                    chk_mill_down.Checked = True
                Else
                    chk_mill_down.Checked = False
                End If

                txt_mill_down_details.Text = T_Quote.Mill_Down_Details

                ddl_stove_type.SelectedValue = T_Quote.Stove_Type_Id

                ddl_faucet_type.SelectedValue = T_Quote.Faucet_Type_Id

                ddl_edge_type.SelectedValue = T_Quote.Edge_Type_Id
                txt_edge_type_details.Text = T_Quote.Edge_Type_Details

                If T_Quote.Cutouts = "1" Then
                    chk_cutouts.Checked = True
                Else
                    chk_cutouts.Checked = False
                End If

                ddl_cutouts_qty.SelectedValue = T_Quote.Cutouts_Quantity

                ddl_material.SelectedValue = T_Quote.Material_Id
                ddl_thickness.SelectedValue = T_Quote.Thickness_Id

                If T_Quote.Top_Removal = "1" Then
                    chk_top_removal.Checked = True
                Else
                    chk_top_removal.Checked = True
                End If

            Else

                T_Msg = "Error Retriving Quote Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Retriving Quote Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Quote = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


    Sub setLookups()

        Dim T_Lookup As New PLookup

        T_Lookup.bindConstructionTypeList(ddl_construction_type)
        T_Lookup.bindTemplateTypeList(ddl_template_type)
        T_Lookup.bindSinkTypeList(ddl_sink_type)
        T_Lookup.bindStoveTypeList(ddl_stove_type)
        T_Lookup.bindFaucetTypeList(ddl_faucet_type)
        T_Lookup.bindEdgeTypeList(ddl_edge_type)
        T_Lookup.bindMaterialList(ddl_material)
        T_Lookup.bindThicknessList(ddl_thickness)

        T_Lookup.bindSinkStatusList(ddl_sink_status)
        T_Lookup.bindFaucetStatusList(ddl_faucet_status)

        T_Lookup = Nothing

    End Sub

End Class