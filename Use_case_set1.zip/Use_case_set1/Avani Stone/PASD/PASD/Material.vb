﻿
'Component Name: Material
'Description: Used to Create, Update, View and Delete Material Information
'Author:  Srinivasan Subbanchattiar 
'Created By: Srinivasan Subbanchattiar 
'Created Date: 08/01/2011 
'Modified By: Srinivasan Subbanchattiar 
'Modified Date: 08/01/2011 
'Version: 1.0

Imports System.Web
Imports System.Data
Imports System.Data.SqlClient

Public Class Material



    Protected intErr As Integer
    Protected strErr As String
    Protected strBy As String

    Protected strMaterialId As String
    Protected strMaterialName As String
    Protected strMaterialColor As String
    Protected strMaterialCodeNumber As String

    Protected intMaterialTypeId As Integer
    Protected strMaterialTypeDescription As String

    Protected strMaterialDescription As String

    Protected intFileTypeId As Integer
    Protected strFileTypeDescription As String

    Protected strFileLocation As String

    Protected intCountryId As Integer
    Protected strCountryName As String
    
    Protected gvData As GridView
    Protected dsData As SqlDataSource

    'for view purpose only
    Protected strCreatedBy As String
    Protected dtCreatedDate As Date
    Protected strModifiedBy As String
    Protected dtModifiedDate As Date


    Public Sub New()

        Clear()

    End Sub


    Public Sub Clear()

        intErr = Nothing
        strErr = Nothing
        strBy = Nothing

        strMaterialId = Nothing
        strMaterialName = Nothing

        strMaterialColor = Nothing
        strMaterialCodeNumber = Nothing

        intMaterialTypeId = Nothing
        strMaterialTypeDescription = Nothing

        strMaterialDescription = Nothing

        intFileTypeId = Nothing
        strFileTypeDescription = Nothing
        strFileLocation = Nothing

        intCountryId = Nothing
        strCountryName = Nothing

        gvData = Nothing
        dsData = Nothing

        strCreatedBy = Nothing
        dtCreatedDate = Nothing
        strModifiedBy = Nothing
        dtModifiedDate = Nothing


    End Sub

    Public Property Error_Id() As Integer
        Get
            Return intErr
        End Get
        Set(ByVal Value As Integer)
            intErr = Value
        End Set
    End Property

    Public Property Error_Message() As String
        Get
            Return strErr
        End Get
        Set(ByVal Value As String)
            strErr = Value
        End Set
    End Property

    Public Property Material_Id() As String
        Get
            Return strMaterialId
        End Get
        Set(ByVal Value As String)
            strMaterialId = Value
        End Set
    End Property

    Public Property Material_Name() As String
        Get
            Return strMaterialName
        End Get
        Set(ByVal Value As String)
            strMaterialName = Value
        End Set
    End Property
     
    Public Property Material_Color() As String
        Get
            Return strMaterialColor
        End Get
        Set(ByVal Value As String)
            strMaterialColor = Value
        End Set
    End Property

    Public Property Material_Code_Number() As String
        Get
            Return strMaterialCodeNumber
        End Get
        Set(ByVal Value As String)
            strMaterialCodeNumber = Value
        End Set
    End Property
     

    Public Property Material_Type_Id() As Integer
        Get
            Return intMaterialTypeId
        End Get
        Set(ByVal Value As Integer)
            intMaterialTypeId = Value
        End Set
    End Property

    Public Property Material_Type_Description() As String
        Get
            Return strMaterialTypeDescription
        End Get
        Set(ByVal Value As String)
            strMaterialTypeDescription = Value
        End Set
    End Property

    Public Property Material_Description() As String
        Get
            Return strMaterialDescription
        End Get
        Set(ByVal Value As String)
            strMaterialDescription = Value
        End Set
    End Property

    Public Property File_Type_Id() As Integer
        Get
            Return intFileTypeId
        End Get
        Set(ByVal Value As Integer)
            intFileTypeId = Value
        End Set
    End Property

    Public Property File_Type_Description() As String
        Get
            Return strFileTypeDescription
        End Get
        Set(ByVal Value As String)
            strFileTypeDescription = Value
        End Set
    End Property

    Public Property File_Location() As String
        Get
            Return strFileLocation
        End Get
        Set(ByVal Value As String)
            strFileLocation = Value
        End Set
    End Property

    Public Property Country_Id() As Integer
        Get
            Return intCountryId
        End Get
        Set(ByVal Value As Integer)
            intCountryId = Value
        End Set
    End Property

    Public Property Country_Name() As String
        Get
            Return strCountryName
        End Get
        Set(ByVal Value As String)
            strCountryName = Value
        End Set
    End Property
     

    Public Property DS_Data() As SqlDataSource
        Get
            Return dsData
        End Get
        Set(ByVal Value As SqlDataSource)
            dsData = Value
        End Set
    End Property

    Public Property GV_Data() As GridView
        Get
            Return gvData
        End Get
        Set(ByVal Value As GridView)
            gvData = Value
        End Set
    End Property

    Public Property By() As String
        Get
            Return strBy
        End Get
        Set(ByVal Value As String)
            strBy = Value
        End Set
    End Property

    Public Property Created_By() As String
        Get
            Return strCreatedBy
        End Get
        Set(ByVal Value As String)
            strCreatedBy = Value
        End Set
    End Property

    Public Property Modified_By() As String
        Get
            Return strModifiedBy
        End Get
        Set(ByVal Value As String)
            strModifiedBy = Value
        End Set
    End Property

    Public Property Created_Date() As Date
        Get
            Return dtCreatedDate
        End Get
        Set(ByVal Value As Date)
            dtCreatedDate = Value
        End Set
    End Property

    Public Property Modified_Date() As Date
        Get
            Return dtModifiedDate
        End Get
        Set(ByVal Value As Date)
            dtModifiedDate = Value
        End Set
    End Property

    Public Sub selectAllMaterials()

        Dim dbCon As New DBAccess

        'Get all the material information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_materials"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub executeSelectMaterial()

        If Not IsDBNull(strMaterialId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the material information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_material", _
                         New SqlParameter("@Material_id", strMaterialId))

            If dbRs.Read Then

                If Not IsDBNull(dbRs("Material_name")) Then
                    strMaterialName = dbRs("Material_name")
                End If
                  
                If Not IsDBNull(dbRs("Material_color")) Then
                    strMaterialColor = dbRs("Material_color")
                End If

                If Not IsDBNull(dbRs("Material_code_number")) Then
                    strMaterialCodeNumber = dbRs("Material_code_number")
                End If

                If Not IsDBNull(dbRs("Material_type_id")) Then
                    intMaterialTypeId = dbRs("Material_type_id")
                End If

                If Not IsDBNull(dbRs("Material_type_description")) Then
                    strMaterialTypeDescription = dbRs("Material_type_description")
                End If

                If Not IsDBNull(dbRs("Material_description")) Then
                    strMaterialDescription = dbRs("Material_description")
                End If

                If Not IsDBNull(dbRs("File_type_id")) Then
                    intFileTypeId = dbRs("File_type_id")
                End If


                If Not IsDBNull(dbRs("File_type_description")) Then
                    strFileTypeDescription = dbRs("File_type_description")
                End If

                If Not IsDBNull(dbRs("File_location")) Then
                    strFileLocation = dbRs("File_location")
                End If

                If Not IsDBNull(dbRs("Country_Id")) Then
                    intCountryId = dbRs("Country_Id")
                End If

                If Not IsDBNull(dbRs("Country_Name")) Then
                    strCountryName = dbRs("Country_Name")
                End If

                If Not IsDBNull(dbRs("Created_by")) Then
                    strCreatedBy = dbRs("Created_by")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                If Not IsDBNull(dbRs("Created_date")) Then
                    dtCreatedDate = dbRs("Created_date")
                End If

                If Not IsDBNull(dbRs("Modified_date")) Then
                    dtModifiedDate = dbRs("Modified_date")
                End If

                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 'Id is Nothing
            strErr = "Id is Nothing"

        End If

    End Sub 'executeSelectMaterial()


    Public Sub executeCreateMaterial()


        Dim dbCon As New DBAccess
        Dim T_User_id As String

        'Create New Material to the database 

        T_User_id = dbCon.RunSPReturnId("dbo.sp_create_material_wiz", _
                         New SqlParameter("@Material_name", strMaterialName), _
                         New SqlParameter("@Material_color", strMaterialColor), _
                         New SqlParameter("@Material_code_number", strMaterialCodeNumber), _
                         New SqlParameter("@Material_type_id", intMaterialTypeId), _
                         New SqlParameter("@Material_description", strMaterialDescription), _
                         New SqlParameter("@File_type_id", intFileTypeId), _
                         New SqlParameter("@File_location", strFileLocation), _
                         New SqlParameter("@country_id", intCountryId), _
                         New SqlParameter("@created_by", strBy))

        If T_User_id = "-1" Then

            intErr = -1 'Create New Material Failed
            strErr = "Create New Material Failed"

        Else

            intErr = 0 'New Material Created Successfully
            strErr = "New Material Created Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeCreateMaterial()


    Public Sub executeUpdateMaterial()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Save Material Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_material_wiz", _
                         New SqlParameter("@Material_id", strMaterialId), _
                         New SqlParameter("@Material_name", strMaterialName), _
                         New SqlParameter("@Material_color", strMaterialColor), _
                         New SqlParameter("@Material_code_number", strMaterialCodeNumber), _
                         New SqlParameter("@Material_type_id", intMaterialTypeId), _
                         New SqlParameter("@Material_description", strMaterialDescription), _
                         New SqlParameter("@File_type_id", intFileTypeId), _
                         New SqlParameter("@File_location", strFileLocation), _
                         New SqlParameter("@country_id", intCountryId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = -1 Then

            intErr = -1 'Update Material Failed
            strErr = "Update Material Failed"

        Else

            intErr = 0 'Material Information Saved Successfully
            strErr = "Material Information Saved Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateMaterial()



    Public Sub executeDeleteMaterial()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Delete Material Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_delete_material_wiz", _
                         New SqlParameter("@Material_id", strMaterialId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Delete Material Failed
            strErr = "Delete Material Failed"

        Else

            intErr = 0 'Material Information Deleted Successfully
            strErr = "Material Information Deleted Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeleteMaterial()

End Class
