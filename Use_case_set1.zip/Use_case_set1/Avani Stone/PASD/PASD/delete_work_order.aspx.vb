﻿Public Class delete_work_order
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            getWorkOrderInformation()

        End If

    End Sub

    Protected Sub delete_WorkOrder(ByVal sender As Object, ByVal e As EventArgs) Handles btn_delete.Click

        deleteWorkOrderInformation()

    End Sub

    Sub getWorkOrderInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Work_Order As New Work_Order
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Work_Order.Work_Order_Id = T_Id
            T_Work_Order.executeSelectWorkOrder()

            If T_Work_Order.Error_Id = 0 Then

                lbl_text.Text = T_Work_Order.Work_Order_Number

            Else

                T_Msg = "Error Retrieving Work Order Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Work Order Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Work_Order = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub deleteWorkOrderInformation()

        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Work_Order As New Work_Order
        Dim T_Msg As String = ""
        Dim T_Id As String = ""

        Try

            T_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Work_Order.Work_Order_Id = T_Id

            T_Work_Order.By = Session("User_Id")
            T_Work_Order.executeDeleteWorkOrder()

            If T_Work_Order.Error_Id <> 0 Then

                T_Msg = "Error Deleteing Work Order Information."
                T_Security.Browser(Request)
                T_Security.By = Session("WorkOrder_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Work Order Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Work_Order = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("Work_order_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

End Class