﻿Public Class view_material
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            getMaterialInformation()

        End If

    End Sub

    Sub getMaterialInformation()

        Dim T_Material As New Material
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_Material_Id As String = ""

        Try

            T_Material_Id = T_Encryption.decode(Request.QueryString("id"))

            T_Material.Material_Id = T_Material_Id
            T_Material.executeSelectMaterial()

            If T_Material.Error_Id = 0 Then

                txt_Material_name.Text = T_Material.Material_Name
                txt_material_color.Text = T_Material.Material_Color
                txt_material_code_number.Text = T_Material.Material_Code_Number
                txt_material_type.Text = T_Material.Material_Type_Description
                txt_file_type.Text = T_Material.File_Type_Description
                txt_material_description.Text = T_Material.Material_Description
                txt_file_location.Text = T_Material.File_Location
                txt_country.Text = T_Material.Country_Name

            Else

                T_Msg = "Error Retrieving Material Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Material Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


End Class