﻿Public Class delete_account
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            getaccountInformation()

        End If

    End Sub

    Protected Sub delete_account(ByVal sender As Object, ByVal e As EventArgs) Handles btn_delete.Click

        deleteaccountInformation()

    End Sub


    Sub getAccountInformation()

        Dim T_account As New Account
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_account_Id As String = ""

        Try

            T_account_Id = T_Encryption.decode(Request.QueryString("id"))

            T_account.Account_Id = T_account_Id
            T_account.executeSelectAccount()

            If T_account.Error_Id = 0 Then

                lbl_text.Text = T_account.Account_Name

            Else

                T_Msg = "Error Retrieving Account Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Account Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Sub deleteAccountInformation()

        Dim T_account As New Account
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_account_Id As String = ""

        Try

            T_account_Id = T_Encryption.decode(Request.QueryString("id"))

            T_account.Account_Id = T_account_Id
            T_account.By = Session("User_Id")
            T_account.executeDeleteAccount()

            If T_account.Error_Id <> 0 Then

                T_Msg = "Error Deleting Account Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Deleting Account Information."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Security = Nothing

        If T_Msg = "" Then
            Response.Redirect("account_manager.aspx")
        Else
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

End Class