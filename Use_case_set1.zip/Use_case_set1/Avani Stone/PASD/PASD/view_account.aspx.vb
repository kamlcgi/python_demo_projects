﻿Public Class view_account
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            getAccountInformation()
            getAllUsersByAccount()

        End If

    End Sub

    Protected Sub gv_sorting(ByVal sender As Object, ByVal e As GridViewSortEventArgs) Handles GV_User_Manager.Sorting

        getAllUsersByAccount()

    End Sub

    Sub getAccountInformation()

        Dim T_account As New Account
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_account_Id As String = ""

        Try

            T_account_Id = T_Encryption.decode(Request.QueryString("id"))

            T_account.Account_Id = T_account_Id
            T_account.executeSelectAccount()

            If T_account.Error_Id = 0 Then

                txt_account_name.Text = T_account.Account_Name
                txt_address1.Text = T_account.Address1
                txt_address2.Text = T_account.Address2
                txt_city.Text = T_account.City
                txt_zip.Text = T_account.Zip
                txt_state.Text = T_account.State_Name
                txt_country.Text = T_account.Country_Name
                txt_phone.Text = T_account.Phone
                txt_mobile.Text = T_account.Mobile
                txt_email.Text = T_account.Email
                txt_fax.Text = T_account.Fax

            Else

                T_Msg = "Error Retrieving Account Information."
                T_Security.Browser(Request)
                T_Security.By = Session("User_Id")
                T_Security.Log_Data = T_Msg
                T_Security.executeCreateUserLog()

            End If

        Catch ex As Exception

            T_Msg = "Error Decoding Account Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub

    Private Sub getAllUsersByAccount()

        Dim T_account As New Account
        Dim T_Security As New PAL_Security
        Dim T_Encryption As New PAL_Encryption
        Dim T_Msg As String = ""
        Dim T_account_Id As String = ""

        Try

            T_account_Id = T_Encryption.decode(Request.QueryString("id"))

            T_account.Account_Id = T_account_Id
            T_account.DS_Data = DS_User_Manager
            T_account.selectAllUsersByAccount()

        Catch ex As Exception

            T_Msg = "Error Decoding Account Id."
            T_Security.Browser(Request)
            T_Security.By = Session("User_Id")
            T_Security.Log_Data = ex.ToString()
            T_Security.executeCreateUserLog()

        End Try

        T_account = Nothing
        T_Encryption = Nothing
        T_Security = Nothing

        If T_Msg <> "" Then
            Response.Redirect("error_message.aspx?msg=" & T_Msg)
        End If

    End Sub


End Class