﻿Imports System
Imports System.Configuration
Imports System.Web
Imports System.IO
Imports System.Data
Imports System.Data.SqlClient

Public Class show_file
    Implements IHttpHandler

    Public Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest

        Dim T_Encryption As New PAL_Encryption

        Dim T_Id As String

        'Get all the file information from the database
        T_Id = T_Encryption.decode(context.Request.QueryString("id"))

        Try

            Using myConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("PALDBConnectionString").ConnectionString)
                Const SQL As String = "SELECT Quote_File FROM dbo.Quote_Detail_File WHERE Quote_detail_id = @ID"
                Dim myCommand As New SqlCommand(SQL, myConnection)
                myCommand.Parameters.AddWithValue("@ID", T_Id)

                myConnection.Open()

                Dim img As Object = myCommand.ExecuteScalar()
                'Dim myReader As SqlDataReader = myCommand.ExecuteReader()
                context.Response.ContentType = "image/jpeg"

                Dim strm As Stream = New MemoryStream(CType(img, Byte()))
                Dim buffer As Byte() = New Byte(4095) {}
                Dim byteSeq As Integer = strm.Read(buffer, 0, 4096)

                Do While byteSeq > 0
                    context.Response.OutputStream.Write(buffer, 0, byteSeq)
                    byteSeq = strm.Read(buffer, 0, 4096)
                Loop

                'context.Response.Buffer = True
                'context.Response.Clear()
                'context.Response.ContentType = "application/pdf"
                'context.Response.AddHeader("content-disposition", "attachment;filename=Tr.pdf")
                'context.Response.BinaryWrite(CType(img, Byte()))
                'context.Response.End()

                myConnection.Close()
            End Using
        Catch ex As Exception
            context.Response.Write(ex.ToString())
        End Try

        T_Encryption = Nothing

    End Sub

   

    Public ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property


End Class
