﻿
'Component Name: Work_Order
'Description: Used to Create, Update, View and Delete Work Order Information
'Author:  Srinivasan Subbanchattiar 
'Created By: Srinivasan Subbanchattiar 
'Created Date: 08/01/2011 
'Modified By: Srinivasan Subbanchattiar 
'Modified Date: 08/01/2011 
'Version: 1.0

Imports System.Web
Imports System.Data
Imports System.Data.SqlClient

Public Class Work_Order


    Protected intErr As Integer
    Protected strErr As String
    Protected strBy As String

    Protected strWorkOrderId As String
    Protected strWorkOrderNumber As String

    Protected strPurchaseOrderNumber As String
    Protected dtPurchaseOrderDate As String

    Protected strRequestedStartDate As String

    Protected strQuoteId As String
    Protected strQuoteName As String
    Protected strQuoteDescription As String

    Protected strQuoteNo As String
    Protected strQuoteDetailNo As String

    Protected strQuoteDetailId As String

    Protected strAddress1 As String
    Protected strAddress2 As String
    Protected strCity As String

    Protected intStateId As Integer
    Protected strStateName As String

    Protected intCountryId As Integer
    Protected strCountryName As String
    Protected strZip As String
    Protected strPhone As String
    Protected strMobile As String
    Protected strFax As String
    Protected strEmail As String

    Protected strFloor As String

    Protected intTemplateTypeId As Integer
    Protected strTemplateTypeDescription As String

    Protected intConstructionTypeId As Integer
    Protected strConstructionTypeDescription As String

    Protected intSinkTypeId As Integer
    Protected strSinkTypeDescrption As String

    Protected intNoofSink As Integer

    Protected intSinkStatusId As Integer
    Protected strSinkStatusDescription As String

    Protected strBackSplash As String
    Protected strBackSplashDetails As String

    Protected strMillDown As String
    Protected strMillDownDetails As String

    Protected intStoveTypeId As Integer
    Protected strStoveTypeDescrption As String

    Protected intFaucetTypeId As Integer
    Protected strFaucetTypeDescrption As String

    Protected intFaucetStatusId As Integer
    Protected strFaucetStatusDescription As String

    Protected intEdgeTypeId As Integer
    Protected strEdgeTypeDescription As String
    Protected strEdgeTypeFile As String
    Protected strEdgeTypeDetails As String

    Protected strCutouts As String
    Protected intCutoutsQuantity As Integer

    Protected strMaterialId As String
    Protected strMaterialName As String

    Protected intThicknessId As Integer
    Protected strThicknessDescription As String

    Protected hpfQuoteFile As HttpPostedFile
    Protected strQuoteFileName As String
    Protected strQuoteFileMime As String

    Protected hpfEstimateFile As HttpPostedFile
    Protected strEstimateFileName As String
    Protected strEstimateFileMime As String

    Protected strTopRemoval As String

    Protected strTemplate As String
    Protected strFabrication As String
    Protected strInstallation As String
    Protected strRepair As String

    Protected strKitchenIsland As String
    Protected strCabinets As String

    Protected strServiceCompleted As String
    Protected dtServiceCompletedDate As String

    Protected strComments As String
    Protected strWorkOrderComments As String


    Protected dtTemplateDate As String
    Protected dtFabricationDate As String
    Protected dtInstallationDate As String
    Protected dtRepairServiceDate As String
    Protected dtVerifiedDate As String


    Protected strTemplateBy As String
    Protected strFabricationBy As String
    Protected strInstallationBy As String
    Protected strRepairServiceBy As String
    Protected strVerifiedBy As String

    Protected strTemplateById As String
    Protected strFabricationById As String
    Protected strInstallationById As String
    Protected strRepairServiceById As String
    Protected strVerifiedById As String


    Protected intTimeSlotId As Integer
    Protected strTimeSlotDescription As String

    Protected intEstimateSQFT As Integer
    Protected intActualSQFT As Integer
    Protected strTemplateCompleted As String
    Protected strTemplateAccepted As String

    Protected strRequestedBy As String

    Protected gvData As GridView
    Protected dsData As SqlDataSource

    'for view purpose only
    Protected strCreatedBy As String
    Protected dtCreatedDate As Date
    Protected strModifiedBy As String
    Protected dtModifiedDate As Date


    Public Sub New()

        Clear()

    End Sub


    Public Sub Clear()

        intErr = Nothing
        strErr = Nothing
        strBy = Nothing

        strWorkOrderId = Nothing
        strWorkOrderNumber = Nothing

        strPurchaseOrderNumber = Nothing
        dtPurchaseOrderDate = Nothing
        strRequestedStartDate = Nothing

        strTemplate = Nothing
        strFabrication = Nothing
        strInstallation = Nothing
        strRepair = Nothing
        strQuoteId = Nothing
        strQuoteName = Nothing
        strQuoteDescription = Nothing

        strQuoteNo = Nothing
        strQuoteDetailNo = Nothing

        strQuoteDetailId = Nothing

        strAddress1 = Nothing
        strAddress2 = Nothing
        strCity = Nothing

        intStateId = Nothing
        strStateName = Nothing

        intCountryId = Nothing
        strCountryName = Nothing
        strZip = Nothing
        strPhone = Nothing
        strMobile = Nothing
        strFax = Nothing
        strEmail = Nothing

        strFloor = Nothing
        intTemplateTypeId = Nothing
        strTemplateTypeDescription = Nothing

        intConstructionTypeId = Nothing
        strConstructionTypeDescription = Nothing

        intSinkTypeId = Nothing
        strSinkTypeDescrption = Nothing

        intNoofSink = Nothing

        intSinkStatusId = Nothing
        strSinkStatusDescription = Nothing

        strBackSplash = Nothing
        strBackSplashDetails = Nothing

        strMillDown = Nothing
        strMillDownDetails = Nothing

        intStoveTypeId = Nothing
        strStoveTypeDescrption = Nothing

        intFaucetTypeId = Nothing
        strFaucetTypeDescrption = Nothing

        intFaucetStatusId = Nothing
        strFaucetStatusDescription = Nothing

        intEdgeTypeId = Nothing
        strEdgeTypeDescription = Nothing
        strEdgeTypeFile = Nothing
        strEdgeTypeDetails = Nothing

        strCutouts = Nothing
        intCutoutsQuantity = Nothing

        strMaterialId = Nothing
        strMaterialName = Nothing

        intThicknessId = Nothing
        strThicknessDescription = Nothing

        hpfQuoteFile = Nothing
        strQuoteFileName = Nothing
        strQuoteFileMime = Nothing

        hpfEstimateFile = Nothing
        strEstimateFileName = Nothing
        strEstimateFileMime = Nothing

        strTopRemoval = Nothing
        strComments = Nothing

        strKitchenIsland = Nothing
        strCabinets = Nothing

        strTemplate = Nothing
        strFabrication = Nothing
        strInstallation = Nothing

        strServiceCompleted = Nothing
        dtServiceCompletedDate = Nothing

        strComments = Nothing

        strWorkOrderComments = Nothing

        dtTemplateDate = Nothing
        dtFabricationDate = Nothing
        dtInstallationDate = Nothing
        dtRepairServiceDate = Nothing
        dtVerifiedDate = Nothing

        strTemplateBy = Nothing
        strFabricationBy = Nothing
        strInstallationBy = Nothing
        strRepairServiceBy = Nothing
        strVerifiedBy = Nothing

        strTemplateById = Nothing
        strFabricationById = Nothing
        strInstallationById = Nothing
        strRepairServiceById = Nothing
        strVerifiedById = Nothing

        intTimeSlotId = Nothing
        strTimeSlotDescription = Nothing

        intEstimateSQFT = Nothing
        intActualSQFT = Nothing
        strTemplateCompleted = Nothing
        strTemplateAccepted = Nothing

        strRequestedBy = Nothing

        gvData = Nothing
        dsData = Nothing

        strCreatedBy = Nothing
        dtCreatedDate = Nothing
        strModifiedBy = Nothing
        dtModifiedDate = Nothing


    End Sub

    Public Property Error_Id() As Integer
        Get
            Return intErr
        End Get
        Set(ByVal Value As Integer)
            intErr = Value
        End Set
    End Property

    Public Property Error_Message() As String
        Get
            Return strErr
        End Get
        Set(ByVal Value As String)
            strErr = Value
        End Set
    End Property

    Public Property Work_Order_Id() As String
        Get
            Return strWorkOrderId
        End Get
        Set(ByVal Value As String)
            strWorkOrderId = Value
        End Set
    End Property

    Public Property Work_Order_Number() As String
        Get
            Return strWorkOrderNumber
        End Get
        Set(ByVal Value As String)
            strWorkOrderNumber = Value
        End Set
    End Property


    Public Property Purchase_Order_Number() As String
        Get
            Return strPurchaseOrderNumber
        End Get
        Set(ByVal Value As String)
            strPurchaseOrderNumber = Value
        End Set
    End Property


    Public Property Purchase_Order_Date() As String
        Get
            Return dtPurchaseOrderDate
        End Get
        Set(ByVal Value As String)
            dtPurchaseOrderDate = Value
        End Set
    End Property

    Public Property Requested_Start_Date() As String
        Get
            Return strRequestedStartDate
        End Get
        Set(ByVal Value As String)
            strRequestedStartDate = Value
        End Set
    End Property

    Public Property Quote_Id() As String
        Get
            Return strQuoteId
        End Get
        Set(ByVal Value As String)
            strQuoteId = Value
        End Set
    End Property

    Public Property Quote_Detail_Id() As String
        Get
            Return strQuoteDetailId
        End Get
        Set(ByVal Value As String)
            strQuoteDetailId = Value
        End Set
    End Property

    Public Property Quote_No() As String
        Get
            Return strQuoteNo
        End Get
        Set(ByVal Value As String)
            strQuoteNo = Value
        End Set
    End Property


    Public Property Quote_Detail_No() As String
        Get
            Return strQuoteDetailNo
        End Get
        Set(ByVal Value As String)
            strQuoteDetailNo = Value
        End Set
    End Property

    Public Property Quote_Name() As String
        Get
            Return strQuoteName
        End Get
        Set(ByVal Value As String)
            strQuoteName = Value
        End Set
    End Property

    Public Property Quote_Description() As String
        Get
            Return strQuoteDescription
        End Get
        Set(ByVal Value As String)
            strQuoteDescription = Value
        End Set
    End Property

    Public Property Address1() As String
        Get
            Return strAddress1
        End Get
        Set(ByVal Value As String)
            strAddress1 = Value
        End Set
    End Property

    Public Property Address2() As String
        Get
            Return strAddress2
        End Get
        Set(ByVal Value As String)
            strAddress2 = Value
        End Set
    End Property

    Public Property City() As String
        Get
            Return strCity
        End Get
        Set(ByVal Value As String)
            strCity = Value
        End Set
    End Property

    Public Property State_Id() As Integer
        Get
            Return intStateId
        End Get
        Set(ByVal Value As Integer)
            intStateId = Value
        End Set
    End Property

    Public Property State_Name() As String
        Get
            Return strStateName
        End Get
        Set(ByVal Value As String)
            strStateName = Value
        End Set
    End Property

    Public Property Zip() As String
        Get
            Return strZip
        End Get
        Set(ByVal Value As String)
            strZip = Value
        End Set
    End Property

    Public Property Country_Id() As Integer
        Get
            Return intCountryId
        End Get
        Set(ByVal Value As Integer)
            intCountryId = Value
        End Set
    End Property

    Public Property Country_Name() As String
        Get
            Return strCountryName
        End Get
        Set(ByVal Value As String)
            strCountryName = Value
        End Set
    End Property


    Public Property Phone() As String
        Get
            Return strPhone
        End Get
        Set(ByVal Value As String)
            strPhone = Value
        End Set
    End Property

    Public Property Mobile() As String
        Get
            Return strMobile
        End Get
        Set(ByVal Value As String)
            strMobile = Value
        End Set
    End Property

    Public Property Fax() As String
        Get
            Return strFax
        End Get
        Set(ByVal Value As String)
            strFax = Value
        End Set
    End Property

    Public Property Email() As String
        Get
            Return strEmail
        End Get
        Set(ByVal Value As String)
            strEmail = Value
        End Set
    End Property

    Public Property Floor() As String
        Get
            Return strFloor
        End Get
        Set(ByVal Value As String)
            strFloor = Value
        End Set
    End Property

    Public Property Template_Type_Id() As Integer
        Get
            Return intTemplateTypeId
        End Get
        Set(ByVal Value As Integer)
            intTemplateTypeId = Value
        End Set
    End Property

    Public Property Template_Type_Description() As String
        Get
            Return strTemplateTypeDescription
        End Get
        Set(ByVal Value As String)
            strTemplateTypeDescription = Value
        End Set
    End Property

    Public Property Construction_Type_Id() As Integer
        Get
            Return intConstructionTypeId
        End Get
        Set(ByVal Value As Integer)
            intConstructionTypeId = Value
        End Set
    End Property

    Public Property Construction_Type_Description() As String
        Get
            Return strConstructionTypeDescription
        End Get
        Set(ByVal Value As String)
            strConstructionTypeDescription = Value
        End Set
    End Property

    Public Property Sink_Type_Id() As Integer
        Get
            Return intSinkTypeId
        End Get
        Set(ByVal Value As Integer)
            intSinkTypeId = Value
        End Set
    End Property

    Public Property Sink_Type_Descrption() As String
        Get
            Return strSinkTypeDescrption
        End Get
        Set(ByVal Value As String)
            strSinkTypeDescrption = Value
        End Set
    End Property

    Public Property No_of_Sink() As Integer
        Get
            Return intNoofSink
        End Get
        Set(ByVal Value As Integer)
            intNoofSink = Value
        End Set
    End Property

    Public Property Sink_Status_Id() As Integer
        Get
            Return intSinkStatusId
        End Get
        Set(ByVal Value As Integer)
            intSinkStatusId = Value
        End Set
    End Property

    Public Property Sink_Status_Description() As String
        Get
            Return strSinkStatusDescription
        End Get
        Set(ByVal Value As String)
            strSinkStatusDescription = Value
        End Set
    End Property

    Public Property Back_Splash() As String
        Get
            Return strBackSplash
        End Get
        Set(ByVal Value As String)
            strBackSplash = Value
        End Set
    End Property

    Public Property Back_Splash_Details() As String
        Get
            Return strBackSplashDetails
        End Get
        Set(ByVal Value As String)
            strBackSplashDetails = Value
        End Set
    End Property


    Public Property Mill_Down() As String
        Get
            Return strMillDown
        End Get
        Set(ByVal Value As String)
            strMillDown = Value
        End Set
    End Property

    Public Property Mill_Down_Details() As String
        Get
            Return strMillDownDetails
        End Get
        Set(ByVal Value As String)
            strMillDownDetails = Value
        End Set
    End Property

    Public Property Stove_Type_Id() As Integer
        Get
            Return intStoveTypeId
        End Get
        Set(ByVal Value As Integer)
            intStoveTypeId = Value
        End Set
    End Property

    Public Property Stove_Type_Descrption() As String
        Get
            Return strStoveTypeDescrption
        End Get
        Set(ByVal Value As String)
            strStoveTypeDescrption = Value
        End Set
    End Property


    Public Property Faucet_Type_Id() As Integer
        Get
            Return intFaucetTypeId
        End Get
        Set(ByVal Value As Integer)
            intFaucetTypeId = Value
        End Set
    End Property

    Public Property Faucet_Type_Descrption() As String
        Get
            Return strFaucetTypeDescrption
        End Get
        Set(ByVal Value As String)
            strFaucetTypeDescrption = Value
        End Set
    End Property

    Public Property Faucet_Status_Id() As Integer
        Get
            Return intFaucetStatusId
        End Get
        Set(ByVal Value As Integer)
            intFaucetStatusId = Value
        End Set
    End Property

    Public Property Faucet_Status_Description() As String
        Get
            Return strFaucetStatusDescription
        End Get
        Set(ByVal Value As String)
            strFaucetStatusDescription = Value
        End Set
    End Property

    Public Property Edge_Type_Id() As Integer
        Get
            Return intEdgeTypeId
        End Get
        Set(ByVal Value As Integer)
            intEdgeTypeId = Value
        End Set
    End Property

    Public Property Edge_Type_Description() As String
        Get
            Return strEdgeTypeDescription
        End Get
        Set(ByVal Value As String)
            strEdgeTypeDescription = Value
        End Set
    End Property

    Public Property Edge_Type_File() As String
        Get
            Return strEdgeTypeFile
        End Get
        Set(ByVal Value As String)
            strEdgeTypeFile = Value
        End Set
    End Property

    Public Property Edge_Type_Details() As String
        Get
            Return strEdgeTypeDetails
        End Get
        Set(ByVal Value As String)
            strEdgeTypeDetails = Value
        End Set
    End Property


    Public Property Cutouts() As String
        Get
            Return strCutouts
        End Get
        Set(ByVal Value As String)
            strCutouts = Value
        End Set
    End Property

    Public Property Cutouts_Quantity() As Integer
        Get
            Return intCutoutsQuantity
        End Get
        Set(ByVal Value As Integer)
            intCutoutsQuantity = Value
        End Set
    End Property


    Public Property Material_Id() As String
        Get
            Return strMaterialId
        End Get
        Set(ByVal Value As String)
            strMaterialId = Value
        End Set
    End Property

    Public Property Material_Name() As String
        Get
            Return strMaterialName
        End Get
        Set(ByVal Value As String)
            strMaterialName = Value
        End Set
    End Property

    Public Property Thickness_Id() As Integer
        Get
            Return intThicknessId
        End Get
        Set(ByVal Value As Integer)
            intThicknessId = Value
        End Set
    End Property

    Public Property Thickness_Description() As String
        Get
            Return strThicknessDescription
        End Get
        Set(ByVal Value As String)
            strThicknessDescription = Value
        End Set
    End Property

    Public Property Quote_File() As HttpPostedFile
        Get
            Return hpfQuoteFile
        End Get
        Set(ByVal Value As HttpPostedFile)
            hpfQuoteFile = Value
        End Set
    End Property

    Public Property Quote_File_Name() As String
        Get
            Return strQuoteFileName
        End Get
        Set(ByVal Value As String)
            strQuoteFileName = Value
        End Set
    End Property

    Public Property Quote_File_Mime() As String
        Get
            Return strQuoteFileMime
        End Get
        Set(ByVal Value As String)
            strQuoteFileMime = Value
        End Set
    End Property

    Public Property Estimate_File() As HttpPostedFile
        Get
            Return hpfEstimateFile
        End Get
        Set(ByVal Value As HttpPostedFile)
            hpfEstimateFile = Value
        End Set
    End Property

    Public Property Estimate_File_Name() As String
        Get
            Return strEstimateFileName
        End Get
        Set(ByVal Value As String)
            strEstimateFileName = Value
        End Set
    End Property

    Public Property Estimate_File_Mime() As String
        Get
            Return strEstimateFileMime
        End Get
        Set(ByVal Value As String)
            strEstimateFileMime = Value
        End Set
    End Property

    Public Property Top_Removal() As String
        Get
            Return strTopRemoval
        End Get
        Set(ByVal Value As String)
            strTopRemoval = Value
        End Set
    End Property

    Public Property Kitchen_Island() As String
        Get
            Return strKitchenIsland
        End Get
        Set(ByVal Value As String)
            strKitchenIsland = Value
        End Set
    End Property

    Public Property Cabinets() As String
        Get
            Return strCabinets
        End Get
        Set(ByVal Value As String)
            strCabinets = Value
        End Set
    End Property

    Public Property Template() As String
        Get
            Return strTemplate
        End Get
        Set(ByVal Value As String)
            strTemplate = Value
        End Set
    End Property

    Public Property Fabrication() As String
        Get
            Return strFabrication
        End Get
        Set(ByVal Value As String)
            strFabrication = Value
        End Set
    End Property

    Public Property Installation() As String
        Get
            Return strInstallation
        End Get
        Set(ByVal Value As String)
            strInstallation = Value
        End Set
    End Property

    Public Property Repair() As String
        Get
            Return strRepair
        End Get
        Set(ByVal Value As String)
            strRepair = Value
        End Set
    End Property

    Public Property Service_Completed() As String
        Get
            Return strServiceCompleted
        End Get
        Set(ByVal Value As String)
            strServiceCompleted = Value
        End Set
    End Property

    Public Property Service_Completed_Date() As String
        Get
            Return dtServiceCompletedDate
        End Get
        Set(ByVal Value As String)
            dtServiceCompletedDate = Value
        End Set
    End Property

    Public Property Comments() As String
        Get
            Return strComments
        End Get
        Set(ByVal Value As String)
            strComments = Value
        End Set
    End Property

    Public Property Work_Order_Comments() As String
        Get
            Return strWorkOrderComments
        End Get
        Set(ByVal Value As String)
            strWorkOrderComments = Value
        End Set
    End Property

    Public Property Template_Date() As String
        Get
            Return dtTemplateDate
        End Get
        Set(ByVal Value As String)
            dtTemplateDate = Value
        End Set
    End Property

    Public Property Fabrication_Date() As String
        Get
            Return dtFabricationDate
        End Get
        Set(ByVal Value As String)
            dtFabricationDate = Value
        End Set
    End Property

    Public Property Installation_Date() As String
        Get
            Return dtInstallationDate
        End Get
        Set(ByVal Value As String)
            dtInstallationDate = Value
        End Set
    End Property

    Public Property Repair_Service_Date() As String
        Get
            Return dtRepairServiceDate
        End Get
        Set(ByVal Value As String)
            dtRepairServiceDate = Value
        End Set
    End Property

    Public Property Verified_Date() As String
        Get
            Return dtVerifiedDate
        End Get
        Set(ByVal Value As String)
            dtVerifiedDate = Value
        End Set
    End Property

    Public Property Template_By_Id() As String
        Get
            Return strTemplateById
        End Get
        Set(ByVal Value As String)
            strTemplateById = Value
        End Set
    End Property

    Public Property Fabrication_By_Id() As String
        Get
            Return strFabricationById
        End Get
        Set(ByVal Value As String)
            strFabricationById = Value
        End Set
    End Property
    Public Property Installation_By_Id() As String
        Get
            Return strInstallationById
        End Get
        Set(ByVal Value As String)
            strInstallationById = Value
        End Set
    End Property

    Public Property Repair_Service_By_Id() As String
        Get
            Return strRepairServiceById
        End Get
        Set(ByVal Value As String)
            strRepairServiceById = Value
        End Set
    End Property

    Public Property Verified_By_Id() As String
        Get
            Return strVerifiedById
        End Get
        Set(ByVal Value As String)
            strVerifiedById = Value
        End Set
    End Property

    Public Property Template_By() As String
        Get
            Return strTemplateBy
        End Get
        Set(ByVal Value As String)
            strTemplateBy = Value
        End Set
    End Property

    Public Property Fabrication_By() As String
        Get
            Return strFabricationBy
        End Get
        Set(ByVal Value As String)
            strFabricationBy = Value
        End Set
    End Property
    Public Property Installation_By() As String
        Get
            Return strInstallationBy
        End Get
        Set(ByVal Value As String)
            strInstallationBy = Value
        End Set
    End Property

    Public Property Repair_Service_By() As String
        Get
            Return strRepairServiceBy
        End Get
        Set(ByVal Value As String)
            strRepairServiceBy = Value
        End Set
    End Property

    Public Property Verified_By() As String
        Get
            Return strVerifiedBy
        End Get
        Set(ByVal Value As String)
            strVerifiedBy = Value
        End Set
    End Property

    Public Property Time_Slot_Id() As Integer
        Get
            Return intTimeSlotId
        End Get
        Set(ByVal Value As Integer)
            intTimeSlotId = Value
        End Set
    End Property

    Public Property Time_Slot_Description() As String
        Get
            Return strTimeSlotDescription
        End Get
        Set(ByVal Value As String)
            strTimeSlotDescription = Value
        End Set
    End Property

    Public Property Estimate_SQFT() As String
        Get
            Return intEstimateSQFT
        End Get
        Set(ByVal Value As String)
            intEstimateSQFT = Value
        End Set
    End Property

    Public Property Actual_SQFT() As String
        Get
            Return intActualSQFT
        End Get
        Set(ByVal Value As String)
            intActualSQFT = Value
        End Set
    End Property

    Public Property Template_Completed() As String
        Get
            Return strTemplateCompleted
        End Get
        Set(ByVal Value As String)
            strTemplateCompleted = Value
        End Set
    End Property

    Public Property Template_Accepted() As String
        Get
            Return strTemplateAccepted
        End Get
        Set(ByVal Value As String)
            strTemplateAccepted = Value
        End Set
    End Property

    Public Property Requested_By() As String
        Get
            Return strRequestedBy
        End Get
        Set(ByVal Value As String)
            strRequestedBy = Value
        End Set
    End Property


    Public Property DS_Data() As SqlDataSource
        Get
            Return dsData
        End Get
        Set(ByVal Value As SqlDataSource)
            dsData = Value
        End Set
    End Property

    Public Property GV_Data() As GridView
        Get
            Return gvData
        End Get
        Set(ByVal Value As GridView)
            gvData = Value
        End Set
    End Property

    Public Property By() As String
        Get
            Return strBy
        End Get
        Set(ByVal Value As String)
            strBy = Value
        End Set
    End Property

    Public Property Created_By() As String
        Get
            Return strCreatedBy
        End Get
        Set(ByVal Value As String)
            strCreatedBy = Value
        End Set
    End Property

    Public Property Modified_By() As String
        Get
            Return strModifiedBy
        End Get
        Set(ByVal Value As String)
            strModifiedBy = Value
        End Set
    End Property

    Public Property Created_Date() As Date
        Get
            Return dtCreatedDate
        End Get
        Set(ByVal Value As Date)
            dtCreatedDate = Value
        End Set
    End Property

    Public Property Modified_Date() As Date
        Get
            Return dtModifiedDate
        End Get
        Set(ByVal Value As Date)
            dtModifiedDate = Value
        End Set
    End Property


    Public Sub selectAllWorkOrders()

        Dim dbCon As New DBAccess

        'Get all the Work Order information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_work_orders"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub selectAllWorkOrdersByUser()

        Dim dbCon As New DBAccess

        'Get all the Work Order By User information from the database
        DS_Data.SelectParameters.Clear()
        DS_Data.SelectCommand = "dbo.sp_get_all_work_orders_by_user"
        DS_Data.SelectParameters.Add("User_Id", strBy)
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub selectAllWorkOrderTemplates()

        Dim dbCon As New DBAccess

        'Get all the Schedule Work Order Templates information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_work_order_templates"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub selectAllScheduleWorkOrderTemplates()

        Dim dbCon As New DBAccess

        'Get all the Schedule Work Order Templates information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_schedule_work_order_templates"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub selectAllScheduledWorkOrderTemplates()

        Dim dbCon As New DBAccess

        'Get all the Schedule Work Order Templates information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_scheduled_work_order_templates"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub selectAllScheduledWorkOrderTemplatesByUser()

        Dim dbCon As New DBAccess

        'Get all the Schedule Work Order Templates information from the database

        DS_Data.SelectParameters.Clear()
        DS_Data.SelectCommand = "dbo.sp_get_all_scheduled_work_order_templates_by_user"
        DS_Data.SelectParameters.Add("User_Id", strBy)
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub selectAllWorkOrderTemplatesNotYetApproved()

        Dim dbCon As New DBAccess

        'Get all the Schedule Work Order Templates information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_work_order_templates_not_yet_approved"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub executeSelectWorkOrder()

        If Not IsDBNull(strWorkOrderId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the user information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_work_order", _
                         New SqlParameter("@work_order_id", strWorkOrderId))

            If dbRs.Read Then

                If Not IsDBNull(dbRs("Work_order_number")) Then
                    strWorkOrderNumber = dbRs("Work_order_number")
                End If

                If Not IsDBNull(dbRs("Purchase_order_number")) Then
                    strPurchaseOrderNumber = dbRs("Purchase_order_number")
                End If

                If Not IsDBNull(dbRs("Purchase_order_date")) Then
                    dtPurchaseOrderDate = dbRs("Purchase_order_date")
                End If

                If Not IsDBNull(dbRs("Requested_start_date")) Then
                    strRequestedStartDate = dbRs("Requested_start_date")
                End If

                If Not IsDBNull(dbRs("Template")) Then
                    strTemplate = dbRs("Template")
                End If

                If Not IsDBNull(dbRs("Fabrication")) Then
                    strFabrication = dbRs("Fabrication")
                End If

                If Not IsDBNull(dbRs("Installation")) Then
                    strInstallation = dbRs("Installation")
                End If

                If Not IsDBNull(dbRs("Repair")) Then
                    strRepair = dbRs("Repair")
                End If

                If Not IsDBNull(dbRs("Quote_no")) Then
                    strQuoteNo = dbRs("Quote_no")
                End If

                If Not IsDBNull(dbRs("Quote_detail_no")) Then
                    strQuoteDetailNo = dbRs("Quote_detail_no")
                End If

                If Not IsDBNull(dbRs("Quote_Name")) Then
                    strQuoteName = dbRs("Quote_Name")
                End If

                If Not IsDBNull(dbRs("Quote_Description")) Then
                    strQuoteDescription = dbRs("Quote_Description")
                End If

                If Not IsDBNull(dbRs("Address1")) Then
                    strAddress1 = dbRs("Address1")
                End If

                If Not IsDBNull(dbRs("Address2")) Then
                    strAddress2 = dbRs("Address2")
                End If

                If Not IsDBNull(dbRs("City")) Then
                    strCity = dbRs("City")
                End If

                If Not IsDBNull(dbRs("State_Id")) Then
                    intStateId = dbRs("State_Id")
                End If
                If Not IsDBNull(dbRs("State_Name")) Then
                    strStateName = dbRs("State_Name")
                End If
                If Not IsDBNull(dbRs("Country_Id")) Then
                    intCountryId = dbRs("Country_Id")
                End If
                If Not IsDBNull(dbRs("Country_Name")) Then
                    strCountryName = dbRs("Country_Name")
                End If
                If Not IsDBNull(dbRs("Zip")) Then
                    strZip = dbRs("Zip")
                End If
                If Not IsDBNull(dbRs("Phone")) Then
                    strPhone = dbRs("Phone")
                End If
                If Not IsDBNull(dbRs("Mobile")) Then
                    strMobile = dbRs("Mobile")
                End If
                If Not IsDBNull(dbRs("Fax")) Then
                    strFax = dbRs("Fax")
                End If
                If Not IsDBNull(dbRs("Email")) Then
                    strEmail = dbRs("Email")
                End If

                If Not IsDBNull(dbRs("Floor")) Then
                    strFloor = dbRs("Floor")
                End If

                If Not IsDBNull(dbRs("Template_type_id")) Then
                    intTemplateTypeId = dbRs("Template_type_id")
                End If
                If Not IsDBNull(dbRs("Template_type_description")) Then
                    strTemplateTypeDescription = dbRs("Template_type_description")
                End If
                If Not IsDBNull(dbRs("Construction_type_id")) Then
                    intConstructionTypeId = dbRs("Construction_type_id")
                End If
                If Not IsDBNull(dbRs("Construction_type_description")) Then
                    strConstructionTypeDescription = dbRs("Construction_type_description")
                End If

                If Not IsDBNull(dbRs("Sink_type_id")) Then
                    intSinkTypeId = dbRs("Sink_type_id")
                End If

                If Not IsDBNull(dbRs("Sink_type_description")) Then
                    strSinkTypeDescrption = dbRs("Sink_type_description")
                End If

                If Not IsDBNull(dbRs("Sink_status_id")) Then
                    intSinkStatusId = dbRs("Sink_status_id")
                End If

                If Not IsDBNull(dbRs("Sink_status_description")) Then
                    strSinkStatusDescription = dbRs("Sink_status_description")
                End If

                If Not IsDBNull(dbRs("No_of_sink")) Then
                    intNoofSink = dbRs("No_of_sink")
                End If

                If Not IsDBNull(dbRs("Back_splash")) Then
                    strBackSplash = dbRs("Back_splash")
                End If

                If Not IsDBNull(dbRs("Back_splash_details")) Then
                    strBackSplashDetails = dbRs("Back_splash_details")
                End If

                If Not IsDBNull(dbRs("Mill_down")) Then
                    strMillDown = dbRs("Mill_down")
                End If

                If Not IsDBNull(dbRs("Mill_down_details")) Then
                    strMillDownDetails = dbRs("Mill_down_details")
                End If

                If Not IsDBNull(dbRs("Stove_type_id")) Then
                    intStoveTypeId = dbRs("Stove_type_id")
                End If

                If Not IsDBNull(dbRs("Stove_type_description")) Then
                    strStoveTypeDescrption = dbRs("Stove_type_description")
                End If

                If Not IsDBNull(dbRs("Faucet_type_id")) Then
                    intFaucetTypeId = dbRs("Faucet_type_id")
                End If

                If Not IsDBNull(dbRs("Faucet_type_description")) Then
                    strFaucetTypeDescrption = dbRs("Faucet_type_description")
                End If

                If Not IsDBNull(dbRs("Faucet_status_id")) Then
                    intFaucetStatusId = dbRs("Faucet_status_id")
                End If

                If Not IsDBNull(dbRs("Faucet_status_description")) Then
                    strFaucetStatusDescription = dbRs("Faucet_status_description")
                End If

                If Not IsDBNull(dbRs("Edge_type_id")) Then
                    intEdgeTypeId = dbRs("Edge_type_id")
                End If

                If Not IsDBNull(dbRs("Edge_type_description")) Then
                    strEdgeTypeDescription = dbRs("Edge_type_description")
                End If

                If Not IsDBNull(dbRs("Edge_type_file")) Then
                    strEdgeTypeFile = dbRs("Edge_type_file")
                End If

                If Not IsDBNull(dbRs("Edge_type_details")) Then
                    strEdgeTypeDetails = dbRs("Edge_type_details")
                End If

                If Not IsDBNull(dbRs("Cutouts")) Then
                    strCutouts = dbRs("Cutouts")
                End If

                If Not IsDBNull(dbRs("Cutouts_quantity")) Then
                    intCutoutsQuantity = dbRs("Cutouts_quantity")
                End If

                If Not IsDBNull(dbRs("Material_id")) Then
                    strMaterialId = dbRs("Material_id")
                End If

                If Not IsDBNull(dbRs("Material_name")) Then
                    strMaterialName = dbRs("Material_name")
                End If

                If Not IsDBNull(dbRs("Thickness_id")) Then
                    intThicknessId = dbRs("Thickness_id")
                End If

                If Not IsDBNull(dbRs("Thickness_description")) Then
                    strThicknessDescription = dbRs("Thickness_description")
                End If

                If Not IsDBNull(dbRs("Top_removal")) Then
                    strTopRemoval = dbRs("Top_removal")
                End If

                If Not IsDBNull(dbRs("Comments")) Then
                    strComments = dbRs("Comments")
                End If

                If Not IsDBNull(dbRs("Work_order_comments")) Then
                    strWorkOrderComments = dbRs("Work_order_comments")
                End If

                If Not IsDBNull(dbRs("Kitchen_island")) Then
                    strKitchenIsland = dbRs("Kitchen_island")
                End If

                If Not IsDBNull(dbRs("Cabinets")) Then
                    strCabinets = dbRs("Cabinets")
                End If

                If Not IsDBNull(dbRs("Created_by")) Then
                    strCreatedBy = dbRs("Created_by")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                If Not IsDBNull(dbRs("Created_date")) Then
                    dtCreatedDate = dbRs("Created_date")
                End If

                If Not IsDBNull(dbRs("Modified_date")) Then
                    dtModifiedDate = dbRs("Modified_date")
                End If

                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 'Id is Nothing
            strErr = "Work Order Id is Nothing"

        End If

    End Sub 'executeSelectWorkOrder()

    Public Sub executeSelectWorkOrderTemplate()

        If Not IsDBNull(strWorkOrderId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the Get Work Order Template information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_work_order_template", _
                         New SqlParameter("@work_order_id", strWorkOrderId))

            If dbRs.Read Then

                If Not IsDBNull(dbRs("Template_date")) Then
                    dtTemplateDate = dbRs("Template_date")
                End If

                If Not IsDBNull(dbRs("Template_by_id")) Then
                    strTemplateById = dbRs("Template_by_id")
                End If

                If Not IsDBNull(dbRs("Template_by")) Then
                    strTemplateBy = dbRs("Template_by")
                End If

                If Not IsDBNull(dbRs("Time_slot_id")) Then
                    intTimeSlotId = dbRs("Time_slot_id")
                End If

                If Not IsDBNull(dbRs("Time_slot_description")) Then
                    strTimeSlotDescription = dbRs("Time_slot_description")
                End If

                If Not IsDBNull(dbRs("Estimate_sqft")) Then
                    intEstimateSQFT = dbRs("Estimate_sqft")
                Else
                    intEstimateSQFT = ""
                End If

                If Not IsDBNull(dbRs("Actual_sqft")) Then
                    intActualSQFT = dbRs("Actual_sqft")
                Else
                    intActualSQFT = ""
                End If

                If Not IsDBNull(dbRs("Verified_by_id")) Then
                    strVerifiedById = dbRs("Verified_by_id")
                End If

                If Not IsDBNull(dbRs("Verified_by")) Then
                    strVerifiedBy = dbRs("Verified_by")
                End If

                If Not IsDBNull(dbRs("Template_completed")) Then
                    strTemplateCompleted = dbRs("Template_completed")
                End If

                If Not IsDBNull(dbRs("Template_accepted")) Then
                    strTemplateAccepted = dbRs("Template_accepted")
                End If

                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 'Id is Nothing
            strErr = "Work Order Id is Nothing"

        End If

    End Sub 'executeSelectWorkOrderTemplate()

    Public Sub executeCreateWorkOrder()


        Dim dbCon As New DBAccess
        Dim T_id As String

        'Create New Work Order to the database      

        T_id = dbCon.RunSPReturnId("dbo.sp_create_work_order_wiz", _
                         New SqlParameter("@Quote_detail_id", strQuoteDetailId), _
                         New SqlParameter("@Purchase_order_number", strPurchaseOrderNumber), _
                         New SqlParameter("@Purchase_order_date", dtPurchaseOrderDate), _
                         New SqlParameter("@Requested_start_date", strRequestedStartDate), _
                         New SqlParameter("@Work_order_comments", strWorkOrderComments), _
                         New SqlParameter("@Floor", strFloor), _
                         New SqlParameter("@Template_type_id", intTemplateTypeId), _
                         New SqlParameter("@Construction_type_id", intConstructionTypeId), _
                         New SqlParameter("@Sink_type_id", intSinkTypeId), _
                         New SqlParameter("@No_of_Sink", intNoofSink), _
                         New SqlParameter("@Back_splash", strBackSplash), _
                         New SqlParameter("@Back_splash_details", strBackSplashDetails), _
                         New SqlParameter("@Mill_down", strMillDown), _
                         New SqlParameter("@Mill_down_details", strMillDownDetails), _
                         New SqlParameter("@Stove_type_id", intStoveTypeId), _
                         New SqlParameter("@Faucet_type_id", intFaucetTypeId), _
                         New SqlParameter("@Edge_type_id", intEdgeTypeId), _
                         New SqlParameter("@Edge_type_details", strEdgeTypeDetails), _
                         New SqlParameter("@Cutouts", strCutouts), _
                         New SqlParameter("@Cutouts_quantity", intCutoutsQuantity), _
                         New SqlParameter("@Material_id", strMaterialId), _
                         New SqlParameter("@Thickness_id", intThicknessId), _
                         New SqlParameter("@Top_removal", strTopRemoval), _
                         New SqlParameter("@Sink_status_id", intSinkStatusId), _
                         New SqlParameter("@Faucet_status_id", intFaucetStatusId), _
                         New SqlParameter("@Kitchen_island", strKitchenIsland), _
                         New SqlParameter("@Cabinets", strCabinets), _
                         New SqlParameter("@created_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Create New Work Order Failed
            strErr = "Create New Work Order Failed"

        Else

            strQuoteDetailId = T_id
            intErr = 0 'New Work Order Created Successfully
            strErr = "New Work Order Created Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeCreateWorkOrder()


    Public Sub executeUpdateWorkOrder()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Save Quote Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_work_order_wiz", _
                         New SqlParameter("@Work_order_id", strWorkOrderId), _
                         New SqlParameter("@Floor", strFloor), _
                         New SqlParameter("@Template_type_id", intTemplateTypeId), _
                         New SqlParameter("@Construction_type_id", intConstructionTypeId), _
                         New SqlParameter("@Sink_type_id", intSinkTypeId), _
                         New SqlParameter("@No_of_Sink", intNoofSink), _
                         New SqlParameter("@Back_splash", strBackSplash), _
                         New SqlParameter("@Back_splash_details", strBackSplashDetails), _
                         New SqlParameter("@Mill_down", strMillDown), _
                         New SqlParameter("@Mill_down_details", strMillDownDetails), _
                         New SqlParameter("@Stove_type_id", intStoveTypeId), _
                         New SqlParameter("@Faucet_type_id", intFaucetTypeId), _
                         New SqlParameter("@Edge_type_id", intEdgeTypeId), _
                         New SqlParameter("@Edge_type_details", strEdgeTypeDetails), _
                         New SqlParameter("@Cutouts", strCutouts), _
                         New SqlParameter("@Cutouts_quantity", intCutoutsQuantity), _
                         New SqlParameter("@Material_id", strMaterialId), _
                         New SqlParameter("@Thickness_id", intThicknessId), _
                         New SqlParameter("@Top_removal", strTopRemoval), _
                         New SqlParameter("@Sink_status_id", intSinkStatusId), _
                         New SqlParameter("@Faucet_status_id", intFaucetStatusId), _
                         New SqlParameter("@Kitchen_island", strKitchenIsland), _
                         New SqlParameter("@Cabinets", strCabinets), _
                         New SqlParameter("@Template", strTemplate), _
                         New SqlParameter("@Fabrication", strFabrication), _
                         New SqlParameter("@Installation", strInstallation), _
                         New SqlParameter("@Repair", strRepair), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = -1 Then

            intErr = -1 'Update Work Order Failed
            strErr = "Update  Work Order Failed"

        Else

            intErr = 0 ' Work Order Information Saved Successfully
            strErr = "Work Order Information Saved Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateWorkOrder()



    Public Sub executeDeleteWorkOrder()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Delete Quote Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_delete_work_order_wiz", _
                         New SqlParameter("@Work_order_id", strWorkOrderId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Delete Work Order Failed
            strErr = "Delete Work Order Failed"

        Else

            intErr = 0 ' Work Order Information Deleted Successfully
            strErr = "Work Order Information Deleted Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeleteWorkOrder()




    Public Sub executeScheduleTemplate()


        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Schedule a New Template 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_schedule_template_wiz", _
                         New SqlParameter("@Work_order_id", strWorkOrderId), _
                         New SqlParameter("@Template_date", dtTemplateDate), _
                         New SqlParameter("@Time_slot_id", intTimeSlotId), _
                         New SqlParameter("@Template_by", strTemplateBy), _
                         New SqlParameter("@Estimate_SQFT", intEstimateSQFT), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = -1 Then

            intErr = -1 'Template Scheduling Failed
            strErr = "Template Scheduling Failed"

        Else

            intErr = 0 'New Template Scheduled Successfully
            strErr = "New Template Scheduled Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeScheduleTemplate()

    Public Sub executeUpdateTemplate()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Schedule a New Template 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_template_wiz", _
                         New SqlParameter("@Work_order_id", strWorkOrderId), _
                         New SqlParameter("@Template_date", dtTemplateDate), _
                         New SqlParameter("@Time_slot_id", intTimeSlotId), _
                         New SqlParameter("@Template_by", strTemplateBy), _
                         New SqlParameter("@Estimate_SQFT", intEstimateSQFT), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = -1 Then

            intErr = -1 'Template Update Failed
            strErr = "Template Update Failed"

        Else

            intErr = 0 'Template Updated Successfully
            strErr = "Template Updated Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateTemplate()

    Public Sub executeUpdateTemplateCompleted()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Schedule a New Template 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_template_completed_wiz", _
                         New SqlParameter("@Work_order_id", strWorkOrderId), _
                         New SqlParameter("@Actual_SQFT", intActualSQFT), _
                         New SqlParameter("@Template_completed", strTemplateCompleted), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = -1 Then

            intErr = -1 'Template Update Failed
            strErr = "Template Update Failed"

        Else

            intErr = 0 'Template Updated Successfully
            strErr = "Template Updated Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateTemplateCompleted()


    Public Sub executeUpdateTemplateAccepted()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Schedule a New Template 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_template_accepted_wiz", _
                         New SqlParameter("@Work_order_id", strWorkOrderId), _
                         New SqlParameter("@Template_accepted", strTemplateAccepted), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = -1 Then

            intErr = -1 'Template Update Failed
            strErr = "Template Update Failed"

        Else

            intErr = 0 'Template Updated Successfully
            strErr = "Template Updated Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateTemplateAccepted()
End Class
