﻿

'Component Name: PAL_Security
'Description: Used to Create, Update, View and Delete PAL Security Information
'Author:  Srinivasan Subbanchattiar 
'Created By: Srinivasan Subbanchattiar 
'Created Date: 07/06/2011 
'Modified By: Srinivasan Subbanchattiar 
'Modified Date: 07/06/2011 
'Version: 1.0

Imports System.Web
Imports System.Data
Imports System.Data.SqlClient


Public Class PAL_Security

    Protected intErr As Integer
    Protected strErr As String
    Protected strBy As String
    Protected strSortBy As String
    Protected strSortOrder As String

    Protected strIpAddress As String
    Protected strBrowserType As String
    Protected strBrowserName As String
    Protected strBrowserVersion As String
    Protected strPlatform As String
    Protected strReferrerUrl As String
    Protected strLogData As String

    Protected strUserId As String
    Protected strUserName As String
    Protected strPassword As String

    Protected intRoleId As Integer
    Protected strRoleName As String

    Protected intPageId As Integer
    Protected intParentPageId As Integer
    Protected strParentPageTitle As String
    Protected strPageTitle As String
    Protected strNavigateUrl As String
    Protected strPageDescription As String

    Protected strFirstName As String
    Protected strLastName As String

    Protected strActiveUser As String

    Protected strAddressId As String
    Protected strAddress1 As String
    Protected strAddress2 As String
    Protected strCity As String

    Protected intStateId As Integer
    Protected strStateName As String

    Protected intCountryId As Integer
    Protected strCountryName As String
    Protected strZip As String
    Protected strPhone As String
    Protected strMobile As String
    Protected strFax As String
    Protected strEmail As String

    Protected blnView As Boolean
    Protected blnModify As Boolean
    Protected blnDelete As Boolean

    Protected dtLastLoginDate As Date

    Protected gvData As GridView
    Protected dsData As SqlDataSource

    'for view purpose only
    Protected strCreatedBy As String
    Protected dtCreatedDate As Date
    Protected strModifiedBy As String
    Protected dtModifiedDate As Date


    Public Sub New()

        Clear()

    End Sub


    Public Sub Clear()

        intErr = Nothing
        strErr = Nothing
        strBy = Nothing
        strSortBy = Nothing
        strSortOrder = Nothing

        blnView = False
        blnModify = False
        blnDelete = False

        strIpAddress = Nothing
        strBrowserType = Nothing
        strBrowserName = Nothing
        strBrowserVersion = Nothing
        strPlatform = Nothing
        strReferrerUrl = Nothing
        strLogData = Nothing

        strUserId = Nothing
        strUserName = Nothing
        strPassword = Nothing

        intRoleId = Nothing
        strRoleName = Nothing

        intPageId = Nothing
        intParentPageId = Nothing
        strParentPageTitle = Nothing
        strPageTitle = Nothing
        strNavigateUrl = Nothing
        strPageDescription = Nothing

        strFirstName = Nothing
        strLastName = Nothing

        strActiveUser = Nothing

        strAddressId = Nothing
        strAddress1 = Nothing
        strAddress2 = Nothing
        strCity = Nothing

        intStateId = Nothing
        strStateName = Nothing

        intCountryId = Nothing
        strCountryName = Nothing
        strZip = Nothing
        strPhone = Nothing
        strMobile = Nothing
        strFax = Nothing
        strEmail = Nothing
        dtLastLoginDate = Nothing

        gvData = Nothing
        dsData = Nothing

        strCreatedBy = Nothing
        dtCreatedDate = Nothing
        strModifiedBy = Nothing
        dtModifiedDate = Nothing


    End Sub

    Public Property Error_Id() As Integer
        Get
            Return intErr
        End Get
        Set(ByVal Value As Integer)
            intErr = Value
        End Set
    End Property

    Public Property Error_Message() As String
        Get
            Return strErr
        End Get
        Set(ByVal Value As String)
            strErr = Value
        End Set
    End Property

    Public Property Allow_view() As Boolean
        Get
            Return blnView
        End Get
        Set(ByVal Value As Boolean)
            blnView = Value
        End Set
    End Property

    Public Property Allow_modify() As Boolean
        Get
            Return blnModify
        End Get
        Set(ByVal Value As Boolean)
            blnModify = Value
        End Set
    End Property

    Public Property Allow_delete() As Boolean
        Get
            Return blnDelete
        End Get
        Set(ByVal Value As Boolean)
            blnDelete = Value
        End Set
    End Property

    Public Property By() As String
        Get
            Return strBy
        End Get
        Set(ByVal Value As String)
            strBy = Value
        End Set
    End Property

    Public Property Sort_By() As String
        Get
            Return strSortBy
        End Get
        Set(ByVal Value As String)
            strSortBy = Value
        End Set
    End Property

    Public Property Sort_Order() As String
        Get
            Return strSortOrder
        End Get
        Set(ByVal Value As String)
            strSortOrder = Value
        End Set
    End Property


    Public Property Ip_Address() As String
        Get
            Return strIpAddress
        End Get
        Set(ByVal Value As String)
            strIpAddress = Value
        End Set
    End Property

    Public Property Browser_Type() As String
        Get
            Return strBrowserType
        End Get
        Set(ByVal Value As String)
            strBrowserType = Value
        End Set
    End Property

    Public Property Browser_Name() As String
        Get
            Return strBrowserName
        End Get
        Set(ByVal Value As String)
            strBrowserName = Value
        End Set
    End Property

    Public Property Browser_Version() As String
        Get
            Return strBrowserVersion
        End Get
        Set(ByVal Value As String)
            strBrowserVersion = Value
        End Set
    End Property

    Public Property Platform() As String
        Get
            Return strPlatform
        End Get
        Set(ByVal Value As String)
            strPlatform = Value
        End Set
    End Property

    Public Property Referrer_Url() As String
        Get
            Return strReferrerUrl
        End Get
        Set(ByVal Value As String)
            strReferrerUrl = Value
        End Set
    End Property

    Public Property Log_Data() As String
        Get
            Return strLogData
        End Get
        Set(ByVal Value As String)
            strLogData = Value
        End Set
    End Property

    Public Property User_Id() As String
        Get
            Return strUserId
        End Get
        Set(ByVal Value As String)
            strUserId = Value
        End Set

    End Property
    Public Property User_Name() As String
        Get
            Return strUserName
        End Get
        Set(ByVal Value As String)
            strUserName = Value
        End Set
    End Property

    Public Property Password() As String
        Get
            Return strPassword
        End Get
        Set(ByVal Value As String)
            strPassword = Value
        End Set
    End Property

    Public Property First_Name() As String
        Get
            Return strFirstName
        End Get
        Set(ByVal Value As String)
            strFirstName = Value
        End Set
    End Property

    Public Property Last_Name() As String
        Get
            Return strLastName
        End Get
        Set(ByVal Value As String)
            strLastName = Value
        End Set
    End Property

    Public Property Active_User As String
        Get
            Return strActiveUser
        End Get
        Set(ByVal Value As String)
            strActiveUser = Value
        End Set
    End Property

    Public Property AddressId() As String
        Get
            Return strAddressId
        End Get
        Set(ByVal Value As String)
            strAddressId = Value
        End Set
    End Property

    Public Property Address1() As String
        Get
            Return strAddress1
        End Get
        Set(ByVal Value As String)
            strAddress1 = Value
        End Set
    End Property

    Public Property Address2() As String
        Get
            Return strAddress2
        End Get
        Set(ByVal Value As String)
            strAddress2 = Value
        End Set
    End Property

    Public Property City() As String
        Get
            Return strCity
        End Get
        Set(ByVal Value As String)
            strCity = Value
        End Set
    End Property

    Public Property State_Id() As Integer
        Get
            Return intStateId
        End Get
        Set(ByVal Value As Integer)
            intStateId = Value
        End Set
    End Property

    Public Property State_Name() As String
        Get
            Return strStateName
        End Get
        Set(ByVal Value As String)
            strStateName = Value
        End Set
    End Property

    Public Property Zip() As String
        Get
            Return strZip
        End Get
        Set(ByVal Value As String)
            strZip = Value
        End Set
    End Property

    Public Property Role_Id() As Integer
        Get
            Return intRoleId
        End Get
        Set(ByVal Value As Integer)
            intRoleId = Value
        End Set
    End Property

    Public Property Role_Name() As String
        Get
            Return strRoleName
        End Get
        Set(ByVal Value As String)
            strRoleName = Value
        End Set
    End Property

    Public Property Page_Id() As Integer
        Get
            Return intPageId
        End Get
        Set(ByVal Value As Integer)
            intPageId = Value
        End Set
    End Property

    Public Property Parent_Page_Id() As Integer
        Get
            Return intParentPageId
        End Get
        Set(ByVal Value As Integer)
            intParentPageId = Value
        End Set
    End Property

    Public Property Parent_Page_Title() As String
        Get
            Return strParentPageTitle
        End Get
        Set(ByVal Value As String)
            strParentPageTitle = Value
        End Set
    End Property

    Public Property Page_Title() As String
        Get
            Return strPageTitle
        End Get
        Set(ByVal Value As String)
            strPageTitle = Value
        End Set
    End Property

    Public Property Navigate_Url() As String
        Get
            Return strNavigateUrl
        End Get
        Set(ByVal Value As String)
            strNavigateUrl = Value
        End Set
    End Property

    Public Property Page_Description() As String
        Get
            Return strPageDescription
        End Get
        Set(ByVal Value As String)
            strPageDescription = Value
        End Set
    End Property

    Public Property Country_Id() As Integer
        Get
            Return intCountryId
        End Get
        Set(ByVal Value As Integer)
            intCountryId = Value
        End Set
    End Property

    Public Property Country_Name() As String
        Get
            Return strCountryName
        End Get
        Set(ByVal Value As String)
            strCountryName = Value
        End Set
    End Property


    Public Property Phone() As String
        Get
            Return strPhone
        End Get
        Set(ByVal Value As String)
            strPhone = Value
        End Set
    End Property

    Public Property Mobile() As String
        Get
            Return strMobile
        End Get
        Set(ByVal Value As String)
            strMobile = Value
        End Set
    End Property

    Public Property Fax() As String
        Get
            Return strFax
        End Get
        Set(ByVal Value As String)
            strFax = Value
        End Set
    End Property

    Public Property Email() As String
        Get
            Return strEmail
        End Get
        Set(ByVal Value As String)
            strEmail = Value
        End Set
    End Property

    Public Property DS_Data() As SqlDataSource
        Get
            Return dsData
        End Get
        Set(ByVal Value As SqlDataSource)
            dsData = Value
        End Set
    End Property

    Public Property GV_Data() As GridView
        Get
            Return gvData
        End Get
        Set(ByVal Value As GridView)
            gvData = Value
        End Set
    End Property


    Public Property Created_By() As String
        Get
            Return strCreatedBy
        End Get
        Set(ByVal Value As String)
            strCreatedBy = Value
        End Set
    End Property

    Public Property Modified_By() As String
        Get
            Return strModifiedBy
        End Get
        Set(ByVal Value As String)
            strModifiedBy = Value
        End Set
    End Property

    Public Property Last_Login_Date() As Date
        Get
            Return dtLastLoginDate
        End Get
        Set(ByVal Value As Date)
            dtLastLoginDate = Value
        End Set
    End Property


    Public Property Created_Date() As Date
        Get
            Return dtCreatedDate
        End Get
        Set(ByVal Value As Date)
            dtCreatedDate = Value
        End Set
    End Property

    Public Property Modified_Date() As Date
        Get
            Return dtModifiedDate
        End Get
        Set(ByVal Value As Date)
            dtModifiedDate = Value
        End Set
    End Property

    Public Sub Browser(ByVal Request As HttpRequest)

        strIpAddress = Request.UserHostAddress
        strBrowserType = Request.Browser.Type
        strBrowserName = Request.Browser.Browser
        strBrowserVersion = Request.Browser.Version
        strPlatform = Request.Browser.Platform

        If Not IsNothing(Request.UrlReferrer) Then
            strReferrerUrl = Request.UrlReferrer.ToString()
        End If

    End Sub

    Public Sub executeValidateUser()

        If Not (IsDBNull(strUserName) And IsDBNull(strPassword)) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the user information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_validate_user", _
                         New SqlParameter("@user_name", strUserName),
                         New SqlParameter("@password", strPassword))

            If dbRs.Read Then

                If Not IsDBNull(dbRs("User_Id")) Then
                    strUserId = dbRs("User_Id")
                End If
               

                If Not IsDBNull(dbRs("First_Name")) Then
                    strFirstName = dbRs("First_Name")
                End If

                If Not IsDBNull(dbRs("Last_Name")) Then
                    strLastName = dbRs("Last_Name")
                End If

                If Not IsDBNull(dbRs("Active_User")) Then
                    strActiveUser = dbRs("Active_User")
                End If

                If Not IsDBNull(dbRs("Role_Id")) Then
                    intRoleId = dbRs("Role_Id")
                End If

                If Not IsDBNull(dbRs("Role_Name")) Then
                    strRoleName = dbRs("Role_Name")
                End If

                If Not IsDBNull(dbRs("Last_Login_Date")) Then
                    dtLastLoginDate = dbRs("Last_Login_Date")
                End If

                If Not IsDBNull(dbRs("Address_Id")) Then
                    strAddressId = dbRs("Address_Id")
                End If

                If Not IsDBNull(dbRs("Address1")) Then
                    strAddress1 = dbRs("Address1")
                End If

                If Not IsDBNull(dbRs("Address2")) Then
                    strAddress2 = dbRs("Address2")
                End If

                If Not IsDBNull(dbRs("City")) Then
                    strCity = dbRs("City")
                End If

                If Not IsDBNull(dbRs("State_Id")) Then
                    intStateId = dbRs("State_Id")
                End If
                If Not IsDBNull(dbRs("State_Name")) Then
                    strStateName = dbRs("State_Name")
                End If
                If Not IsDBNull(dbRs("Country_Id")) Then
                    intCountryId = dbRs("Country_Id")
                End If
                If Not IsDBNull(dbRs("Country_Name")) Then
                    strCountryName = dbRs("Country_Name")
                End If
                If Not IsDBNull(dbRs("Zip")) Then
                    strZip = dbRs("Zip")
                End If
                If Not IsDBNull(dbRs("Phone")) Then
                    strPhone = dbRs("Phone")
                End If
                If Not IsDBNull(dbRs("Mobile")) Then
                    strMobile = dbRs("Mobile")
                End If
                If Not IsDBNull(dbRs("Fax")) Then
                    strFax = dbRs("Fax")
                End If
                If Not IsDBNull(dbRs("Email")) Then
                    strEmail = dbRs("Email")
                End If

                If Not IsDBNull(dbRs("Created_by")) Then
                    strCreatedBy = dbRs("Created_by")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                If Not IsDBNull(dbRs("Created_date")) Then
                    dtCreatedDate = dbRs("Created_date")
                End If

                If Not IsDBNull(dbRs("Modified_date")) Then
                    dtModifiedDate = dbRs("Modified_date")
                End If

                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 ' is Nothing
            strErr = "User Name and Password is Nothing"

        End If

    End Sub 'executeValidateUser()


    Public Function Check_Page(ByVal Role_id As Integer, ByVal T_Request As HttpRequest) As Integer

        Dim dbCon As New DBAccess

        Dim Navigate_url As String

        Navigate_url = Get_Page(T_Request)

        Check_Page = dbCon.RunSPReturnInteger("dbo.sp_check_url", _
                                          New SqlParameter("@role_id", Role_id),
                                          New SqlParameter("@navigate_url", Navigate_url))

        dbCon = Nothing

    End Function

    Public Function Get_Page(ByVal T_Request As HttpRequest) As String

        Dim Navigate_url As String = T_Request.Url.ToString()

        Navigate_url = Navigate_url.Substring(0, Navigate_url.IndexOf(".aspx") + 5)
        Navigate_url = Navigate_url.Remove(0, Navigate_url.LastIndexOf("/") + 1)

        Get_Page = Navigate_url

    End Function


    Public Sub executeClearUserLog()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        T_id = dbCon.RunSPReturnInteger("dbo.sp_clear_user_log")

        dbCon = Nothing

    End Sub

    Public Sub executeCreateUserLog()

        Dim dbCon As New DBAccess
        Dim T_Browser As String
        Dim T_id As Integer

        T_Browser = ""
        T_Browser = T_Browser & " IP:" & strIpAddress
        T_Browser = T_Browser & " Browser Type:" & strBrowserType
        T_Browser = T_Browser & " Browser Name:" & strBrowserName
        T_Browser = T_Browser & " Browser Version:" & strBrowserVersion
        T_Browser = T_Browser & " Platform:" & strPlatform
        T_Browser = T_Browser & " ReferrerUrl:" & strReferrerUrl

        T_id = dbCon.RunSPReturnInteger("dbo.sp_create_user_log", _
                                          New SqlParameter("@IP_address", strIpAddress),
                                          New SqlParameter("@Browser", T_Browser),
                                          New SqlParameter("@Log_data", strLogData),
                                          New SqlParameter("@Log_by", strBy))

        dbCon = Nothing

    End Sub

    Public Sub executeSelectUserPermission()

        If Not (IsDBNull(intRoleId) And IsDBNull(strNavigateUrl)) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the user permission information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_user_permission", _
                                            New SqlParameter("@role_id", Role_Id),
                                            New SqlParameter("@navigate_url", strNavigateUrl))

            If dbRs.Read Then

                If Not IsDBNull(dbRs("Allow_view")) Then
                    blnView = dbRs("Allow_view")
                End If
                If Not IsDBNull(dbRs("Allow_modify")) Then
                    blnModify = dbRs("Allow_modify")
                End If

                If Not IsDBNull(dbRs("Allow_delete")) Then
                    blnDelete = dbRs("Allow_delete")
                End If

                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 ' is Nothing
            strErr = "RoleId or NavigateUrl is Nothing"

        End If

    End Sub 'executeSelectUserPermission()


    Public Sub executeSelectRole()

        If Not IsDBNull(intRoleId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the role information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_role", _
                                            New SqlParameter("@role_id", intRoleId))

            If dbRs.Read Then

                If Not IsDBNull(dbRs("Role_name")) Then
                    strRoleName = dbRs("Role_name")
                End If

                If Not IsDBNull(dbRs("Created_by")) Then
                    strCreatedBy = dbRs("Created_by")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                If Not IsDBNull(dbRs("Created_date")) Then
                    dtCreatedDate = dbRs("Created_date")
                End If

                If Not IsDBNull(dbRs("Modified_date")) Then
                    dtModifiedDate = dbRs("Modified_date")
                End If

                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 ' is Nothing
            strErr = "RoleId  is Nothing"

        End If

    End Sub 'executeSelectRole()

    Public Sub executeSelectPage()

        If Not IsDBNull(intPageId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the Page information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_page", _
                                            New SqlParameter("@page_id", intPageId))

            If dbRs.Read Then

                If Not IsDBNull(dbRs("Parent_page_id")) Then
                    intParentPageId = dbRs("Parent_page_id")
                End If

                If Not IsDBNull(dbRs("Parent_page_title")) Then
                    strParentPageTitle = dbRs("Parent_page_title")
                End If

                If Not IsDBNull(dbRs("Page_title")) Then
                    strPageTitle = dbRs("Page_title")
                End If

                If Not IsDBNull(dbRs("Navigate_url")) Then
                    strNavigateUrl = dbRs("Navigate_url")
                End If

                If Not IsDBNull(dbRs("Page_description")) Then
                    strPageDescription = dbRs("Page_description")
                End If

                If Not IsDBNull(dbRs("Created_by")) Then
                    strCreatedBy = dbRs("Created_by")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                If Not IsDBNull(dbRs("Created_date")) Then
                    dtCreatedDate = dbRs("Created_date")
                End If

                If Not IsDBNull(dbRs("Modified_date")) Then
                    dtModifiedDate = dbRs("Modified_date")
                End If

                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 'Page Id is Nothing
            strErr = "Page Id  is Nothing"

        End If

    End Sub 'executeSelectPage()

    Public Sub executeCreatePage()


        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Create Page Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_create_page_wiz", _
                         New SqlParameter("@parent_page_id", intParentPageId), _
                         New SqlParameter("@page_title", strPageTitle), _
                         New SqlParameter("@page_description", strPageDescription), _
                         New SqlParameter("@navigate_url", strNavigateUrl), _
                         New SqlParameter("@created_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Create Page Failed
            strErr = "Create Page Failed"

        Else

            intErr = 0 'New Page Information Created Successfully
            strErr = "New Page Information Created Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeCreatePage()

    Public Sub executeUpdatePage()


        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Save Page Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_page_wiz", _
                         New SqlParameter("@page_id", intPageId), _
                         New SqlParameter("@parent_page_id", intParentPageId), _
                         New SqlParameter("@page_title", strPageTitle), _
                         New SqlParameter("@page_description", strPageDescription), _
                         New SqlParameter("@navigate_url", strNavigateUrl), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Update Page Failed
            strErr = "Update Page Failed"

        Else

            intErr = 0 'Page Information Saved Successfully
            strErr = "Page Information Saved Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdatePage()

    Public Sub executeDeletePage()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Delete Page Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_delete_page_wiz", _
                         New SqlParameter("@page_id", intPageId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Delete Page Failed
            strErr = "Delete Page Failed"

        Else

            intErr = 0 'Page Information Deleted Successfully
            strErr = "Page Information Deleted Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeletePage()

    Public Sub executeSelectUser()

        If Not IsDBNull(strUserId) Then

            Dim dbCon As New DBAccess
            Dim dbRs As SqlDataReader

            'Get all the user information from the database

            dbRs = dbCon.RunSPReturnRS("dbo.sp_get_user_by_id", _
                         New SqlParameter("@user_id", strUserId))

            If dbRs.Read Then

                If Not IsDBNull(dbRs("User_name")) Then
                    strUserName = dbRs("user_name")
                End If
                If Not IsDBNull(dbRs("Passwd")) Then
                    strPassword = dbRs("Passwd")
                End If

                If Not IsDBNull(dbRs("First_Name")) Then
                    strFirstName = dbRs("First_Name")
                End If

                If Not IsDBNull(dbRs("Last_Name")) Then
                    strLastName = dbRs("Last_Name")
                End If

                If Not IsDBNull(dbRs("Active_User")) Then
                    strActiveUser = dbRs("Active_User")
                End If

                If Not IsDBNull(dbRs("Role_Id")) Then
                    intRoleId = dbRs("Role_Id")
                End If

                If Not IsDBNull(dbRs("Role_Name")) Then
                    strRoleName = dbRs("Role_Name")
                End If

                If Not IsDBNull(dbRs("Last_Login_Date")) Then
                    dtLastLoginDate = dbRs("Last_Login_Date")
                End If

                If Not IsDBNull(dbRs("Address_Id")) Then
                    strAddressId = dbRs("Address_Id")
                End If

                If Not IsDBNull(dbRs("Address1")) Then
                    strAddress1 = dbRs("Address1")
                End If

                If Not IsDBNull(dbRs("Address2")) Then
                    strAddress2 = dbRs("Address2")
                End If

                If Not IsDBNull(dbRs("City")) Then
                    strCity = dbRs("City")
                End If

                If Not IsDBNull(dbRs("State_Id")) Then
                    intStateId = dbRs("State_Id")
                End If
                If Not IsDBNull(dbRs("State_Name")) Then
                    strStateName = dbRs("State_Name")
                End If
                If Not IsDBNull(dbRs("Country_Id")) Then
                    intCountryId = dbRs("Country_Id")
                End If
                If Not IsDBNull(dbRs("Country_Name")) Then
                    strCountryName = dbRs("Country_Name")
                End If
                If Not IsDBNull(dbRs("Zip")) Then
                    strZip = dbRs("Zip")
                End If
                If Not IsDBNull(dbRs("Phone")) Then
                    strPhone = dbRs("Phone")
                End If
                If Not IsDBNull(dbRs("Mobile")) Then
                    strMobile = dbRs("Mobile")
                End If
                If Not IsDBNull(dbRs("Fax")) Then
                    strFax = dbRs("Fax")
                End If
                If Not IsDBNull(dbRs("Email")) Then
                    strEmail = dbRs("Email")
                End If

                If Not IsDBNull(dbRs("Created_by")) Then
                    strCreatedBy = dbRs("Created_by")
                End If

                If Not IsDBNull(dbRs("Modified_by")) Then
                    strModifiedBy = dbRs("Modified_by")
                End If

                If Not IsDBNull(dbRs("Created_date")) Then
                    dtCreatedDate = dbRs("Created_date")
                End If

                If Not IsDBNull(dbRs("Modified_date")) Then
                    dtModifiedDate = dbRs("Modified_date")
                End If

                intErr = 0 'Record found
                strErr = ""

            Else

                intErr = -1 'Record not found
                strErr = "Record Not Found"

            End If

            dbRs.Close()
            dbRs = Nothing
            dbCon = Nothing

        Else

            intErr = -2 'Id is Nothing
            strErr = "UserId is Nothing"

        End If

    End Sub 'executeSelectUser()


    Public Sub executeCreateUser()


        Dim dbCon As New DBAccess
        Dim T_User_id As String

        'Create New User to the database 

        T_User_id = dbCon.RunSPReturnId("dbo.sp_create_user_wiz", _
                         New SqlParameter("@first_name", strFirstName), _
                         New SqlParameter("@last_name", strLastName), _
                         New SqlParameter("@address1", strAddress1), _
                         New SqlParameter("@address2", strAddress2), _
                         New SqlParameter("@city", strCity), _
                         New SqlParameter("@state_id", intStateId), _
                         New SqlParameter("@zip", strZip), _
                         New SqlParameter("@country_id", intCountryId), _
                         New SqlParameter("@phone", strPhone), _
                         New SqlParameter("@mobile", strMobile), _
                         New SqlParameter("@fax", strFax), _
                         New SqlParameter("@email", strEmail), _
                         New SqlParameter("@user_name", strUserName), _
                         New SqlParameter("@password", strPassword), _
                         New SqlParameter("@role_id", intRoleId), _
                         New SqlParameter("@created_by", strBy))

        If T_User_id = "-1" Then

            intErr = -1 'Create New User Failed
            strErr = "Create New User Failed"

        Else

            intErr = 0 'New User Created Successfully
            strErr = "New User Created Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeCreateUser()

    Public Sub executeUpdateUser()


        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Save User Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_user_wiz", _
                         New SqlParameter("@user_id", strUserId), _
                         New SqlParameter("@first_name", strFirstName), _
                         New SqlParameter("@last_name", strLastName), _
                         New SqlParameter("@address1", strAddress1), _
                         New SqlParameter("@address2", strAddress2), _
                         New SqlParameter("@city", strCity), _
                         New SqlParameter("@state_id", intStateId), _
                         New SqlParameter("@zip", strZip), _
                         New SqlParameter("@country_id", intCountryId), _
                         New SqlParameter("@phone", strPhone), _
                         New SqlParameter("@mobile", strMobile), _
                         New SqlParameter("@fax", strFax), _
                         New SqlParameter("@email", strEmail), _
                         New SqlParameter("@user_name", strUserName), _
                         New SqlParameter("@password", strPassword), _
                         New SqlParameter("@active_user", strActiveUser), _
                         New SqlParameter("@role_id", intRoleId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Update User Failed
            strErr = "Update User Failed"

        Else

            intErr = 0 'User Information Saved Successfully
            strErr = "User Information Saved Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateUser()


    Public Sub executeChangeUserPassword()


        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Change User Password Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_change_user_password", _
                         New SqlParameter("@user_id", strUserId), _
                         New SqlParameter("@password", strPassword), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Change User Failed
            strErr = "Change User Failed"

        Else

            intErr = 0 'User Password Information Changed Successfully
            strErr = "User Password Information Changed Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeChangeUserPassword()

    Public Sub executeDeleteUser()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Delete User Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_delete_user_wiz", _
                         New SqlParameter("@user_id", strUserId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Delete User Failed
            strErr = "Delete User Failed"

        Else

            intErr = 0 'User Information Deleted Successfully
            strErr = "User Information Deleted Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeleteUser()

    Public Sub executeCreateRole()

        Dim dbCon As New DBAccess
        Dim T_id As Integer
        Dim T_Row As GridViewRow
        Dim T_Sort_index As Integer
        Dim T_chk_view As String
        Dim T_chk_modify As String
        Dim T_chk_delete As String

        'Create Role Information to the database 

        For Each T_Row In gvData.Rows

            If CType(T_Row.FindControl("chk_add"), CheckBox).Checked Then

                intPageId = gvData.DataKeys(T_Row.RowIndex).Value


                If CType(T_Row.FindControl("txt_sort_index"), TextBox).Text = "" Then
                    T_Sort_index = 0
                Else
                    T_Sort_index = CType(T_Row.FindControl("txt_sort_index"), TextBox).Text
                End If

                If CType(T_Row.FindControl("chk_view"), CheckBox).Checked Then
                    T_chk_view = "1"
                Else
                    T_chk_view = "0"
                End If

                If CType(T_Row.FindControl("chk_modify"), CheckBox).Checked Then
                    T_chk_modify = "1"
                Else
                    T_chk_modify = "0"
                End If

                If CType(T_Row.FindControl("chk_delete"), CheckBox).Checked Then
                    T_chk_delete = "1"
                Else
                    T_chk_delete = "0"
                End If

                T_id = dbCon.RunSPReturnInteger("dbo.sp_new_temp_role_page", _
                                 New SqlParameter("@role_id", 0), _
                                 New SqlParameter("@page_id", intPageId), _
                                 New SqlParameter("@sort_index", T_Sort_index), _
                                 New SqlParameter("@allow_view", T_chk_view), _
                                 New SqlParameter("@allow_modify", T_chk_modify), _
                                 New SqlParameter("@allow_delete", T_chk_delete), _
                                 New SqlParameter("@modified_by", strBy))

            End If

        Next


        T_id = dbCon.RunSPReturnInteger("dbo.sp_create_role_wiz", _
                         New SqlParameter("@role_name", strRoleName), _
                         New SqlParameter("@created_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Create Role Failed
            strErr = "Create Role Failed"

        Else

            intRoleId = T_id
            intErr = 0 'New Role Information Created Successfully
            strErr = "New Role Information Created Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeCreateRole()

    Public Sub executeUpdateRole()


        Dim dbCon As New DBAccess
        Dim T_id As Integer
        Dim T_Row As GridViewRow
        Dim T_Sort_index As Integer
        Dim T_chk_view As String
        Dim T_chk_modify As String
        Dim T_chk_delete As String

        'Save Role Information to the database 

        For Each T_Row In gvData.Rows

            intPageId = gvData.DataKeys(T_Row.RowIndex).Value


            If CType(T_Row.FindControl("txt_sort_index"), TextBox).Text = "" Then
                T_Sort_index = 0
            Else
                T_Sort_index = CType(T_Row.FindControl("txt_sort_index"), TextBox).Text
            End If

            If CType(T_Row.FindControl("chk_view"), CheckBox).Checked Then
                T_chk_view = "1"
            Else
                T_chk_view = "0"
            End If

            If CType(T_Row.FindControl("chk_modify"), CheckBox).Checked Then
                T_chk_modify = "1"
            Else
                T_chk_modify = "0"
            End If

            If CType(T_Row.FindControl("chk_delete"), CheckBox).Checked Then
                T_chk_delete = "1"
            Else
                T_chk_delete = "0"
            End If

            T_id = dbCon.RunSPReturnInteger("dbo.sp_new_temp_role_page", _
                             New SqlParameter("@role_id", intRoleId), _
                             New SqlParameter("@page_id", intPageId), _
                             New SqlParameter("@sort_index", T_Sort_index), _
                             New SqlParameter("@allow_view", T_chk_view), _
                             New SqlParameter("@allow_modify", T_chk_modify), _
                             New SqlParameter("@allow_delete", T_chk_delete), _
                             New SqlParameter("@modified_by", strBy))


        Next


        T_id = dbCon.RunSPReturnInteger("dbo.sp_update_role_wiz", _
                         New SqlParameter("@role_id", intRoleId), _
                         New SqlParameter("@role_name", strRoleName), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Update Role Failed
            strErr = "Update Role Failed"

        Else

            intErr = 0 'Role Information Saved Successfully
            strErr = "Role Information Saved Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeUpdateRole()

    Public Sub executeDeleteRole()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Delete Role Information from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_delete_role_wiz", _
                         New SqlParameter("@role_id", intRoleId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Delete Role Failed
            strErr = "Delete Role Failed"

        Else

            intErr = 0 'Role Information Deleted Successfully
            strErr = "Role Information Deleted Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeDeleteRole()

    Public Sub executeAddPage()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Add Page Information to the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_add_page", _
                         New SqlParameter("@role_id", intRoleId), _
                         New SqlParameter("@page_id", intPageId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Add Page Failed
            strErr = "Add Page  Failed"

        Else

            intErr = 0 'Page Added Successfully
            strErr = "Page Added Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeAddPage()

    Public Sub executeRemovePage()

        Dim dbCon As New DBAccess
        Dim T_id As Integer

        'Remove Page from the database 

        T_id = dbCon.RunSPReturnInteger("dbo.sp_remove_page", _
                         New SqlParameter("@role_id", intRoleId), _
                         New SqlParameter("@page_id", intPageId), _
                         New SqlParameter("@modified_by", strBy))

        If T_id = "-1" Then

            intErr = -1 'Remove Page Failed
            strErr = "Remove Page  Failed"

        Else

            intErr = 0 'Page Removed Successfully
            strErr = "Page Removed Successfully"

        End If

        dbCon = Nothing


    End Sub 'executeRemovePage()


    Public Function getMenuData(ByVal Role_id As Integer) As System.Data.DataSet

        Dim dbCon As New DBAccess
        Dim T_Main_DataSet As New System.Data.DataSet()
        Dim T_Sub_DataSet As New System.Data.DataSet()


        'Get all the User Menu information from the database

        T_Main_DataSet = dbCon.RunSPReturnDataSet("dbo.sp_get_all_main_menu_items_by_role_id", "Main", _
                     New SqlParameter("@role_id", Role_id))

        T_Sub_DataSet = dbCon.RunSPReturnDataSet("dbo.sp_get_all_sub_menu_items_by_role_id", "Sub", _
                     New SqlParameter("@role_id", Role_id))


        T_Main_DataSet.Merge(T_Sub_DataSet, True)

        T_Main_DataSet.Relations.Add("Sub_Menu", _
        T_Main_DataSet.Tables("Main").Columns("Page_id"), _
        T_Main_DataSet.Tables("Sub").Columns("Parent_page_id"))

        Return T_Main_DataSet

    End Function

    Sub setGVUserPermission(ByVal ColumnName As String, ByVal LinkURL As String, ByVal QueryStringNames As String, ByVal QueryStringValues As String)

        executeSelectUserPermission() 'get the user permissions from the database

        If intErr = 0 Then

            If blnView Then
                GV_Data.Columns.Add(buildColumn(ColumnName, "", "View", "view" & LinkURL, QueryStringNames, QueryStringValues))
            End If

            If blnModify Then
                GV_Data.Columns.Add(buildColumn(ColumnName, "", "Modify", "modify" & LinkURL, QueryStringNames, QueryStringValues))
            End If

            If blnDelete Then
                GV_Data.Columns.Add(buildColumn(ColumnName, "", "Delete", "delete" & LinkURL, QueryStringNames, QueryStringValues))
            End If

        End If

    End Sub

    Public Function buildColumn(ByVal ColumnName As String, ByVal HeaderText As String, ByVal LinkText As String, ByVal LinkURL As String, ByVal QueryStringNames As String, ByVal QueryStringValues As String) As TemplateField

        Dim T_Column As New TemplateField()
        Dim T_Link As New HyperLinkTemplate(ColumnName)

        T_Link.ColumnLinkName = LinkText
        T_Link.NavigateTo = LinkURL
        T_Link.QueryStringNames = QueryStringNames
        T_Link.QueryStringValues = QueryStringValues

        T_Column.HeaderText = HeaderText
        T_Column.ItemTemplate = T_Link

        buildColumn = T_Column

    End Function

    Public Sub selectAllRoles()

        'Get all the Roles information from the database

        Dim dbCon As New DBAccess

        DS_Data.SelectCommand = "dbo.sp_get_all_roles"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub selectAllPages()

        'Get all the Pages information from the database

        Dim dbCon As New DBAccess

        DS_Data.SelectCommand = "dbo.sp_get_all_pages"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing
        
    End Sub

    Public Sub selectAllPagesByRole()

        'Get all the Pages information By Role from the database

        Dim dbCon As New DBAccess

        DS_Data.SelectParameters.Clear()
        DS_Data.SelectCommand = "dbo.sp_get_all_pages_by_role"
        DS_Data.SelectParameters.Add("role_id", intRoleId)
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()

        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub selectAllUsers()

        Dim dbCon As New DBAccess

        'Get all the User information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_users"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

    Public Sub selectAllUserLogs()

        Dim dbCon As New DBAccess

        'Get all the User log information from the database

        DS_Data.SelectCommand = "dbo.sp_get_all_user_logs"
        DS_Data.SelectCommandType = 1
        DS_Data.ConnectionString = dbCon.GetConnectionString()
        DS_Data.DataBind()

        dbCon = Nothing

    End Sub

End Class
