

/****** Script: New/Update/Delete Accounts - PAvaniStone_db_xx	******/
/****** Author: Sreenivasan Subbanchattiar		******/
/****** Script Created By: Sreenivasan Subbanchattiar   	******/
/****** Script Created Date: 7/20/2011 			******/
/****** Script Modified By: Sreenivasan Subbanchattiar		******/
/****** Script Modified Date: 7/20/2011 	  		******/
/****** Script Version: 1.0  				******/


/****** Object:Stored Procedure dbo.sp_new_account_id    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_new_account_id') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_new_account_id
GO

CREATE procedure dbo.sp_new_account_id @new_id as varchar(20) output
as
begin

 select @new_id=(PAL_id + right('0' + cast(datepart(Mm,getdate()) as varchar(2)),2) + right('0' + cast(datepart(dd,getdate()) as varchar(2)),2) + right(cast(datepart(Yy,getdate()) as varchar(4)),2)+ CAST(account_id as varchar(10))) from PAL_identifiers
           
 update PAL_identifiers set account_id=account_id+1
  
end
GO



/****** Object:Stored Procedure   dbo.sp_get_all_accounts    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_accounts') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_accounts
GO

CREATE procedure dbo.sp_get_all_accounts
AS
begin

 SELECT * FROM dbo.view_all_accounts  

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_all_users_by_account    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_users_by_account') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_users_by_account
GO

CREATE procedure dbo.sp_get_all_users_by_account
					 @account_id as varchar(20)
AS
begin

 SELECT * FROM dbo.view_all_users_by_account WHERE account_id = @account_id 

 end
GO 


/****** Object:Stored Procedure   dbo.sp_get_account    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_account') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure  dbo.sp_get_account
GO

CREATE procedure  dbo.sp_get_account
        @account_id as varchar(20)
AS
begin
  
  SELECT * FROM  dbo.view_all_accounts  WHERE account_id = @account_id 
  
 end
GO 


/****** Object:Stored Procedure   dbo.sp_create_account_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_create_account_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_create_account_wiz
GO

create procedure dbo.sp_create_account_wiz( 
	@account_name varchar(50),
	@address1 varchar(50),
	@address2 varchar(50),
	@city varchar(50),
	@state_id int,
	@zip varchar(50),
	@country_id int,
	@phone varchar(50),
	@mobile varchar(50),
	@fax varchar(50),
	@email varchar(50),	
	@created_by varchar(20),
	@retval varchar(20) OUTPUT)
as
begin

declare @account_id varchar(20)
declare @address_id varchar(20)

exec dbo.sp_new_account_id @account_id OUTPUT
exec dbo.sp_new_address_id @address_id OUTPUT

begin tran

exec dbo.sp_new_address	
		@address_id ,
		@address1 ,
		@address2 ,
		@city ,
		@state_id,
		@zip,
		@country_id,
		@phone,
		@mobile,
		@fax,
		@email
		
		
INSERT INTO dbo.accounts(
		account_id,
		account_name,
		Address_id,
		Created_by,
		Created_date,
		Modified_by,
		Modified_date
     )VALUES(
		@account_id,
	    @account_name,
	    @address_id,	    
	    @created_by,
		GETDATE(),
	    @created_by,
		GETDATE()
     )          	
     
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = @account_id
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_update_account_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_update_account_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_update_account_wiz
GO

create procedure dbo.sp_update_account_wiz( 
	@account_id varchar(20),
	@account_name varchar(50),
	@address1 varchar(50),
	@address2 varchar(50),
	@city varchar(50),
	@state_id int,
	@zip varchar(50),
	@country_id int,
	@phone varchar(50),
	@mobile varchar(50),
	@fax varchar(50),
	@email varchar(50),	
	@modified_by varchar(20),
	@retval int OUTPUT)
as
begin

declare @address_id varchar(20)

 SELECT @address_id=address_id FROM dbo.accounts WHERE account_id=@account_id 

begin tran

exec dbo.sp_update_address	
		@address_id ,
		@address1 ,
		@address2 ,
		@city ,
		@state_id,
		@zip,
		@country_id,
		@phone,
		@mobile,
		@fax,
		@email
		
	UPDATE dbo.accounts SET
	    account_name=@account_name,			
		Modified_by = @modified_by,
        Modified_date = GETDATE()  
	WHERE account_id = @account_id
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_delete_account_wiz    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_delete_account_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_delete_account_wiz
GO

CREATE procedure dbo.sp_delete_account_wiz(
			@account_id  varchar(20),
			@modified_by varchar(20),
			@retval int OUTPUT)
AS
begin

 declare @address_id varchar(20)

 SELECT @address_id=address_id FROM dbo.accounts WHERE account_id=@account_id 
 
 begin tran
 
 DELETE FROM  dbo.Pal_Address WHERE address_id=@address_id 
 
 DELETE FROM  dbo.accounts WHERE account_id=@account_id 
 
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 


/****** Object:Stored Procedure   dbo.sp_add_contact_to_account    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_add_contact_to_account') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_add_contact_to_account
GO

CREATE procedure dbo.sp_add_contact_to_account(
			@account_id  varchar(20),
			@user_id  varchar(20),
			@modified_by varchar(20),
			@retval int OUTPUT)
AS
begin
 
 begin tran
 
	INSERT INTO dbo.Accounts_X_Users(
				Account_id,
				User_id
	)VALUES(
		@account_id,
		@user_id		
	) 
 
   UPDATE dbo.Accounts SET
		Modified_by = @modified_by,
        Modified_date = GETDATE()  
	WHERE account_id = @account_id
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 



/****** Object:Stored Procedure   dbo.sp_remove_contact_from_account    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_remove_contact_from_account') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_remove_contact_from_account
GO

CREATE procedure dbo.sp_remove_contact_from_account(
			@account_id  varchar(20),
			@user_id  varchar(20),
			@modified_by varchar(20),
			@retval int OUTPUT)
AS
begin
 
 begin tran
 
	DELETE FROM dbo.Accounts_X_Users WHERE Account_id = @account_id and User_id = @user_id
 
   UPDATE dbo.Accounts SET
		Modified_by = @modified_by,
        Modified_date = GETDATE()  
	WHERE account_id = @account_id
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 
