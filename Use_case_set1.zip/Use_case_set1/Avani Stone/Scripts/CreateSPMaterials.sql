

/****** Script: New/Update/Delete Materials - PAvaniStone_db_xx	******/
/****** Author: Sreenivasan Subbanchattiar		******/
/****** Script Created By: Sreenivasan Subbanchattiar   	******/
/****** Script Created Date: 7/20/2011 			******/
/****** Script Modified By: Sreenivasan Subbanchattiar		******/
/****** Script Modified Date: 7/20/2011 	  		******/
/****** Script Version: 1.0  				******/


/****** Object:Stored Procedure dbo.sp_new_material_id    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_new_material_id') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_new_material_id
GO

CREATE procedure dbo.sp_new_material_id @new_id as varchar(20) output
as
begin

 select @new_id=(PAL_id + right('0' + cast(datepart(Mm,getdate()) as varchar(2)),2) + right('0' + cast(datepart(dd,getdate()) as varchar(2)),2) + right(cast(datepart(Yy,getdate()) as varchar(4)),2)+ CAST(Material_id as varchar(10))) from PAL_identifiers
           
 update PAL_identifiers set Material_id=Material_id+1
  
end
GO



/****** Object:Stored Procedure   dbo.sp_get_all_materials    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_materials') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_materials
GO

CREATE procedure dbo.sp_get_all_materials
AS
begin

 SELECT * FROM dbo.view_all_materials  

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_material    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_material') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure  dbo.sp_get_material
GO

CREATE procedure  dbo.sp_get_material
        @Material_id as varchar(20)
AS
begin
  
  SELECT * FROM  dbo.view_all_materials  WHERE Material_id = @Material_id 
  
 end
GO 


/****** Object:Stored Procedure   dbo.sp_create_material_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_create_material_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_create_material_wiz
GO

create procedure dbo.sp_create_material_wiz( 
	@Material_name varchar(50),	
	@Material_color varchar(50),
	@Material_code_number varchar(50),
	@Material_type_id tinyint,
	@Material_description varchar(500),
	@File_type_id tinyint,
	@File_location varchar(50),
	@Country_id int,
	@created_by varchar(20),
	@retval varchar(20) OUTPUT)
as
begin

declare @Material_id varchar(20)

exec dbo.sp_new_material_id @material_id OUTPUT

begin tran
		
INSERT INTO dbo.Materials(
		Material_id,
		Material_name,
		Material_color,
        Material_code_number,
        Material_type_id,
        Material_description,
        File_type_id,
        File_location,
        Country_id,
		Created_by,
		Created_date,
		Modified_by,
		Modified_date
     )VALUES(
		@Material_id,
	    @Material_name,
	    @Material_color,
        @Material_code_number,
        @Material_type_id,
        @Material_description,
        @File_type_id,
        @File_location,
        @Country_id,	    
	    @created_by,
		GETDATE(),
	    @created_by,
		GETDATE()
     )          	
     
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = @Material_id
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_update_material_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_update_material_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_update_material_wiz
GO

create procedure dbo.sp_update_material_wiz( 
	@Material_id varchar(20),
	@Material_name varchar(50),	
	@Material_color varchar(50),
	@Material_code_number varchar(50),
	@Material_type_id tinyint,
	@Material_description varchar(500),
	@File_type_id tinyint,
	@File_location varchar(50),
	@Country_id int,	
	@modified_by varchar(20),
	@retval int OUTPUT)
as
begin

begin tran

	UPDATE dbo.Materials SET
	    Material_name=@Material_name,
		Material_color=@Material_color,
        Material_code_number=@Material_code_number,
        Material_type_id=@Material_type_id,
        Material_description=@Material_description,
        File_type_id=@File_type_id,
        File_location=@File_location,
        Country_id=@Country_id,	 			
		Modified_by = @modified_by,
        Modified_date = GETDATE()  
	WHERE Material_id = @Material_id
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_delete_material_wiz    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_delete_material_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_delete_material_wiz
GO

CREATE procedure dbo.sp_delete_material_wiz(
			@Material_id  varchar(20),
			@modified_by varchar(20),
			@retval int OUTPUT)
AS
begin
 
 begin tran
 
 DELETE FROM  dbo.Materials WHERE Material_id=@Material_id 
 
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 
