

/****** Script: New/Update/Delete Work Orders - PAvaniStone_db_xx	******/
/****** Author: Sreenivasan Subbanchattiar		******/
/****** Script Created By: Sreenivasan Subbanchattiar   	******/
/****** Script Created Date: 7/20/2011 			******/
/****** Script Modified By: Sreenivasan Subbanchattiar		******/
/****** Script Modified Date: 7/20/2011 	  		******/
/****** Script Version: 1.0  				******/


/****** Object:Stored Procedure dbo.sp_new_work_order_id    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_new_work_order_id') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_new_work_order_id
GO

CREATE procedure dbo.sp_new_work_order_id @new_id as varchar(20) output
as
begin

 select @new_id=(PAL_id + right('0' + cast(datepart(Mm,getdate()) as varchar(2)),2) + right('0' + cast(datepart(dd,getdate()) as varchar(2)),2) + right(cast(datepart(Yy,getdate()) as varchar(4)),2)+ CAST(work_order_id as varchar(10))) from PAL_identifiers
           
 update PAL_identifiers set work_order_id=work_order_id+1
  
end
GO


/****** Object:Stored Procedure dbo.sp_new_work_order_no    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_new_work_order_no') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_new_work_order_no
GO

CREATE procedure dbo.sp_new_work_order_no @new_id as int output
as
begin

 select @new_id=work_order_number from dbo.PAL_identifiers
           
 update PAL_identifiers set work_order_number=work_order_number+1
  
end
GO


/****** Object:Stored Procedure   dbo.sp_get_all_work_orders    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_work_orders') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_work_orders
GO

CREATE procedure dbo.sp_get_all_work_orders
AS
begin

 SELECT * FROM dbo.view_all_work_orders  

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_all_work_order_templates    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_work_order_templates') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_work_order_templates
GO

CREATE procedure dbo.sp_get_all_work_order_templates
AS
begin

 SELECT * FROM dbo.view_all_work_order_templates  WHERE Template_by_id IS NOT NULL

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_all_work_order_templates_not_yet_approved    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_work_order_templates_not_yet_approved') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_work_order_templates_not_yet_approved
GO

CREATE procedure dbo.sp_get_all_work_order_templates_not_yet_approved
AS
begin

 SELECT * FROM dbo.view_all_work_order_templates  WHERE Template_completed = '1' AND Template_accepted IS NULL

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_all_schedule_work_order_templates    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_schedule_work_order_templates') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_schedule_work_order_templates
GO

CREATE procedure dbo.sp_get_all_schedule_work_order_templates
AS
begin

 SELECT * FROM dbo.view_all_work_order_templates WHERE Time_Slot_id IS NULL  

 end
GO 


/****** Object:Stored Procedure   dbo.sp_get_all_scheduled_work_order_templates    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_scheduled_work_order_templates') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_scheduled_work_order_templates
GO

CREATE procedure dbo.sp_get_all_scheduled_work_order_templates
AS
begin

 SELECT * FROM dbo.view_all_work_order_templates WHERE Time_Slot_id IS NOT NULL  

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_all_scheduled_work_order_templates_by_user    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_scheduled_work_order_templates_by_user') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_scheduled_work_order_templates_by_user
GO

CREATE procedure dbo.sp_get_all_scheduled_work_order_templates_by_user
						@User_id as varchar(20)
AS
begin

 SELECT * FROM dbo.view_all_work_order_templates WHERE Template_by_id = @User_id AND Time_Slot_id IS NOT NULL  

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_all_work_orders_by_user    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_work_orders_by_user') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_work_orders_by_user
GO

CREATE procedure dbo.sp_get_all_work_orders_by_user
				@User_id as varchar(20)
AS
begin

 SELECT * FROM dbo.view_all_work_orders  WHERE User_Id = @User_id

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_work_order    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_work_order') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure  dbo.sp_get_work_order
GO

CREATE procedure  dbo.sp_get_work_order
        @work_order_id as varchar(20)
AS
begin
  
  SELECT * FROM  dbo.view_all_work_orders  WHERE work_order_id = @work_order_id 
  
 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_work_order_template    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_work_order_template') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure  dbo.sp_get_work_order_template
GO

CREATE procedure  dbo.sp_get_work_order_template
        @work_order_id as varchar(20)
AS
begin
  
  SELECT * FROM  dbo.view_all_work_order_templates  WHERE work_order_id = @work_order_id 
  
 end
GO 

/****** Object:Stored Procedure   dbo.sp_create_work_order_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_create_work_order_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_create_work_order_wiz
GO

create procedure dbo.sp_create_work_order_wiz(	
	@Quote_detail_id varchar(50),
	@Purchase_order_number varchar(50),		
	@Purchase_order_date Varchar(50),	
	@Requested_start_date Varchar(50),
	@Work_order_comments Varchar(255),
	@Floor varchar(50),
	@Template_type_id	Int,
	@Construction_type_id	Int,
	@Sink_type_id	Int,
	@No_of_Sink	Int,
	@Back_splash 	Char(1),
	@Back_splash_details	Varchar(50),
	@Mill_down 	Char(1),
	@Mill_down_details	Varchar(50),
	@Stove_type_id	Int,
	@Faucet_type_id	Int,
	@Edge_type_id	Int,
	@Edge_type_details Varchar(255),
	@Cutouts	Varchar(50),
	@Cutouts_quantity Int,
	@Material_id	Varchar(20),
	@Thickness_id	Int,	
	@Top_removal Char(1),
	@Sink_status_id int   ,
	@Faucet_status_id int   ,
	@Kitchen_island	Varchar(255) ,
	@Cabinets	Varchar(255) ,	
	@Created_by varchar(20),
	@retval varchar(20) OUTPUT)
as
begin

Declare @work_order_id varchar(20)
Declare @Work_order_number int
Declare @dt_Purchase_order_date date

	IF @Purchase_order_date = ''
		SET @dt_Purchase_order_date = NULL
	ELSE
		SET @dt_Purchase_order_date = @Purchase_order_date
	
	
	EXEC dbo.sp_new_work_order_id @work_order_id OUTPUT
	EXEC dbo.sp_new_work_order_no @Work_order_number OUTPUT

begin tran
			
	INSERT INTO dbo.Work_Orders(
			 Work_order_id
			,Work_order_number 
			,Quote_detail_id 
			,Purchase_order_number			
			,Purchase_order_date	
			,Requested_start_date
			,Work_order_comments
			,Template 
			,Fabrication
			,Installation
			,Repair
			,Created_by
			,Created_date
			,Modified_by
			,Modified_date
	)VALUES(
			 @Work_order_id
			,@Work_order_number 
			,@Quote_detail_id 
			,@Purchase_order_number			
			,@dt_Purchase_order_date	
			,@Requested_start_date
			,@Work_order_comments
			,'0' 
			,'0'
			,'0'
			,'0'
			,@Created_by
			,GETDATE()
			,@Created_by
			,GETDATE()
		 )          	
		 
 if @@error = 0	     
  INSERT INTO dbo.Work_Order_Details(
			Work_Order_id
           ,Floor
           ,Template_type_id
           ,Construction_type_id
           ,Sink_type_id
           ,No_of_sink
           ,Back_splash
           ,Back_splash_details
           ,Mill_down
           ,Mill_down_details
           ,Stove_type_id
           ,Faucet_type_id
           ,Edge_type_id
           ,Edge_type_details
           ,Cutouts
           ,Cutouts_quantity
           ,Top_removal
           ,Material_id
           ,Thickness_id
           ,Sink_status_id
           ,Faucet_status_id
           ,Kitchen_island
           ,Cabinets
	) VALUES(
			@Work_Order_id
           ,@Floor
           ,@Template_type_id
           ,@Construction_type_id
           ,@Sink_type_id
           ,@No_of_sink
           ,@Back_splash
           ,@Back_splash_details
           ,@Mill_down
           ,@Mill_down_details
           ,@Stove_type_id
           ,@Faucet_type_id
           ,@Edge_type_id
           ,@Edge_type_details
           ,@Cutouts
           ,@Cutouts_quantity
           ,@Top_removal
           ,@Material_id
           ,@Thickness_id
           ,@Sink_status_id
           ,@Faucet_status_id
           ,@Kitchen_island
           ,@Cabinets
      )

 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = @work_order_id
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_update_work_order_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_update_work_order_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_update_work_order_wiz
GO
           
create procedure dbo.sp_update_work_order_wiz( 
	@Work_order_id varchar(20),	
	@Floor varchar(50),
	@Template_type_id	Int,
	@Construction_type_id	Int,
	@Sink_type_id	Int,
	@No_of_Sink	Int,
	@Back_splash 	Char(1),
	@Back_splash_details	Varchar(50),
	@Mill_down 	Char(1),
	@Mill_down_details	Varchar(50),
	@Stove_type_id	Int,
	@Faucet_type_id	Int,
	@Edge_type_id	Int,
	@Edge_type_details Varchar(255),
	@Cutouts	Varchar(50),
	@Cutouts_quantity Int,
	@Material_id	Varchar(20),
	@Thickness_id	Int,	
	@Top_removal Char(1),
	@Sink_status_id int   ,
	@Faucet_status_id int   ,
	@Kitchen_island	Varchar(255) ,
	@Cabinets	Varchar(255) ,			
	@Template Char(1),
	@Fabrication Char(1),
	@Installation Char(1),
	@Repair Char(1),				
	@modified_by varchar(20),
	@retval int OUTPUT)
as
begin

begin tran
		
	UPDATE dbo.Work_Orders SET			 
			 Template=@Template 
			,Fabrication=@Fabrication
			,Installation=@Installation
			,Repair=@Repair
			,Modified_by = @modified_by
			,Modified_date = GETDATE()  
	WHERE Work_Order_id = @Work_order_id  
	
	UPDATE dbo.Work_Order_Details SET
			Floor=@Floor 			
           ,Template_type_id=@Template_type_id
           ,Construction_type_id=@Construction_type_id
           ,Sink_type_id=@Sink_type_id
           ,No_of_sink=@No_of_sink
           ,Back_splash=@Back_splash
           ,Back_splash_details=@Back_splash_details
           ,Mill_down=@Mill_down
           ,Mill_down_details=@Mill_down_details
           ,Stove_type_id=@Stove_type_id
           ,Faucet_type_id=@Faucet_type_id
           ,Edge_type_id=@Edge_type_id
           ,Edge_type_details=@Edge_type_details
           ,Cutouts=@Cutouts
           ,Cutouts_quantity=@Cutouts_quantity
           ,Top_removal=@Top_removal
           ,Material_id=@Material_id
           ,Thickness_id=@Thickness_id
           ,Sink_status_id=@Sink_status_id
           ,Faucet_status_id=@Faucet_status_id
           ,Kitchen_island=@Kitchen_island
           ,Cabinets=@Cabinets
	WHERE Work_Order_id = @Work_order_id  
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_delete_work_order_wiz    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_delete_work_order_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_delete_work_order_wiz
GO

CREATE procedure dbo.sp_delete_work_order_wiz(
			@work_order_id  varchar(20),
			@modified_by varchar(20),
			@retval int OUTPUT)
AS
begin
 
 begin tran
 
 DELETE FROM  dbo.Work_order_Details WHERE work_order_id=@work_order_id 
 DELETE FROM  dbo.Work_orders WHERE work_order_id=@work_order_id 
 
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 
 

/****** Object:Stored Procedure   dbo.sp_schedule_template_wiz    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_schedule_template_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_schedule_template_wiz
GO

CREATE procedure dbo.sp_schedule_template_wiz(
			@Work_order_id  varchar(20),
			@Template_date  varchar(20),
			@Time_slot_id Int,
			@Template_by  varchar(20),			
			@Estimate_SQFT varchar(20),
			@Modified_by varchar(20),			
			@retval int OUTPUT)
AS
begin
 
 if @Estimate_SQFT = ''
	SET @Estimate_SQFT = NULL 
 
 begin tran
 
 INSERT INTO dbo.Work_Order_Templates(
            Work_order_id,
			Template_date,
			Time_slot_id,
			Template_by,			
			Estimate_SQFT,
			Template_completed			
 )VALUES(
            @Work_order_id  ,
			@Template_date,
			@Time_slot_id ,
			@Template_by  ,			
			@Estimate_SQFT,
			'0' 
 )
 
  if @@error = 0
     UPDATE dbo.Work_orders SET 
             Modified_by = @Modified_by,
             Modified_date = GETDATE()
     WHERE Work_Order_id =@Work_order_id          
   
  
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 

 

/****** Object:Stored Procedure   dbo.sp_update_template_wiz    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_update_template_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_update_template_wiz
GO

CREATE procedure dbo.sp_update_template_wiz(
			@Work_order_id  varchar(20),
			@Template_date  varchar(20),
			@Time_slot_id Int,
			@Template_by  varchar(20),			
			@Estimate_SQFT varchar(20),
			@Modified_by varchar(20),			
			@retval int OUTPUT)
AS
begin
 
 begin tran
 
	 UPDATE dbo.Work_Order_Templates SET				
				Template_date=@Template_date,
				Time_slot_id=@Time_slot_id,
				Template_by=@Template_by,			
				Estimate_SQFT=@Estimate_SQFT
	  WHERE Work_Order_id =@Work_order_id   
 
  if @@error = 0
     UPDATE dbo.Work_orders SET 
             Modified_by = @Modified_by,
             Modified_date = GETDATE()
     WHERE Work_Order_id =@Work_order_id          
   
  
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 



/****** Object:Stored Procedure   dbo.sp_update_template_completed_wiz    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_update_template_completed_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_update_template_completed_wiz
GO

CREATE procedure dbo.sp_update_template_completed_wiz(
			@Work_order_id  varchar(20),			
			@Actual_SQFT varchar(20),
			@Template_completed  char(1),
			@Modified_by varchar(20),			
			@retval int OUTPUT)
AS
begin
  
 begin tran
 
	 UPDATE dbo.Work_Order_Templates SET				
			Actual_SQFT=@Actual_SQFT,
			Template_completed=@Template_completed
	  WHERE Work_Order_id =@Work_order_id   
 
  if @@error = 0
     UPDATE dbo.Work_orders SET 
             Modified_by = @Modified_by,
             Modified_date = GETDATE()
     WHERE Work_Order_id =@Work_order_id          
   
  
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 



/****** Object:Stored Procedure   dbo.sp_update_template_accepted_wiz    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_update_template_accepted_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_update_template_accepted_wiz
GO

CREATE procedure dbo.sp_update_template_accepted_wiz(
			@Work_order_id  varchar(20),						
			@Template_accepted  char(1),
			@Modified_by varchar(20),			
			@retval int OUTPUT)
AS
begin
  
 begin tran
 
	 UPDATE dbo.Work_Order_Templates SET		
	        Verified_by = @Modified_by,
	        Verified_date = GETDATE (),
			Template_accepted=@Template_accepted
	  WHERE Work_Order_id =@Work_order_id   
 
  if @@error = 0
     UPDATE dbo.Work_orders SET 
             Modified_by = @Modified_by,
             Modified_date = GETDATE()
     WHERE Work_Order_id =@Work_order_id          
   
  
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 