

/****** Script: New/Update/Delete Customers - PAvaniStone_db_xx	******/
/****** Author: Sreenivasan Subbanchattiar		******/
/****** Script Created By: Sreenivasan Subbanchattiar   	******/
/****** Script Created Date: 7/20/2011 			******/
/****** Script Modified By: Sreenivasan Subbanchattiar		******/
/****** Script Modified Date: 7/20/2011 	  		******/
/****** Script Version: 1.0  				******/


/****** Object:Stored Procedure dbo.sp_new_customer_id    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_new_customer_id') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_new_customer_id
GO

CREATE procedure dbo.sp_new_customer_id @new_id as varchar(20) output
as
begin

 select @new_id=(PAL_id + right('0' + cast(datepart(Mm,getdate()) as varchar(2)),2) + right('0' + cast(datepart(dd,getdate()) as varchar(2)),2) + right(cast(datepart(Yy,getdate()) as varchar(4)),2)+ CAST(customer_id as varchar(10))) from PAL_identifiers
           
 update PAL_identifiers set customer_id=customer_id+1
  
end
GO



/****** Object:Stored Procedure   dbo.sp_get_all_customers    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_customers') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_customers
GO

CREATE procedure dbo.sp_get_all_customers
AS
begin

 SELECT * FROM dbo.view_all_customers  

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_customer    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_customer') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure  dbo.sp_get_customer
GO

CREATE procedure  dbo.sp_get_customer
        @customer_id as varchar(20)
AS
begin
  
  SELECT * FROM  dbo.view_all_customers  WHERE customer_id = @customer_id 
  
 end
GO 


/****** Object:Stored Procedure   dbo.sp_create_customer_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_create_customer_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_create_customer_wiz
GO

create procedure dbo.sp_create_customer_wiz( 
	@first_name varchar(50),
	@last_name varchar(50),
	@address1 varchar(50),
	@address2 varchar(50),
	@city varchar(50),
	@state_id int,
	@zip varchar(50),
	@country_id int,
	@phone varchar(50),
	@mobile varchar(50),
	@fax varchar(50),
	@email varchar(50),	
	@created_by varchar(20),
	@retval varchar(20) OUTPUT)
as
begin

declare @customer_id varchar(20)

exec dbo.sp_new_customer_id @customer_id OUTPUT

begin tran
		
INSERT INTO dbo.customers(
		Customer_id
	   ,First_name
	   ,Last_name
	   ,Address1
	   ,Address2
	   ,City
	   ,State_id
	   ,Zip
	   ,Country_id
	   ,Phone
	   ,Mobile
	   ,Fax
	   ,Email
	   ,Created_by
	   ,Created_date
	   ,Modified_by
	   ,Modified_date
)VALUES(
		@customer_id,
	    @first_name,
		@last_name,
	    @address1 ,
		@address2 ,
		@city ,
		@state_id,
		@zip,
		@country_id,
		@phone,
		@mobile,
		@fax,
		@email,	    
	    @created_by,
		GETDATE(),
	    @created_by,
		GETDATE()
     )          	
     
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = @customer_id
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_update_customer_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_update_customer_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_update_customer_wiz
GO

create procedure dbo.sp_update_customer_wiz( 
	@customer_id varchar(20),
	@first_name varchar(50),
	@last_name varchar(50),
	@address1 varchar(50),
	@address2 varchar(50),
	@city varchar(50),
	@state_id int,
	@zip varchar(50),
	@country_id int,
	@phone varchar(50),
	@mobile varchar(50),
	@fax varchar(50),
	@email varchar(50),	
	@modified_by varchar(20),
	@retval int OUTPUT)
as
begin

begin tran
		
	UPDATE dbo.Customers SET
	    first_name=@first_name,
	    last_name=@last_name,
	    address1 = @address1,
		address2 = @address2,
		city = @city,
		state_id = @state_id,
		zip = @zip,
		country_id = @country_id,
		phone = @phone,
		mobile = @mobile,
		fax = @fax,
		email = @email,			
		Modified_by = @modified_by,
        Modified_date = GETDATE()  
	WHERE customer_id = @customer_id
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_delete_customer_wiz    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_delete_customer_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_delete_customer_wiz
GO

CREATE procedure dbo.sp_delete_customer_wiz(
			@customer_id  varchar(20),
			@modified_by varchar(20),
			@retval int OUTPUT)
AS
begin
 
 begin tran
 
 DELETE FROM  dbo.customers WHERE customer_id=@customer_id 
 
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 
