
/****** Description: All Views Create and Drop Scripts For PAvaniStone_db_xx  ******/
/****** Author:  Sreenivasan Subbanchattiar  ******/
/****** Script Created Date: 7/20/2011  ******/
/****** Script Modified Date: 7/20/2011   ******/
/****** Script Version: 1.0  ******/

/****** Database:  PAvaniStone_db_xx  ******/
USE PAvaniStone_db_xx
GO


/****** Object:  View dbo.view_created_by    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_created_by') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_created_by
GO

CREATE VIEW dbo.view_created_by
AS
SELECT   User_id, First_name + ' ' + Last_name AS Created_by
FROM     dbo.PAL_Users
GO

/****** Object:  View dbo.view_modified_by    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_modified_by') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_modified_by
GO

CREATE VIEW dbo.view_modified_by
AS
SELECT   User_id, First_name + ' ' + Last_name AS Modified_by
FROM     dbo.PAL_Users
GO

/****** Object:  View dbo.view_requested_by    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_requested_by') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_requested_by
GO

CREATE VIEW dbo.view_requested_by
AS
SELECT   User_id AS Requested_by_id, First_name + ' ' + Last_name AS Requested_by
FROM     dbo.PAL_Users
GO

/****** Object:  View dbo.view_template_by    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_template_by') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_template_by
GO

CREATE VIEW dbo.view_template_by
AS
SELECT   User_id AS Template_by_id, First_name + ' ' + Last_name AS Template_by
FROM     dbo.PAL_Users
GO


/****** Object:  View dbo.view_verified_by    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_verified_by') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_verified_by
GO

CREATE VIEW dbo.view_verified_by
AS
SELECT   User_id AS Verified_by_id, First_name + ' ' + Last_name AS Verified_by
FROM     dbo.PAL_Users
GO

/****** Object:  View dbo.view_fabrication_by    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_fabrication_by') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_fabrication_by
GO

CREATE VIEW dbo.view_fabrication_by
AS
SELECT   User_id AS Fabrication_by_id, First_name + ' ' + Last_name AS Fabrication_by
FROM     dbo.PAL_Users
GO

/****** Object:  View dbo.view_installation_by    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_installation_by') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_installation_by
GO

CREATE VIEW dbo.view_installation_by
AS
SELECT   User_id AS Installation_by_id, First_name + ' ' + Last_name AS Installation_by
FROM     dbo.PAL_Users
GO

/****** Object:  View dbo.view_repair_service_by    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_repair_service_by') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_repair_service_by
GO

CREATE VIEW dbo.view_repair_service_by
AS
SELECT   User_id AS Repair_service_by_id, First_name + ' ' + Last_name AS Repair_service_by
FROM     dbo.PAL_Users
GO

/****** Object:  View dbo.view_all_user_logs    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_user_logs') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_user_logs
GO

CREATE VIEW dbo.view_all_user_logs
AS
SELECT	dbo.PAL_Users_Log.Log_id, dbo.PAL_Users_Log.IP_address, dbo.PAL_Users_Log.Browser, dbo.PAL_Users_Log.Log_data, dbo.view_created_by.Created_by, 
        dbo.PAL_Users_Log.Log_date, dbo.PAL_Users_Log.Log_by
FROM	dbo.PAL_Users_Log 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.PAL_Users_Log.Log_by = dbo.view_created_by.User_id
go      
         
/****** Object:  View dbo.view_all_roles    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_roles') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_roles
GO

CREATE VIEW dbo.view_all_roles
AS
SELECT	dbo.PAL_Role.Role_id, dbo.PAL_Role.Role_name, dbo.view_created_by.Created_by, dbo.PAL_Role.Created_date, 
        dbo.view_modified_by.Modified_by, dbo.PAL_Role.Modified_date
FROM    dbo.PAL_Role 
		LEFT OUTER JOIN   dbo.view_modified_by ON dbo.PAL_Role.Modified_by = dbo.view_modified_by.User_id 
		LEFT OUTER JOIN	  dbo.view_created_by ON dbo.PAL_Role.Created_by = dbo.view_created_by.User_id
GO


/****** Object:  View dbo.view_all_pages   Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_pages') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_pages
GO

CREATE VIEW dbo.view_all_pages
AS
SELECT	dbo.PAL_Page.Page_id, dbo.PAL_Page.Parent_Page_id, dbo.PAL_Page.Page_title, PAL_Page_1.Page_title AS Parent_page_title, 
        dbo.PAL_Page.Navigate_url, dbo.PAL_Page.Page_description, dbo.view_created_by.Created_by, dbo.PAL_Page.Created_date, 
        dbo.view_modified_by.Modified_by, dbo.PAL_Page.Modified_date
FROM    dbo.PAL_Page 
		LEFT OUTER JOIN dbo.PAL_Page AS PAL_Page_1 ON dbo.PAL_Page.Parent_Page_id = PAL_Page_1.Page_id 
		LEFT OUTER JOIN dbo.view_modified_by ON dbo.PAL_Page.Modified_by = dbo.view_modified_by.User_id 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.PAL_Page.Created_by = dbo.view_created_by.User_id
GO

/****** Object:  View dbo.view_all_pages_by_role    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_pages_by_role') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_pages_by_role
GO

CREATE VIEW dbo.view_all_pages_by_role
AS
SELECT	dbo.view_all_pages.Page_id, dbo.view_all_pages.Parent_Page_id, dbo.view_all_pages.Page_title, dbo.view_all_pages.Parent_Page_title, dbo.view_all_pages.Navigate_url, 
        dbo.view_all_pages.Page_description, dbo.view_all_pages.Created_by, dbo.view_all_pages.Created_date, dbo.view_all_pages.Modified_by, 
        dbo.view_all_pages.Modified_date, dbo.PAL_Role_X_PAL_Page.Role_id, dbo.PAL_Role_X_PAL_Page.Sort_index, 
        dbo.PAL_Role_X_PAL_Page.Allow_view, dbo.PAL_Role_X_PAL_Page.Allow_modify, dbo.PAL_Role_X_PAL_Page.Allow_delete
FROM    dbo.PAL_Role_X_PAL_Page 
		INNER JOIN  dbo.view_all_pages ON dbo.PAL_Role_X_PAL_Page.Page_id = dbo.view_all_pages.Page_id
GO

                      
/****** Object:  View dbo.view_all_address    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_address') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_address
GO

CREATE VIEW dbo.view_all_address
AS
SELECT	dbo.PAL_Address.Address_id, dbo.PAL_Address.Address1, dbo.PAL_Address.Address2, dbo.PAL_Address.City, dbo.PAL_Address.State_id, dbo.State_LKUP.State_name, dbo.State_LKUP.State_code, 
        dbo.PAL_Address.Zip, dbo.PAL_Address.Country_id, dbo.Country_LKUP.Country_name, dbo.PAL_Address.Phone, dbo.PAL_Address.Mobile, dbo.PAL_Address.Fax, 
        dbo.PAL_Address.Email
FROM    dbo.PAL_Address 
		LEFT OUTER JOIN dbo.Country_LKUP ON dbo.PAL_Address.Country_id = dbo.Country_LKUP.Country_id 
		LEFT OUTER JOIN dbo.State_LKUP ON dbo.PAL_Address.State_id = dbo.State_LKUP.State_id
GO

                      
/****** Object:  View dbo.view_all_users    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_users') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_users
GO

CREATE VIEW dbo.view_all_users
AS
SELECT	dbo.PAL_Users.User_id, dbo.PAL_Users.User_name, dbo.PAL_Users.Passwd, dbo.PAL_Users.First_name, dbo.PAL_Users.Last_name, 
        dbo.PAL_Users.Active_user, dbo.PAL_Users.Role_id, dbo.view_all_roles.Role_name, dbo.PAL_Users.Last_login_date, dbo.PAL_Users.Address_id, 
        dbo.view_all_address.Address1, dbo.view_all_address.Address2, dbo.view_all_address.City, dbo.view_all_address.State_id, 
        dbo.view_all_address.State_name, dbo.view_all_address.State_code, dbo.view_all_address.Zip, dbo.view_all_address.Country_id, dbo.view_all_address.Country_name, 
        dbo.view_all_address.Phone, dbo.view_all_address.Mobile, dbo.view_all_address.Fax, dbo.view_all_address.Email, 
        dbo.view_created_by.Created_by, dbo.view_modified_by.Modified_by, dbo.PAL_Users.Created_date, dbo.PAL_Users.Modified_date
FROM    dbo.PAL_Users 
		LEFT OUTER JOIN dbo.view_modified_by ON dbo.PAL_Users.User_id = dbo.view_modified_by.User_id 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.PAL_Users.User_id = dbo.view_created_by.User_id 
		LEFT OUTER JOIN dbo.view_all_roles ON dbo.PAL_Users.Role_id = dbo.view_all_roles.Role_id 
		LEFT OUTER JOIN dbo.view_all_address ON dbo.PAL_Users.Address_id = dbo.view_all_address.Address_id
GO

/****** Object:  View dbo.view_all_users_by_account    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_users_by_account') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_users_by_account
GO

CREATE VIEW dbo.view_all_users_by_account
AS
SELECT	dbo.view_all_users.User_id, dbo.view_all_users.User_name, dbo.view_all_users.Passwd, dbo.view_all_users.First_name, 
        dbo.view_all_users.Last_name, dbo.view_all_users.Active_user, dbo.view_all_users.Role_id, dbo.view_all_users.Role_name, 
        dbo.view_all_users.Last_login_date, dbo.view_all_users.Address_id, dbo.view_all_users.Address1, dbo.view_all_users.Address2, 
        dbo.view_all_users.City, dbo.view_all_users.State_id, dbo.view_all_users.State_name, dbo.view_all_users.State_code, dbo.view_all_users.Zip, 
        dbo.view_all_users.Country_id, dbo.view_all_users.Country_name, dbo.view_all_users.Phone, dbo.view_all_users.Mobile, dbo.view_all_users.Fax, 
        dbo.view_all_users.Email, dbo.view_all_users.Created_by, dbo.view_all_users.Modified_by, dbo.view_all_users.Created_date, 
        dbo.view_all_users.Modified_date, dbo.Accounts_X_Users.Account_id
FROM    dbo.view_all_users 
		INNER JOIN dbo.Accounts_X_Users ON dbo.view_all_users.User_id = dbo.Accounts_X_Users.User_id
GO                      
                      
/****** Object:  View dbo.view_all_country    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_country') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_country
GO

CREATE VIEW dbo.view_all_country
AS
SELECT	Country_id, Country_name, Country_code
FROM	dbo.Country_LKUP
GO 

/****** Object:  View dbo.view_all_states_by_country    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_states_by_country') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_states_by_country
GO

CREATE VIEW dbo.view_all_states_by_country
AS
SELECT   dbo.State_LKUP.State_id, dbo.State_LKUP.State_name, dbo.State_LKUP.State_code, dbo.Country_X_State.Country_id
FROM     dbo.State_LKUP 
		 INNER JOIN  dbo.Country_X_State ON dbo.State_LKUP.State_id = dbo.Country_X_State.State_id
GO          

/****** Object:  View dbo.view_all_suppliers    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_suppliers') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_suppliers
GO

CREATE VIEW dbo.view_all_suppliers
AS
SELECT	dbo.Suppliers.Supplier_id, dbo.Suppliers.Supplier_name, dbo.Suppliers.Address_id, dbo.view_all_address.Address1, dbo.view_all_address.Address2, 
        dbo.view_all_address.City, dbo.view_all_address.State_id, dbo.view_all_address.State_name, dbo.view_all_address.State_code, dbo.view_all_address.Zip, dbo.view_all_address.Country_id, 
        dbo.view_all_address.Country_name, dbo.view_all_address.Phone, dbo.view_all_address.Mobile, dbo.view_all_address.Fax, dbo.view_all_address.Email, 
        dbo.view_created_by.Created_by, dbo.Suppliers.Created_date, dbo.view_modified_by.Modified_by, dbo.Suppliers.Modified_date
FROM	dbo.Suppliers 
		LEFT OUTER JOIN dbo.view_modified_by ON dbo.Suppliers.Modified_by = dbo.view_modified_by.User_id 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.Suppliers.Created_by = dbo.view_created_by.User_id 
		LEFT OUTER JOIN dbo.view_all_address ON dbo.Suppliers.Address_id = dbo.view_all_address.Address_id
GO   

/****** Object:  View dbo.view_all_accounts    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_accounts') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_accounts
GO

CREATE VIEW dbo.view_all_accounts
AS
SELECT	dbo.Accounts.Account_id, dbo.Accounts.Account_name, dbo.Accounts.Address_id, dbo.view_all_address.Address1, dbo.view_all_address.Address2, 
        dbo.view_all_address.City, dbo.view_all_address.State_id, dbo.view_all_address.State_name, dbo.view_all_address.State_code, dbo.view_all_address.Zip, dbo.view_all_address.Country_id, 
        dbo.view_all_address.Country_name, dbo.view_all_address.Phone, dbo.view_all_address.Mobile, dbo.view_all_address.Fax, dbo.view_all_address.Email, 
        dbo.view_created_by.Created_by, dbo.Accounts.Created_date, dbo.view_modified_by.Modified_by, dbo.Accounts.Modified_date
FROM	dbo.Accounts 
		LEFT OUTER JOIN dbo.view_modified_by ON dbo.Accounts.Modified_by = dbo.view_modified_by.User_id 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.Accounts.Created_by = dbo.view_created_by.User_id 
		LEFT OUTER JOIN dbo.view_all_address ON dbo.Accounts.Address_id = dbo.view_all_address.Address_id
GO   

/****** Object:  View dbo.view_all_accounts_by_user    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_accounts_by_user') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_accounts_by_user
GO

CREATE VIEW dbo.view_all_accounts_by_user
AS
SELECT	  dbo.view_all_accounts.Account_id, dbo.view_all_accounts.Account_name, dbo.view_all_accounts.Address_id, dbo.view_all_accounts.Address1, 
		  dbo.view_all_accounts.Address2, dbo.view_all_accounts.City, dbo.view_all_accounts.State_id, dbo.view_all_accounts.State_name, 
		  dbo.view_all_accounts.State_code, dbo.view_all_accounts.Zip, dbo.view_all_accounts.Country_id, dbo.view_all_accounts.Country_name, 
		  dbo.view_all_accounts.Phone, dbo.view_all_accounts.Mobile, dbo.view_all_accounts.Fax, dbo.view_all_accounts.Email, 
		  dbo.view_all_accounts.Created_by, dbo.view_all_accounts.Created_date, dbo.view_all_accounts.Modified_by, dbo.view_all_accounts.Modified_date, 
		  dbo.Accounts_X_Users.User_id, dbo.view_requested_by.Requested_by
FROM      dbo.view_all_accounts 
	      INNER JOIN dbo.Accounts_X_Users ON dbo.view_all_accounts.Account_id = dbo.Accounts_X_Users.Account_id 
	      INNER JOIN dbo.view_requested_by ON dbo.Accounts_X_Users.User_id = dbo.view_requested_by.Requested_by_id 
GO		

/****** Object:  View dbo.view_all_quotes    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_quotes') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_quotes
GO

CREATE VIEW dbo.view_all_quotes
AS
SELECT	dbo.Quote_Details.Quote_detail_id,  dbo.Quote_Details.Quote_Detail_No, dbo.Quotes.Quote_id, dbo.Quotes.Quote_no, dbo.Quotes.Quote_name, dbo.Quotes.Quote_description, dbo.Quotes.Address1, dbo.Quotes.Address2, dbo.Quotes.City, 
        dbo.Quotes.State_id, dbo.State_LKUP.State_name, dbo.State_LKUP.State_code, dbo.Quotes.Zip, dbo.Quotes.Country_id, dbo.Country_LKUP.Country_name, 
        dbo.Quotes.Phone, dbo.Quotes.Mobile, dbo.Quotes.Fax, dbo.Quotes.Email,dbo.Quotes.Quoted_date, dbo.Quote_Details.Floor, dbo.Quote_Details.Template_type_id, dbo.Template_Type_LKUP.Template_type_description, 
        dbo.Quote_Details.Construction_type_id, dbo.Construction_Type_LKUP.Construction_type_description, dbo.Quote_Details.Sink_type_id, dbo.Sink_Type_LKUP.Sink_type_description, dbo.Quote_Details.No_of_Sink, 
        dbo.Quote_Details.Back_splash, dbo.Quote_Details.Back_splash_details,dbo.Quote_Details.Mill_down, dbo.Quote_Details.Mill_down_details, dbo.Quote_Details.Stove_type_id, dbo.Stove_Type_LKUP.Stove_type_description, dbo.Quote_Details.Faucet_type_id, 
        dbo.Faucet_Type_LKUP.Faucet_type_description, dbo.Quote_Details.Edge_type_id, dbo.Edge_Type_LKUP.Edge_type_description,  dbo.Edge_Type_LKUP.Edge_type_file, dbo.Quote_Details.Edge_type_details , 
        dbo.Quote_Details.Cutouts, dbo.Quote_Details.Cutouts_quantity,dbo.Quote_Details.Top_Removal,
        dbo.Quote_Details.Material_id, dbo.Materials.Material_name, dbo.Quote_Details.Thickness_id, dbo.Thickness_LKUP.Thickness_description, 
        dbo.Quote_Details.Comments,  dbo.Quote_Detail_File.Quote_file_mime, dbo.Quote_Detail_File.Quote_file_name, dbo.Quote_Detail_File.Quote_file, 
        dbo.Quote_Detail_File.Estimate_file_mime, dbo.Quote_Detail_File.Estimate_file_name, dbo.Quote_Detail_File.Estimate_file, 
		dbo.view_created_by.User_id, dbo.view_requested_by.Requested_by, dbo.view_created_by.Created_by, 
        dbo.Quotes.Created_date, dbo.view_modified_by.Modified_by, dbo.Quotes.Modified_date,dbo.view_all_accounts_by_user.Account_name
FROM    dbo.Quotes 
		LEFT OUTER JOIN dbo.Quote_Details ON dbo.Quotes.Quote_id = dbo.Quote_Details.Quote_id
		LEFT OUTER JOIN dbo.Construction_Type_LKUP ON dbo.Quote_Details.Construction_type_id = dbo.Construction_Type_LKUP.Construction_type_id
		LEFT OUTER JOIN dbo.Template_Type_LKUP ON dbo.Quote_Details.Template_type_id = dbo.Template_Type_LKUP.Template_type_id
		LEFT OUTER JOIN dbo.Sink_Type_LKUP ON dbo.Quote_Details.Sink_type_id = dbo.Sink_Type_LKUP.Sink_type_id
		LEFT OUTER JOIN dbo.Stove_Type_LKUP ON dbo.Quote_Details.Stove_type_id = dbo.Stove_Type_LKUP.Stove_type_id
		LEFT OUTER JOIN dbo.Faucet_Type_LKUP ON dbo.Quote_Details.Faucet_type_id = dbo.Faucet_Type_LKUP.Faucet_type_id
		LEFT OUTER JOIN dbo.Edge_Type_LKUP ON dbo.Quote_Details.Edge_type_id = dbo.Edge_Type_LKUP.Edge_type_id
		LEFT OUTER JOIN dbo.Thickness_LKUP ON dbo.Quote_Details.Thickness_id = dbo.Thickness_LKUP.Thickness_id
		LEFT OUTER JOIN dbo.Materials ON dbo.Quote_Details.Material_id = dbo.Materials.Material_id
		LEFT OUTER JOIN dbo.view_requested_by ON dbo.Quotes.Requested_by = dbo.view_requested_by.Requested_by_id 
		LEFT OUTER JOIN dbo.view_modified_by ON dbo.Quotes.Modified_by = dbo.view_modified_by.User_id 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.Quotes.Created_by = dbo.view_created_by.User_id 
		LEFT OUTER JOIN dbo.Country_LKUP ON dbo.Quotes.Country_id = dbo.Country_LKUP.Country_id 
		LEFT OUTER JOIN dbo.State_LKUP ON dbo.Quotes.State_id = dbo.State_LKUP.State_id
		LEFT OUTER JOIN dbo.Quote_Detail_File ON dbo.Quote_Detail_File.Quote_detail_id = dbo.Quote_Details.Quote_detail_id
		LEFT OUTER JOIN dbo.view_all_accounts_by_user ON dbo.view_requested_by.Requested_by_id = dbo.view_all_accounts_by_user.User_id
GO
 
/****** Object:  View dbo.view_all_projects    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_projects') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_projects
GO

CREATE VIEW dbo.view_all_projects
AS
SELECT	dbo.Projects.Project_id,dbo.Projects.Project_name, dbo.Projects.Project_description, dbo.Projects.Address1, dbo.Projects.Address2, dbo.Projects.City, 
        dbo.Projects.State_id, dbo.State_LKUP.State_name, dbo.State_LKUP.State_code, dbo.Projects.Zip, dbo.Projects.Country_id, dbo.Country_LKUP.Country_name, 
        dbo.Projects.Phone, dbo.Projects.Mobile, dbo.Projects.Fax, dbo.Projects.Email, dbo.view_created_by.Created_by, 
        dbo.Projects.Created_date,  dbo.view_modified_by.Modified_by, dbo.Projects.Modified_date
FROM    dbo.Projects 
		LEFT OUTER JOIN dbo.view_modified_by ON dbo.Projects.Modified_by = dbo.view_modified_by.User_id 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.Projects.Created_by = dbo.view_created_by.User_id 
		LEFT OUTER JOIN dbo.Country_LKUP ON dbo.Projects.Country_id = dbo.Country_LKUP.Country_id 
		LEFT OUTER JOIN dbo.State_LKUP ON dbo.Projects.State_id = dbo.State_LKUP.State_id
GO

/****** Object:  View dbo.view_all_customers    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_customers') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_customers
GO

CREATE VIEW dbo.view_all_customers
AS
SELECT	dbo.Customers.Customer_id,dbo.Customers.First_name, dbo.Customers.Last_name, dbo.Customers.Address1, dbo.Customers.Address2, dbo.Customers.City, 
        dbo.Customers.State_id, dbo.State_LKUP.State_name, dbo.State_LKUP.State_code, dbo.Customers.Zip, dbo.Customers.Country_id, dbo.Country_LKUP.Country_name, 
        dbo.Customers.Phone, dbo.Customers.Mobile, dbo.Customers.Fax, dbo.Customers.Email, dbo.view_created_by.Created_by, 
        dbo.Customers.Created_date,  dbo.view_modified_by.Modified_by, dbo.Customers.Modified_date
FROM    dbo.Customers 
		LEFT OUTER JOIN dbo.view_modified_by ON dbo.Customers.Modified_by = dbo.view_modified_by.User_id 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.Customers.Created_by = dbo.view_created_by.User_id 
		LEFT OUTER JOIN dbo.Country_LKUP ON dbo.Customers.Country_id = dbo.Country_LKUP.Country_id 
		LEFT OUTER JOIN dbo.State_LKUP ON dbo.Customers.State_id = dbo.State_LKUP.State_id
GO

/****** Object:  View dbo.view_all_materials    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_materials') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_materials
GO

CREATE VIEW dbo.view_all_materials
AS		
SELECT	dbo.Materials.Material_id, dbo.Materials.Material_name, dbo.Materials.Material_color, dbo.Materials.Material_code_number, 
        dbo.Materials.Material_type_id, dbo.Material_Type_LKUP.Material_type_description, dbo.Materials.Material_description, dbo.Materials.File_type_id, 
        dbo.File_Type_LKUP.File_type_description, dbo.Materials.File_location, dbo.Materials.Country_id, dbo.Country_LKUP.Country_name, 
        dbo.view_created_by.Created_by, dbo.Materials.Created_date, dbo.view_modified_by.Modified_by, dbo.Materials.Modified_date
FROM    dbo.Materials 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.Materials.Created_by = dbo.view_created_by.User_id 
		LEFT OUTER JOIN dbo.view_modified_by ON dbo.Materials.Modified_by = dbo.view_modified_by.User_id 
		LEFT OUTER JOIN dbo.Country_LKUP ON dbo.Materials.Country_id = dbo.Country_LKUP.Country_id 
		LEFT OUTER JOIN dbo.File_Type_LKUP ON dbo.Materials.File_type_id = dbo.File_Type_LKUP.File_type_id 
		LEFT OUTER JOIN dbo.Material_Type_LKUP ON dbo.Materials.Material_type_id = dbo.Material_Type_LKUP.Material_type_id
GO            


/****** Object:  View dbo.view_all_estimates    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_estimates') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_estimates
GO

CREATE VIEW dbo.view_all_estimates
AS
SELECT	dbo.Estimates.Estimate_id, dbo.Estimates.Estimate_number, dbo.Estimates.Account_id, dbo.view_all_accounts.Account_name, 
		dbo.Estimates.Customer_id, (dbo.view_all_customers.First_name + ' ' + dbo.view_all_customers.Last_name) AS Customer_name, dbo.Estimates.Supplier_id, 
		dbo.view_all_suppliers.Supplier_name, dbo.Estimates.Material_id, dbo.view_all_materials.Material_name, dbo.Estimates.Edge_type_id, 
		dbo.Edge_Type_LKUP.Edge_type_description, dbo.Estimates.Thickness_id, dbo.Thickness_LKUP.Thickness_description, dbo.Estimates.Square_feet, 
		dbo.Estimates.Price_per_sq_ft, dbo.Estimates.Estimate_Status, dbo.view_created_by.Created_by, dbo.Estimates.Created_date, 
		dbo.view_modified_by.Modified_by, dbo.Estimates.Modified_date
FROM    dbo.Estimates 
		INNER JOIN dbo.Edge_Type_LKUP ON dbo.Estimates.Edge_type_id = dbo.Edge_Type_LKUP.Edge_type_id 
		LEFT OUTER JOIN dbo.view_all_suppliers ON dbo.Estimates.Supplier_id = dbo.view_all_suppliers.Supplier_id 
		LEFT OUTER JOIN dbo.view_all_materials ON dbo.Estimates.Material_id = dbo.view_all_materials.Material_id 
		LEFT OUTER JOIN dbo.Thickness_LKUP ON dbo.Estimates.Thickness_id = dbo.Thickness_LKUP.Thickness_id 
		LEFT OUTER JOIN dbo.view_modified_by ON dbo.Estimates.Modified_by = dbo.view_modified_by.User_id 
		LEFT OUTER JOIN dbo.view_created_by ON dbo.Estimates.Created_by = dbo.view_created_by.User_id 
		LEFT OUTER JOIN dbo.view_all_customers ON dbo.Estimates.Customer_id = dbo.view_all_customers.Customer_id 
		LEFT OUTER JOIN dbo.view_all_accounts ON dbo.Estimates.Account_id = dbo.view_all_accounts.Account_id         
GO

/****** Object:  View dbo.view_all_work_orders    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_work_orders') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_work_orders
GO

CREATE VIEW dbo.view_all_work_orders
AS
SELECT	  dbo.Work_Orders.Work_Order_id, dbo.Work_Orders.Work_order_number, dbo.Work_Orders.Purchase_order_number, dbo.Work_Orders.Purchase_order_date,
		  dbo.Work_Orders.Requested_start_date, dbo.Work_Orders.Template, dbo.Work_Orders.Fabrication, dbo.Work_Orders.Installation, dbo.Work_Orders.Repair, 
          dbo.Work_Order_Details.Floor,dbo.Work_Order_Details.Construction_type_id, dbo.Construction_Type_LKUP.Construction_type_description, dbo.Work_Order_Details.Template_type_id,
          dbo.Work_Order_Details.No_of_sink, dbo.Work_Order_Details.Material_id,  dbo.Materials.Material_name , dbo.Work_Order_Details.Sink_type_id, 
          dbo.Sink_Type_LKUP.Sink_type_description, dbo.Work_Order_Details.Sink_status_id, dbo.Sink_Status_LKUP.Sink_status_description, 
          dbo.Work_Order_Details.Stove_type_id, dbo.Stove_Type_LKUP.Stove_type_description, dbo.Work_Order_Details.Edge_type_id, 
          dbo.Edge_Type_LKUP.Edge_type_description, dbo.Work_Order_Details.Faucet_status_id, dbo.Faucet_Status_LKUP.Faucet_status_description, 
          dbo.Work_Order_Details.Back_splash, dbo.Work_Order_Details.Back_splash_details, dbo.Work_Order_Details.Mill_down, 
          dbo.Work_Order_Details.Mill_down_details, dbo.Work_Order_Details.Cutouts, dbo.Work_Order_Details.Faucet_type_id, 
          dbo.Faucet_Type_LKUP.Faucet_type_description, dbo.Work_Orders.Quote_detail_id, dbo.Work_Order_Details.Edge_type_details,
          dbo.Work_Order_Details.Cutouts_quantity, dbo.Work_Order_Details.Top_removal, dbo.Work_Order_Details.Thickness_id, 
          dbo.Thickness_LKUP.Thickness_description, dbo.Work_Order_Details.Kitchen_island, dbo.Work_Order_Details.Cabinets, 
          dbo.Template_Type_LKUP.Template_type_description, dbo.view_all_quotes.Quote_Detail_No, dbo.view_all_quotes.Quote_id, dbo.view_all_quotes.Quote_no, dbo.view_all_quotes.Edge_type_file, 
          dbo.view_all_quotes.Quote_name, dbo.view_all_quotes.Quote_description, dbo.view_all_quotes.Address1, dbo.view_all_quotes.Address2, 
          dbo.view_all_quotes.City, dbo.view_all_quotes.State_id, dbo.view_all_quotes.State_name, dbo.view_all_quotes.State_code, dbo.view_all_quotes.Zip, 
          dbo.view_all_quotes.Country_id, dbo.view_all_quotes.Country_name, dbo.view_all_quotes.Phone, dbo.view_all_quotes.Mobile, 
          dbo.view_all_quotes.Fax, dbo.view_all_quotes.Email, dbo.view_all_quotes.Quoted_date, dbo.view_all_quotes.Comments,                       
          dbo.Work_Orders.Service_completed, dbo.Work_Orders.Service_completed_date, dbo.Work_Orders.Work_order_comments, 
          dbo.view_created_by.Created_by, dbo.Work_Orders.Created_date, dbo.view_modified_by.Modified_by, dbo.Work_Orders.Modified_date,
          dbo.view_all_accounts_by_user.Account_name, dbo.view_created_by.User_id
FROM      dbo.Work_Orders 
			INNER JOIN dbo.Work_Order_Details ON dbo.Work_Orders.Work_Order_id = dbo.Work_Order_Details.Work_Order_id 
			LEFT OUTER JOIN dbo.Template_Type_LKUP ON dbo.Work_Order_Details.Template_type_id = dbo.Template_Type_LKUP.Template_type_id 
			LEFT OUTER JOIN dbo.Construction_Type_LKUP ON dbo.Work_Order_Details.Construction_type_id = dbo.Construction_Type_LKUP.Construction_type_id 
			LEFT OUTER JOIN dbo.view_modified_by ON dbo.Work_Orders.Modified_by = dbo.view_modified_by.User_id 
			LEFT OUTER JOIN dbo.view_created_by ON dbo.Work_Orders.Created_by = dbo.view_created_by.User_id 
			LEFT OUTER JOIN dbo.view_all_quotes ON dbo.Work_Orders.Quote_detail_id = dbo.view_all_quotes.Quote_detail_id 
			LEFT OUTER JOIN dbo.Thickness_LKUP ON dbo.Work_Order_Details.Thickness_id = dbo.Thickness_LKUP.Thickness_id 
			LEFT OUTER JOIN dbo.Faucet_Type_LKUP ON dbo.Work_Order_Details.Faucet_type_id = dbo.Faucet_Type_LKUP.Faucet_type_id 
			LEFT OUTER JOIN dbo.Faucet_Status_LKUP ON dbo.Work_Order_Details.Faucet_status_id = dbo.Faucet_Status_LKUP.Faucet_status_id 
			LEFT OUTER JOIN dbo.Edge_Type_LKUP ON dbo.Work_Order_Details.Edge_type_id = dbo.Edge_Type_LKUP.Edge_type_id 
			LEFT OUTER JOIN dbo.Sink_Type_LKUP ON dbo.Work_Order_Details.Sink_type_id = dbo.Sink_Type_LKUP.Sink_type_id 
			LEFT OUTER JOIN dbo.Sink_Status_LKUP ON dbo.Work_Order_Details.Sink_status_id = dbo.Sink_Status_LKUP.Sink_status_id 
			LEFT OUTER JOIN dbo.Stove_Type_LKUP ON dbo.Work_Order_Details.Stove_type_id = dbo.Stove_Type_LKUP.Stove_type_id
			LEFT OUTER JOIN dbo.Materials  ON dbo.Work_Order_Details.Material_id = dbo.Materials.Material_id 
			LEFT OUTER JOIN dbo.view_all_accounts_by_user ON dbo.Work_Orders.Created_by = dbo.view_all_accounts_by_user.User_id
GO                      		

/****** Object:  View dbo.view_all_materials_by_work_order    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_materials_by_work_order') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_materials_by_work_order
GO

CREATE VIEW dbo.view_all_materials_by_work_order
AS
SELECT	  dbo.view_all_materials.Material_id, dbo.view_all_materials.Material_name, dbo.view_all_materials.Material_color, 
		  dbo.view_all_materials.Material_code_number, dbo.view_all_materials.Material_type_id, dbo.view_all_materials.Material_type_description, 
		  dbo.view_all_materials.Material_description, dbo.view_all_materials.File_type_id, dbo.view_all_materials.File_type_description, 
		  dbo.view_all_materials.Country_id, dbo.view_all_materials.Country_name, dbo.Work_Order_Details.Work_Order_id
FROM      dbo.view_all_materials 
		  INNER JOIN dbo.Work_Order_Details ON dbo.view_all_materials.Material_id = dbo.Work_Order_Details.Material_id
GO                       

/****** Object:  View dbo.view_all_work_order_templates    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.view_all_work_order_templates') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view dbo.view_all_work_order_templates
GO

CREATE VIEW dbo.view_all_work_order_templates
AS
SELECT	  dbo.view_all_work_orders.Work_Order_id, dbo.view_all_work_orders.Work_order_number,		  
          dbo.view_all_work_orders.Template_type_id, dbo.view_all_work_orders.Template_type_description, 
          dbo.view_all_work_orders.Quote_Detail_No, dbo.view_all_work_orders.Quote_id, dbo.view_all_work_orders.Quote_no, 
          dbo.view_all_work_orders.Quote_name, dbo.view_all_work_orders.Quote_description, 
          dbo.view_all_work_orders.Address1, dbo.view_all_work_orders.Address2, dbo.view_all_work_orders.City, dbo.view_all_work_orders.State_id, 
          dbo.view_all_work_orders.State_name, dbo.view_all_work_orders.State_code, dbo.view_all_work_orders.Zip, dbo.view_all_work_orders.Country_id, 
          dbo.view_all_work_orders.Country_name, dbo.view_all_work_orders.Phone, dbo.view_all_work_orders.Mobile, dbo.view_all_work_orders.Fax, 
          dbo.view_all_work_orders.Email, dbo.view_all_work_orders.Quoted_date, dbo.view_all_work_orders.Comments, 
          dbo.view_all_work_orders.Service_completed, dbo.view_all_work_orders.Service_completed_date, dbo.view_all_work_orders.Work_order_comments, 
          dbo.view_all_work_orders.Created_by, dbo.view_all_work_orders.Created_date, dbo.view_all_work_orders.Modified_by, 
          dbo.view_all_work_orders.Modified_date, dbo.view_all_work_orders.Account_name, dbo.view_all_work_orders.User_id, 
          dbo.Work_Order_Templates.Time_slot_id, dbo.Time_Slot_LKUP.Time_Slot_description, dbo.Work_Order_Templates.Template_date, 
          dbo.Work_Order_Templates.Estimate_sqft, dbo.Work_Order_Templates.Actual_sqft, dbo.Work_Order_Templates.Template_completed, 
          dbo.Work_Order_Templates.Verified_date, dbo.Work_Order_Templates.Template_accepted, dbo.view_template_by.Template_by_id, 
          dbo.view_template_by.Template_by, dbo.view_verified_by.Verified_by_id, dbo.view_verified_by.Verified_by
FROM      dbo.view_all_work_orders 
		  LEFT OUTER JOIN dbo.Work_Order_Templates ON dbo.view_all_work_orders.Work_Order_id = dbo.Work_Order_Templates.Work_order_id 
		  LEFT OUTER JOIN dbo.view_verified_by ON dbo.Work_Order_Templates.Verified_by = dbo.view_verified_by.Verified_by_id 
		  LEFT OUTER JOIN dbo.view_template_by ON dbo.Work_Order_Templates.Template_by = dbo.view_template_by.Template_by_id 
		  LEFT OUTER JOIN dbo.Time_Slot_LKUP ON dbo.Work_Order_Templates.Time_slot_id = dbo.Time_Slot_LKUP.Time_Slot_id
GO                      