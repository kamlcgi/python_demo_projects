

/****** Script: Create All LookUp Table Stored Procedures - PAvaniStone_db_xx	******/
/****** Author: Sreenivasan Subbanchattiar		******/
/****** Script Created By: Sreenivasan Subbanchattiar   	******/
/****** Script Created Date: 7/20/2011 			******/
/****** Script Modified By: Sreenivasan Subbanchattiar		******/
/****** Script Modified Date: 7/20/2011 	  		******/
/****** Script Version: 1.0  				******/


/****** Object:Stored Procedure   dbo.sp_get_all_users_lkup    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_users_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_users_lkup
GO

CREATE procedure dbo.sp_get_all_users_lkup
AS
begin

 SELECT User_id, (Last_name + ', ' + First_name) AS First_name FROM  dbo.view_all_users ORDER BY Last_name

end
GO

/****** Object:Stored Procedure   dbo.sp_get_all_templator_lkup    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_templator_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_templator_lkup
GO

CREATE procedure dbo.sp_get_all_templator_lkup
AS
begin

 SELECT * FROM  dbo.view_template_by

end
GO


/****** Object:Stored Procedure   dbo.sp_get_all_fabricator_lkup    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_fabricator_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_fabricator_lkup
GO

CREATE procedure dbo.sp_get_all_fabricator_lkup
AS
begin

 SELECT * FROM  dbo.view_fabrication_by

end
GO



/****** Object:Stored Procedure   dbo.sp_get_all_users_not_in_account_lkup    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_users_not_in_account_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_users_not_in_account_lkup
GO

CREATE procedure dbo.sp_get_all_users_not_in_account_lkup
					@Account_id as Varchar(20)
AS
begin

 SELECT User_id, (Last_name + ', ' + First_name) AS First_name FROM  dbo.view_all_users WHERE User_id NOT IN (SELECT User_id FROM dbo.Accounts_X_Users WHERE Account_id=@Account_id)  ORDER BY Last_name

end
GO

/****** Object:Stored Procedure   dbo.sp_get_all_accounts_lkup    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_accounts_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_accounts_lkup
GO

CREATE procedure dbo.sp_get_all_accounts_lkup
AS
begin

 SELECT Account_id, (Account_name + ' - ' + City + ' - ' + State_code) AS Account_name FROM  dbo.view_all_accounts  ORDER BY Account_name 

end
GO


/****** Object:Stored Procedure   dbo.sp_get_all_suppliers_lkup    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_suppliers_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_suppliers_lkup
GO

CREATE procedure dbo.sp_get_all_suppliers_lkup
AS
begin

 SELECT Supplier_id, (Supplier_name + ' - ' + City + ' - ' + State_code) AS Supplier_name FROM  dbo.view_all_suppliers  ORDER BY Supplier_name  

end
GO


/****** Object:Stored Procedure   dbo.sp_get_all_customers_lkup    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_customers_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_customers_lkup
GO

CREATE procedure dbo.sp_get_all_customers_lkup
AS
begin

 SELECT Customer_id, (Last_name + ', ' + First_name + ' - ' + City + ' - ' + State_code) AS Customer_name FROM  dbo.view_all_customers  ORDER BY Last_name  

end
GO

/****** Object:Stored Procedure   dbo.sp_get_all_materials_lkup    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_materials_lkup') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_materials_lkup
GO

CREATE procedure dbo.sp_get_all_materials_lkup
AS
begin

 SELECT Material_id, (Material_name + ' - ' + Material_code_number) AS Material_name FROM  dbo.view_all_materials  ORDER BY Material_name 

end
GO

/****** Object:Stored Procedure   dbo.sp_get_all_edge_type    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_edge_type') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_edge_type
GO

CREATE procedure dbo.sp_get_all_edge_type
AS
begin

 SELECT * FROM  dbo.Edge_Type_LKUP

end
GO


/****** Object:Stored Procedure   dbo.sp_get_all_construction_type    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_construction_type') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_construction_type
GO

CREATE procedure dbo.sp_get_all_construction_type
AS
begin

 SELECT * FROM  dbo.Construction_Type_LKUP

end
GO

/****** Object:Stored Procedure   dbo.sp_get_all_faucet_type   Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_faucet_type') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_faucet_type
GO

CREATE procedure dbo.sp_get_all_faucet_type
AS
begin

 SELECT * FROM  dbo.Faucet_Type_LKUP

end
GO

/****** Object:Stored Procedure   dbo.sp_get_all_faucet_status   Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_faucet_status') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_faucet_status
GO

CREATE procedure dbo.sp_get_all_faucet_status
AS
begin

 SELECT * FROM  dbo.Faucet_Status_LKUP

end
GO

/****** Object:Stored Procedure   dbo.sp_get_all_sink_status   Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_sink_status') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_sink_status
GO

CREATE procedure dbo.sp_get_all_sink_status
AS
begin

 SELECT * FROM  dbo.Sink_Status_LKUP

end
GO


/****** Object:Stored Procedure   dbo.sp_get_all_sink_type   Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_sink_type') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_sink_type
GO

CREATE procedure dbo.sp_get_all_sink_type
AS
begin

 SELECT * FROM  dbo.Sink_Type_LKUP

end
GO


/****** Object:Stored Procedure   dbo.sp_get_all_thickness   Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_thickness') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_thickness
GO

CREATE procedure dbo.sp_get_all_thickness
AS
begin

 SELECT * FROM  dbo.Thickness_LKUP

end
GO


/****** Object:Stored Procedure   dbo.sp_get_all_stove_type  Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_stove_type') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_stove_type
GO

CREATE procedure dbo.sp_get_all_stove_type
AS
begin

 SELECT * FROM  dbo.Stove_Type_LKUP

end
GO


/****** Object:Stored Procedure   dbo.sp_get_all_template_type  Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_template_type') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_template_type
GO

CREATE procedure dbo.sp_get_all_template_type
AS
begin

 SELECT * FROM  dbo.Template_Type_LKUP

end
GO


/****** Object:Stored Procedure   dbo.sp_get_all_time_slot  Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_time_slot') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_time_slot
GO

CREATE procedure dbo.sp_get_all_time_slot
AS
begin

 SELECT * FROM  dbo.Time_Slot_LKUP

end
GO


/****** Object:Stored Procedure   dbo.sp_get_all_material_type  Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_material_type') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_material_type
GO

CREATE procedure dbo.sp_get_all_material_type
AS
begin

 SELECT * FROM  dbo.Material_Type_LKUP

end
GO


/****** Object:Stored Procedure   dbo.sp_get_all_file_type  Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_file_type') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_file_type
GO

CREATE procedure dbo.sp_get_all_file_type
AS
begin

 SELECT * FROM  dbo.File_Type_LKUP

end
GO