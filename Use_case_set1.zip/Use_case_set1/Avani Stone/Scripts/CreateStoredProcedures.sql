

/****** Script: New/Update/Delete PAvaniStone_db_xx	******/
/****** Author: Sreenivasan Subbanchattiar		******/
/****** Script Created By: Sreenivasan Subbanchattiar   	******/
/****** Script Created Date: 7/20/2011 			******/
/****** Script Modified By: Sreenivasan Subbanchattiar		******/
/****** Script Modified Date: 7/20/2011 	  		******/
/****** Script Version: 1.0  				******/

/****** Object:Stored Procedure dbo.sp_new_user_id    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_new_user_id') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_new_user_id
GO

CREATE procedure dbo.sp_new_user_id @new_id as varchar(20) output
as
begin

 select @new_id=(PAL_id + right('0' + cast(datepart(Mm,getdate()) as varchar(2)),2) + right('0' + cast(datepart(dd,getdate()) as varchar(2)),2) + right(cast(datepart(Yy,getdate()) as varchar(4)),2)+ CAST(User_id as varchar(10))) from PAL_identifiers
           
 update PAL_identifiers set User_id=User_id+1
  
end
GO

/****** Object:Stored Procedure dbo.sp_new_address_id Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_new_address_id') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_new_address_id
GO

CREATE procedure dbo.sp_new_address_id  @new_id as varchar(20) output
as
begin

 select @new_id=(PAL_id + right('0' + cast(datepart(Mm,getdate()) as varchar(2)),2) + right('0' + cast(datepart(dd,getdate()) as varchar(2)),2) + right(cast(datepart(Yy,getdate()) as varchar(4)),2)+ CAST(Address_id   as varchar(10))) from PAL_identifiers
           
 update PAL_identifiers set Address_id =Address_id  +1
  
end
GO


/****** Object:Stored Procedure   dbo.sp_validate_user    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_validate_user') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_validate_user
GO

CREATE procedure dbo.sp_validate_user
                @user_name as varchar(50),
                @password as varchar(50)
AS
begin
  
   SELECT * FROM  dbo.view_all_users WHERE User_name=@user_name AND Passwd=@password  

end
GO 

/****** Object:Stored Procedure   dbo.sp_get_all_country    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_country') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_country
GO

CREATE procedure dbo.sp_get_all_country
AS
begin

 SELECT * FROM  dbo.view_all_country

end
GO 

/****** Object:Stored Procedure   dbo.sp_get_all_state_by_country    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_state_by_country') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_state_by_country
GO

CREATE procedure dbo.sp_get_all_state_by_country
                @country_id as int
AS
begin
  
   SELECT * FROM  dbo.view_all_states_by_country WHERE Country_id = @country_id

end
GO 

/****** Object:Stored Procedure   dbo.sp_get_all_roles    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_roles') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_roles
GO

CREATE procedure dbo.sp_get_all_roles
AS
begin

 SELECT * FROM  dbo.view_all_roles

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_all_pages    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_pages') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_pages
GO

CREATE procedure dbo.sp_get_all_pages
AS
begin

 SELECT * FROM  dbo.view_all_pages

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_all_parent_pages    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_parent_pages') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_parent_pages
GO

CREATE procedure dbo.sp_get_all_parent_pages
AS
begin

 SELECT * FROM  dbo.view_all_pages WHERE Parent_Page_id = 0 ORDER BY Page_title

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_role    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_role') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure  dbo.sp_get_role
GO

CREATE procedure  dbo.sp_get_role
        @role_id as int
AS
begin
  
  SELECT * FROM  dbo.view_all_roles  WHERE role_id = @role_id 
  
 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_page    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_page') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure  dbo.sp_get_page
GO

CREATE procedure  dbo.sp_get_page
        @page_id as int
AS
begin
  
  SELECT * FROM  dbo.view_all_pages  WHERE page_id = @page_id 
  
 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_all_pages_by_role    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_pages_by_role') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure  dbo.sp_get_all_pages_by_role
GO

CREATE procedure  dbo.sp_get_all_pages_by_role
        @role_id as int
AS
begin
  
  SELECT * FROM  dbo.view_all_pages_by_role  WHERE role_id = @role_id 
  
 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_all_pages_not_in_role    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_pages_not_in_role') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure  dbo.sp_get_all_pages_not_in_role
GO

CREATE procedure  dbo.sp_get_all_pages_not_in_role
        @role_id as int
AS
begin
  
  SELECT * FROM dbo.view_all_pages WHERE page_id NOT IN (SELECT page_id FROM  dbo.view_all_pages_by_role  WHERE role_id = @role_id ) ORDER BY Page_title
  
 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_user_by_id    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_user_by_id') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_user_by_id
GO

CREATE procedure dbo.sp_get_user_by_id
        @user_id as varchar(50)
AS
begin
 
 SELECT * FROM  dbo.view_all_users WHERE User_Id=@user_id  

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_all_users    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_users') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_users
GO

CREATE procedure dbo.sp_get_all_users 
AS
begin

  SELECT * FROM  dbo.view_all_users
  
end
GO

/****** Object:Stored Procedure   dbo.sp_get_all_user_logs    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_user_logs') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_user_logs
GO

CREATE procedure dbo.sp_get_all_user_logs 
AS
begin

  SELECT * FROM  dbo.view_all_user_logs ORDER BY Log_date DESC 
  
end
GO

/****** Object:Stored Procedure   dbo.sp_get_all_users_by_role    Script Date: 02/17/2006  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_users_by_role') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_users_by_role
GO

CREATE procedure dbo.sp_get_all_users_by_role
		@role_id as int,
        @sort_by as varchar(100)
AS
begin
  Declare @cmd as Varchar(2000)
  
	  if  @sort_by = 'Null'
		  set  @sort_by = 'Sort_index' 

	   SET @cmd = 'SELECT * FROM  dbo.view_all_users  WHERE role_id = ' + cast(@role_id as varchar(3))  + ' ORDER BY ' + @sort_by
  
  EXEC(@cmd)

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_all_main_menu_items_by_role_id    Script Date: 02/17/2006  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_main_menu_items_by_role_id') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_main_menu_items_by_role_id
GO

CREATE procedure dbo.sp_get_all_main_menu_items_by_role_id
		@role_id as int        
AS
begin
  
  SELECT * FROM  dbo.view_all_pages_by_role  WHERE Parent_Page_id=0 AND  Role_id = @role_id  ORDER BY Sort_index 
    
end
GO

/****** Object:Stored Procedure   dbo.sp_get_all_sub_menu_items_by_role_id    Script Date: 02/17/2006  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_sub_menu_items_by_role_id') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_sub_menu_items_by_role_id
GO

CREATE procedure dbo.sp_get_all_sub_menu_items_by_role_id
		@role_id as int        
AS
begin
  
  SELECT * FROM  dbo.view_all_pages_by_role  WHERE Parent_Page_id > 0 AND  Role_id = @role_id  ORDER BY Sort_index 
    
end
GO

/****** Object:Stored Procedure   dbo.sp_new_role    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_new_role') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_new_role
GO

CREATE procedure dbo.sp_new_role
    @role_id int,
	@role_name varchar(255),
	@created_by varchar(20)
as
begin

   INSERT INTO dbo.PAL_Role(
		Role_id,
		Role_name ,
		Created_by,
		Created_date,
		Modified_by,
		Modified_date
  )VALUES(
		@role_id,
		@role_name ,
		@created_by,
		GETDATE(),
		@created_by,
		GETDATE()
  )  

end
GO

/****** Object:Stored Procedure   dbo.sp_new_temp_role_page    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_new_temp_role_page') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_new_temp_role_page
GO

CREATE procedure dbo.sp_new_temp_role_page(
						@role_id int,
						@page_id int,
						@sort_index int,
						@allow_view char(1),
						@allow_modify char(1),
						@allow_delete char(1),
						@modified_by varchar(20),
						@retval int OUTPUT)
as
begin

	INSERT INTO dbo.T_PAL_Role_X_PAL_Page(
	    role_id ,
		page_id ,
		sort_index ,
		allow_view ,
		allow_modify ,
		allow_delete ,
		modified_by  
	)VALUES(
		@role_id,
		@page_id ,
		@sort_index ,
		@allow_view,
		@allow_modify ,
		@allow_delete,
		@modified_by  
	)  
	
	set @retval = 0
    return  

end
GO


/****** Object:Stored Procedure   dbo.sp_create_role_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_create_role_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_create_role_wiz
GO

create procedure dbo.sp_create_role_wiz( 
		@role_name varchar(255),
		@created_by varchar(20),
		@retval int OUTPUT)
as
begin
 
 declare @role_id int
 
 SELECT @role_id=MAX(role_id)+1 FROM dbo.PAL_Role
 
begin tran
		
	exec dbo.sp_new_role
			 @role_id,
			 @role_name,
			 @created_by			
    
    INSERT INTO dbo.PAL_Role_X_PAL_Page(
			Role_id,
            Page_id,
            Sort_index,
            Allow_view,
            Allow_modify,
            Allow_delete
    ) SELECT 
			@role_id,
            Page_id,
            Sort_index,
            Allow_view,
            Allow_modify,
            Allow_delete
		FROM	dbo.T_PAL_Role_X_PAL_Page WHERE modified_by=@created_by
	
	DELETE FROM dbo.T_PAL_Role_X_PAL_Page WHERE modified_by=@created_by
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = @role_id
    return  
  
end 
GO

/****** Object:Stored Procedure   dbo.sp_add_page    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_add_page') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_add_page
GO

create procedure dbo.sp_add_page( 
		@role_id int,
		@page_id int,
		@modified_by varchar(20),
		@retval int OUTPUT)
as
begin

begin tran
		
	UPDATE dbo.Pal_Role SET 
			modified_by = @modified_by,
			modified_date = GETDATE() 
	WHERE role_id=@role_id
	   
    INSERT INTO dbo.PAL_Role_X_PAL_Page(
			Role_id,
            Page_id,
            Sort_index,
            Allow_view,
            Allow_modify,
            Allow_delete
    ) VALUES ( 
			@role_id,
            @page_id,
            0,
            '0',
            '0',
            '0'
	)	
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_remove_page    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_remove_page') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_remove_page
GO

create procedure dbo.sp_remove_page( 
		@role_id int,
		@page_id int,
		@modified_by varchar(20),
		@retval int OUTPUT)
as
begin

begin tran
		
	DELETE FROM dbo.PAL_Role_X_PAL_Page WHERE role_id=@role_id AND page_id=@page_id  
    	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
  
end 
GO

/****** Object:Stored Procedure   dbo.sp_update_role_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_update_role_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_update_role_wiz
GO

create procedure dbo.sp_update_role_wiz( 
		@role_id int,
		@role_name varchar(255),
		@modified_by varchar(20),
		@retval int OUTPUT)
as
begin

begin tran
		
	UPDATE dbo.Pal_Role SET 
			role_name = @role_name,
			modified_by = @modified_by,
			modified_date = GETDATE() 
	WHERE role_id=@role_id
	   
    DELETE FROM dbo.PAL_Role_X_PAL_Page WHERE role_id=@role_id
    
    INSERT INTO dbo.PAL_Role_X_PAL_Page(
			Role_id,
            Page_id,
            Sort_index,
            Allow_view,
            Allow_modify,
            Allow_delete
    ) SELECT 
			Role_id,
            Page_id,
            Sort_index,
            Allow_view,
            Allow_modify,
            Allow_delete
		FROM	dbo.T_PAL_Role_X_PAL_Page WHERE modified_by=@modified_by
	
	DELETE FROM dbo.T_PAL_Role_X_PAL_Page WHERE modified_by=@modified_by
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_create_page_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_create_page_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_create_page_wiz
GO

create procedure dbo.sp_create_page_wiz( 
		@parent_page_id int,
		@page_title varchar(50),
		@page_description varchar(255),
		@navigate_url varchar(255),
		@created_by varchar(20),
		@retval int OUTPUT)
as
begin

 declare @page_id as int
 
 SELECT @page_id=MAX(page_id)+1 FROM dbo.PAL_Page

begin tran
	
	INSERT INTO dbo.PAL_Page(
		   Page_id,
		   Parent_Page_id,
		   Page_title,
		   Navigate_url,
		   Page_description,
		   Created_by,
		   Created_date,
		   Modified_by,
		   Modified_date
     )VALUES(
		@page_id,
	    @parent_page_id,
	    @page_title,
	    @navigate_url,
	    @page_description,
	    @created_by,
		GETDATE(),
	    @created_by,
		GETDATE()
     )          	
		
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
  
end 
GO

/****** Object:Stored Procedure   dbo.sp_update_page_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_update_page_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_update_page_wiz
GO

create procedure dbo.sp_update_page_wiz( 
		@page_id int,
		@parent_page_id int,
		@page_title varchar(50),
		@page_description varchar(255),
		@navigate_url varchar(255),
		@modified_by varchar(20),
		@retval int OUTPUT)
as
begin

begin tran
		
	UPDATE  dbo.PAL_Page SET 
			parent_page_id = @parent_page_id,
			page_title = @page_title,
			page_description = @page_description,
			navigate_url = @navigate_url,
			modified_by = @modified_by,
			modified_date = GETDATE() 
	WHERE page_id=@page_id
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_delete_page_wiz    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_delete_page_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_delete_page_wiz
GO

CREATE procedure dbo.sp_delete_page_wiz(
			@page_id int,
			@modified_by varchar(20),
			@retval int OUTPUT)
AS
begin
 
 begin tran
 
  DELETE FROM  dbo.PAL_Role_X_PAL_Page WHERE page_id =@page_id
  
  DELETE FROM  dbo.PAL_Page WHERE page_id =@page_id  
 
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 

/****** Object:Stored Procedure   dbo.sp_delete_role_wiz    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_delete_role_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_delete_role_wiz
GO

CREATE procedure dbo.sp_delete_role_wiz(
			@role_id int,
			@modified_by varchar(20),
			@retval int OUTPUT)
AS
begin

  if @role_id = 1
   begin    
     set @retval = '-2' 
     return 
  end
 
 begin tran
 
 DELETE FROM  dbo.PAL_Role_X_PAL_Page WHERE role_id =@role_id 
 
 DELETE FROM  dbo.PAL_Role WHERE role_id =@role_id  
 
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 

/****** Object:Stored Procedure   dbo.sp_new_page    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_new_page') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_new_page
GO

CREATE procedure dbo.sp_new_page
    @page_id int,
    @parent_Page_id int,
    @page_title varchar(50),
    @navigate_url varchar(50),
    @page_description varchar(255),
	@created_by varchar(10)
as
begin

	INSERT INTO dbo.PAL_Page(
		   Page_id,
		   Parent_Page_id,
           Page_title,
           Navigate_url,
           Page_description,
           Created_by,
           Created_date,
           Modified_by,
           Modified_date   
	)VALUES(
		@page_id,
        @parent_Page_id,
        @page_title,
        @Navigate_url,
        @page_description,
        @created_by,
		GETDATE(),
		@created_by,
		GETDATE()
	)  

end
GO

/****** Object:Stored Procedure   dbo.sp_create_page    Script Date: 07/25/2011 ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_create_page') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_create_page
GO

create procedure dbo.sp_create_page( 
	@parent_Page_id int,
    @page_title varchar(50),
    @navigate_url varchar(50),
    @page_description varchar(255),
	@created_by varchar(10),
	@retval int OUTPUT)
as
begin

declare @page_id int

SELECT @page_id=max(Page_id) FROM dbo.PAL_Page

begin tran

exec dbo.sp_new_page
		@page_id,
        @parent_Page_id,
        @page_title,
        @Navigate_url,
        @page_description,
        @created_by
     
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = @page_id
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_check_url    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_check_url') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_check_url
GO

create procedure dbo.sp_check_url( 
	@role_id int,
    @navigate_url varchar(50),
    @retval int OUTPUT)
as
begin

declare @page_id int

SELECT @page_id=Page_id FROM dbo.view_all_pages_by_role WHERE  Role_id =@role_id and Navigate_url = @navigate_url
     
if @@error <> 0
  begin
     set @retval = -1 
     return 
  end
  
  if @page_id is null
  begin
     set @retval = -2 
     return 
  end
  
  set @retval = @page_id
  return  
  
end 
GO

/****** Object:Stored Procedure   dbo.sp_get_user_permission    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_user_permission') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_user_permission
GO

create procedure dbo.sp_get_user_permission( 
	@role_id int,
    @navigate_url varchar(50))    
as
begin

SELECT * FROM dbo.view_all_pages_by_role WHERE  Role_id =@role_id and Navigate_url = @navigate_url
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_new_address    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_new_address') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_new_address
GO

CREATE procedure dbo.sp_new_address
	@address_id varchar(20),
	@address1 varchar(50),
	@address2 varchar(50),
	@city varchar(50),
	@state_id int,
	@zip varchar(50),
	@country_id int,
	@phone varchar(50),
	@mobile varchar(50),
	@fax varchar(50),
	@email varchar(50)
as
begin

	INSERT INTO dbo.Pal_Address(
			address_id ,
			address1 ,
			address2 ,
			city ,
			state_id,
			zip,
			country_id,
			phone,
			mobile,
			fax,
			email		
	)VALUES(
			@address_id ,
			@address1 ,
			@address2 ,
			@city ,
			@state_id,
			@zip,
			@country_id,
			@phone,
			@mobile,
			@fax,
			@email
	)  

end
GO

/****** Object:Stored Procedure   dbo.sp_new_user    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_new_user') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_new_user
GO

CREATE procedure dbo.sp_new_user
	@user_id varchar(50),
	@user_name varchar(50),
	@password varchar(50),
	@role_id int,
	@address_id varchar(20),
    @first_name varchar(50),
	@last_name varchar(50),
	@created_by varchar(20)
as
begin

	INSERT INTO dbo.PAL_Users(
		User_id,
		User_name,
		Passwd,
		Role_id,
		Active_user, 
		Last_login_date, 
		Address_id, 
		First_name,
		Last_name,		
		Created_by,
        Created_date,
        Modified_by,
        Modified_date   
	)VALUES(
	    @user_id,
		@user_name,
		@password,
		@role_id,
		'1',
		GETDATE(), 
		@address_id, 
		@first_name,
		@last_name,	
		@created_by,
		GETDATE(),
		@created_by,
		GETDATE()
	)  

end
GO


/****** Object:Stored Procedure   dbo.sp_create_user_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_create_user_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_create_user_wiz
GO

create procedure dbo.sp_create_user_wiz( 
	@first_name varchar(50),
	@last_name varchar(50),
	@address1 varchar(50),
	@address2 varchar(50),
	@city varchar(50),
	@state_id int,
	@zip varchar(50),
	@country_id int,
	@phone varchar(50),
	@mobile varchar(50),
	@fax varchar(50),
	@email varchar(50),
	@user_name varchar(50),
	@password varchar(50),
	@role_id int,
	@created_by varchar(20),
	@retval varchar(20) OUTPUT)
as
begin

declare @user_id varchar(20)
declare @address_id varchar(20)

exec dbo.sp_new_user_id @user_id OUTPUT
exec dbo.sp_new_address_id @address_id OUTPUT

begin tran

exec dbo.sp_new_address	
		@address_id ,
		@address1 ,
		@address2 ,
		@city ,
		@state_id,
		@zip,
		@country_id,
		@phone,
		@mobile,
		@fax,
		@email
		
exec dbo.sp_new_user
		@user_id ,
		@user_name,
		@password ,
		@role_id ,
		@address_id,
		@first_name,
		@last_name ,
		@created_by 
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = @user_id
    return  
  
end 
GO



/****** Object:Stored Procedure   dbo.sp_update_address    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_update_address') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_update_address
GO

CREATE procedure dbo.sp_update_address
	@address_id varchar(20),
	@address1 varchar(50),
	@address2 varchar(50),
	@city varchar(50),
	@state_id int,
	@zip varchar(50),
	@country_id int,
	@phone varchar(50),
	@mobile varchar(50),
	@fax varchar(50),
	@email varchar(50)
as
begin

	UPDATE dbo.Pal_Address SET 
			address1 = @address1,
			address2 = @address2,
			city = @city,
			state_id = @state_id,
			zip = @zip,
			country_id = @country_id,
			phone = @phone,
			mobile = @mobile,
			fax = @fax,
			email = @email
	WHERE address_id=@address_id				
	
end
GO

/****** Object:Stored Procedure   dbo.sp_update_user    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_update_user') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_update_user
GO

CREATE procedure dbo.sp_update_user
	@user_id varchar(50),
	@first_name varchar(50),
	@last_name varchar(50),
	@user_name varchar(50),
	@password varchar(50),
	@active_user char(1),
	@role_id int,
	@modified_by varchar(20)
as
begin

	UPDATE dbo.PAL_Users SET
	    user_name=@user_name,		
		First_name = @first_name,
		Last_name =  @last_name,
		active_user=@active_user,		
		role_id=@role_id,
		Modified_by = @modified_by,
        Modified_date = GETDATE()  
	WHERE user_id = @user_id
	
	if @password <> ''
	UPDATE dbo.PAL_Users SET
		   passwd=@password		
	WHERE user_id = @user_id	
	
end
GO


/****** Object:Stored Procedure   dbo.sp_update_user_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_update_user_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_update_user_wiz
GO

create procedure dbo.sp_update_user_wiz( 
	@user_id varchar(20),
	@first_name varchar(50),
	@last_name varchar(50),
	@address1 varchar(50),
	@address2 varchar(50),
	@city varchar(50),
	@state_id int,
	@zip varchar(50),
	@country_id int,
	@phone varchar(50),
	@mobile varchar(50),
	@fax varchar(50),
	@email varchar(50),
	@user_name varchar(50),
	@password varchar(50),
	@active_user char(1),
	@role_id int,	
	@modified_by varchar(20),
	@retval int OUTPUT)
as
begin

declare @address_id varchar(20)

 SELECT @address_id=address_id FROM dbo.PAL_Users WHERE User_id=@user_id 

begin tran

exec dbo.sp_update_address	
		@address_id ,
		@address1 ,
		@address2 ,
		@city ,
		@state_id,
		@zip,
		@country_id,
		@phone,
		@mobile,
		@fax,
		@email
		
exec dbo.sp_update_user
		@user_id ,
		@first_name,
		@last_name ,
		@user_name,
		@password,
		@active_user,
		@role_id,
		@modified_by 
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_change_user_password    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_change_user_password') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_change_user_password
GO

CREATE procedure dbo.sp_change_user_password(
			@user_id varchar(50),
			@password varchar(50),
			@modified_by varchar(20),
			@retval int OUTPUT)
AS
begin

 begin tran
 
	UPDATE dbo.PAL_Users SET
		Passwd = @password,			
		Modified_by = @modified_by,
        Modified_date = GETDATE()  
	WHERE user_id = @user_id
 
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 


/****** Object:Stored Procedure   dbo.sp_delete_user_wiz    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_delete_user_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_delete_user_wiz
GO

CREATE procedure dbo.sp_delete_user_wiz(
			@user_id as varchar(50),
			@modified_by varchar(20),
			@retval int OUTPUT)
AS
begin

 declare @address_id varchar(20)

 SELECT @address_id=address_id FROM dbo.PAL_Users WHERE User_id=@user_id 
 
 begin tran
 
 DELETE FROM  dbo.Pal_Address WHERE address_id=@address_id 
 
 DELETE FROM  dbo.PAL_Users WHERE User_Id=@user_id  
 
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 

/****** Object:Stored Procedure   dbo.sp_create_user_log    Script Date: 02/17/2006  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_create_user_log') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_create_user_log
GO

CREATE procedure dbo.sp_create_user_log(
		@IP_address as varchar(50),
		@Browser  varchar(500),
		@Log_data varchar(2000) ,
		@Log_by varchar(20) ,	
		@retval int OUTPUT)
AS
begin
begin tran

  INSERT INTO dbo.PAL_Users_Log(
		IP_address ,
		Browser,
		Log_data ,
		Log_by,
		Log_date
  )Values(
		@IP_address ,
		@Browser ,
		@Log_data ,
		@Log_by ,	
        getDate()
  )
    
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
        
end
GO 


/****** Object:Stored Procedure   dbo.sp_clear_user_log    Script Date: 02/17/2006  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_clear_user_log') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_clear_user_log
GO

CREATE procedure dbo.sp_clear_user_log(
		@retval int OUTPUT)
AS
begin

  DELETE FROM dbo.PAL_Users_Log

  set @retval = 0
  return  
        
end
GO 
