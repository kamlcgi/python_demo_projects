

/****** Script: New/Update/Delete quotes - PAvaniStone_db_xx	******/
/****** Author: Sreenivasan Subbanchattiar		******/
/****** Script Created By: Sreenivasan Subbanchattiar   	******/
/****** Script Created Date: 7/20/2011 			******/
/****** Script Modified By: Sreenivasan Subbanchattiar		******/
/****** Script Modified Date: 7/20/2011 	  		******/
/****** Script Version: 1.0  				******/


/****** Object:Stored Procedure dbo.sp_new_quote_id    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_new_quote_id') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_new_quote_id
GO

CREATE procedure dbo.sp_new_quote_id @new_id as varchar(20) output
as
begin

 select @new_id=(PAL_id + right('0' + cast(datepart(Mm,getdate()) as varchar(2)),2) + right('0' + cast(datepart(dd,getdate()) as varchar(2)),2) + right(cast(datepart(Yy,getdate()) as varchar(4)),2)+ CAST(quote_id as varchar(10))) from PAL_identifiers
           
 update PAL_identifiers set quote_id=quote_id+1
  
end
GO

/****** Object:Stored Procedure   dbo.sp_new_quote_no    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_new_quote_no') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure  dbo.sp_new_quote_no
GO

CREATE procedure  dbo.sp_new_quote_no @new_no as varchar(20) output       
AS
begin
  
  SELECT @new_no=quote_no FROM dbo.PAL_Identifiers 
  
  UPDATE dbo.PAL_Identifiers  SET Quote_no=Quote_no+1
  
 end
GO 


/****** Object:Stored Procedure   dbo.sp_get_all_quotes    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_quotes') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_quotes
GO

CREATE procedure dbo.sp_get_all_quotes
AS
begin

 SELECT * FROM dbo.view_all_quotes  

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_all_quotes_by_user    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_quotes_by_user') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_quotes_by_user
GO

CREATE procedure dbo.sp_get_all_quotes_by_user
				@User_id as varchar(20)
AS
begin

 SELECT * FROM dbo.view_all_quotes WHERE User_id =@User_id

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_quote    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_quote') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure  dbo.sp_get_quote
GO

CREATE procedure  dbo.sp_get_quote
        @quote_detail_id as varchar(50)
AS
begin
  
  SELECT * FROM  dbo.view_all_quotes  WHERE quote_detail_id = @quote_detail_id 
  
 end
GO 


/****** Object:Stored Procedure   dbo.sp_new_quote_details    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_new_quote_details') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_new_quote_details
GO

CREATE procedure dbo.sp_new_quote_details
    @quote_detail_id varchar(20),
	@quote_id varchar(20),
	@quote_no varchar(20),
	@Floor varchar(50),
	@Template_type_id	Int,
	@Construction_type_id	Int,
	@Sink_type_id	Int,
	@No_of_sink	Int,
	@Back_splash 	Char(1),
	@Back_splash_details	Varchar(50),
	@Mill_down 	Char(1),
	@Mill_down_details	Varchar(50),
	@Stove_type_id	Int,
	@Faucet_type_id	Int,
	@Edge_type_id	Int,
	@Edge_type_details	Varchar(255),
	@Cutouts	Varchar(50),
	@Cutouts_quantity	Int,
	@Material_id	Varchar(20),
	@Thickness_id	Int,	
	@Top_removal 	Char(1),
	@Comments varchar(255)	
as
begin

 declare @Quote_detail_no varchar(20)
 
 SELECT @Quote_detail_no=COUNT(1)+1 FROM dbo.Quote_Details WHERE Quote_id = @quote_id
 
 SET @Quote_detail_no=@quote_no + '-' + @Quote_detail_no

	INSERT INTO dbo.Quote_Details(
		    Quote_detail_id
		   ,Quote_id	
		   ,Quote_detail_no 	   
		   ,Floor
		   ,Template_type_id
		   ,Construction_type_id
		   ,Sink_type_id
		   ,No_of_sink
		   ,Back_splash 
		   ,Back_splash_details
		   ,Mill_down 
		   ,Mill_down_details 
		   ,Stove_type_id
		   ,Faucet_type_id
		   ,Edge_type_id
		   ,Edge_type_details
		   ,Cutouts
		   ,Cutouts_quantity
		   ,Material_id
		   ,Thickness_id
		   ,Top_removal		   
		   ,Comments	   
	)VALUES(
	        @quote_detail_id,
			@quote_id,
			@Quote_detail_no,			
			@Floor,
			@Template_type_id,
			@Construction_type_id,
			@Sink_type_id,
			@No_of_Sink,
			@Back_splash, 
			@Back_splash_details,
			@Mill_down,
			@Mill_down_details,
			@Stove_type_id,
			@Faucet_type_id,
			@Edge_type_id,
			@Edge_type_details,
			@Cutouts,
			@Cutouts_quantity,
			@Material_id,
			@Thickness_id,	
			@Top_removal,		
			@Comments
		 )   

end
GO

/****** Object:Stored Procedure   dbo.sp_create_quote_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_create_quote_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_create_quote_wiz
GO

create procedure dbo.sp_create_quote_wiz( 	
	@quote_name varchar(50),
	@quote_description varchar(255),
	@address1 varchar(50),
	@address2 varchar(50),
	@city varchar(50),
	@state_id int,
	@zip varchar(50),
	@country_id int,
	@phone varchar(50),
	@mobile varchar(50),
	@fax varchar(50),
	@email varchar(50),	
	@Floor varchar(50),
	@Template_type_id	Int,
	@Construction_type_id	Int,
	@Sink_type_id	Int,
	@No_of_Sink	Int,
	@Back_splash 	Char(1),
	@Back_splash_details	Varchar(50),
	@Mill_down 	Char(1),
	@Mill_down_details	Varchar(50),
	@Stove_type_id	Int,
	@Faucet_type_id	Int,
	@Edge_type_id	Int,
	@Edge_type_details Varchar(255),
	@Cutouts	Varchar(50),
	@Cutouts_quantity Int,
	@Material_id	Varchar(20),
	@Thickness_id	Int,	
	@Top_removal Char(1),
	@Comments varchar(255),	
	@Requested_by	Varchar(20),
	@created_by varchar(20),
	@retval varchar(20) OUTPUT)
as
begin

declare @quote_detail_id varchar(20)
declare @quote_id varchar(20)
declare @quote_no varchar(20)

exec dbo.sp_new_quote_id @quote_detail_id OUTPUT
exec dbo.sp_new_quote_id @quote_id OUTPUT
exec dbo.sp_new_quote_no @quote_no OUTPUT


begin tran
			
exec dbo.sp_new_quote_details	
			@quote_detail_id,
			@quote_id,
			@quote_no,			
			@Floor,
			@Template_type_id,
			@Construction_type_id,
			@Sink_type_id,
			@No_of_Sink,
			@Back_splash, 
			@Back_splash_details,
			@Mill_down,
			@Mill_down_details,
			@Stove_type_id,
			@Faucet_type_id,
			@Edge_type_id,
			@Edge_type_details,
			@Cutouts,
			@Cutouts_quantity,
			@Material_id,
			@Thickness_id,	
			@Top_removal,		
			@Comments
		          		
	INSERT INTO dbo.Quotes(
			quote_id
		   ,quote_no 	
		   ,quote_name
		   ,quote_description
		   ,Address1
		   ,Address2
		   ,City
		   ,State_id
		   ,Zip
		   ,Country_id
		   ,Phone
		   ,Mobile
		   ,Fax
		   ,Email	   
		   ,Requested_by
		   ,Created_by
		   ,Created_date
		   ,Modified_by
		   ,Modified_date
	)VALUES(
			@quote_id,
			@quote_no,
			@quote_name,
			@quote_description,
			@address1 ,
			@address2 ,
			@city ,
			@state_id,
			@zip,
			@country_id,
			@phone,
			@mobile,
			@fax,
			@email,		
			@Requested_by,	    
			@created_by,
			GETDATE(),
			@created_by,
			GETDATE()
		 )          	
     
     	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = @quote_detail_id
    return  
  
end 
GO



/****** Object:Stored Procedure   dbo.sp_add_room_quote_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_add_room_quote_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_add_room_quote_wiz
GO

create procedure dbo.sp_add_room_quote_wiz( 	
    @quote_detail_id varchar(20),	
	@Floor varchar(50),
	@Template_type_id	Int,
	@Construction_type_id	Int,
	@Sink_type_id	Int,
	@No_of_Sink	Int,
	@Back_splash 	Char(1),
	@Back_splash_details	Varchar(50),
	@Mill_down 	Char(1),
	@Mill_down_details	Varchar(50),
	@Stove_type_id	Int,
	@Faucet_type_id	Int,
	@Edge_type_id	Int,
	@Edge_type_details	Varchar(255),
	@Cutouts	Varchar(50),
	@Material_id	Varchar(20),
	@Thickness_id	Int,	
	@Comments varchar(255),		
	@created_by varchar(20),
	@retval varchar(20) OUTPUT)
as
begin

declare @quote_id varchar(20)
declare @quote_no varchar(20)

SELECT @quote_id=quote_id,@quote_no=quote_no FROM dbo.view_all_quotes  WHERE quote_detail_id = @quote_detail_id 

exec dbo.sp_new_quote_id @quote_detail_id OUTPUT

begin tran

exec dbo.sp_new_quote_details	
			@quote_detail_id,
			@quote_id,
			@quote_no,			
			@Floor,
			@Template_type_id,
			@Construction_type_id,
			@Sink_type_id,
			@No_of_Sink,
			@Back_splash, 
			@Back_splash_details,
			@Mill_down,
			@Mill_down_details,
			@Stove_type_id,
			@Faucet_type_id,
			@Edge_type_id,
			@Edge_type_details,
			@Cutouts,
			@Material_id,
			@Thickness_id,			
			@Comments
		     	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = @quote_detail_id
    return  
  
end 
GO

/****** Object:Stored Procedure   dbo.sp_quote_attach_layout_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_quote_attach_layout_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_quote_attach_layout_wiz
GO

create procedure dbo.sp_quote_attach_layout_wiz( 	
	@quote_detail_id varchar(50),	
	@quote_file_name varchar(50),		
	@quote_file Image,
	@created_by varchar(20),
	@retval varchar(20) OUTPUT)
as
begin

declare @quote_id varchar(20)
declare @quote_file_ext varchar(50)
declare @quote_file_mime varchar(50)

SET @quote_file_mime=''	

SELECT @quote_file_ext=SUBSTRING (@quote_file_name,CHARINDEX('.',@quote_file_name,len(@quote_file_name)-5),len(@quote_file_name)) 

SELECT top 1 @quote_file_mime=file_type_mime FROM dbo.File_Type_LKUP WHERE file_type_extension=@quote_file_ext

begin tran
		
	
	INSERT INTO dbo.Quote_Detail_File(
			Quote_detail_id
		   ,Quote_file_name		   
		   ,Quote_file_mime		   
		   ,Quote_file   
	)VALUES(
			@Quote_detail_id,
			@Quote_file_name,	
			@Quote_file_mime,		
			@Quote_file			
		 )          	
     
     	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_quote_attach_estimate_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_quote_attach_estimate_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_quote_attach_estimate_wiz
GO

create procedure dbo.sp_quote_attach_estimate_wiz( 	
	@quote_detail_id varchar(50),	
	@estimate_file_name varchar(50),		
	@estimate_file Image,
	@created_by varchar(20),
	@retval varchar(20) OUTPUT)
as
begin

declare @quote_id varchar(20)
declare @estimate_file_ext varchar(50)
declare @estimate_file_mime varchar(50)

SET @estimate_file_mime=''	

SELECT @estimate_file_ext=SUBSTRING (@estimate_file_name,CHARINDEX('.',@estimate_file_name,len(@estimate_file_name)-5),len(@estimate_file_name))  

SELECT top 1 @estimate_file_mime=file_type_mime FROM dbo.File_Type_LKUP WHERE file_type_extension=@estimate_file_ext

begin tran

   IF EXISTS(SELECT 1 FROM dbo.Quote_Detail_File WHERE 	Quote_detail_id=@Quote_detail_id)	
      UPDATE dbo.Quote_Detail_File SET
			 Estimate_file_name = @estimate_file_name,	
			 Estimate_file_mime = @estimate_file_mime,		
			 Estimate_file = @estimate_file
      WHERE  Quote_detail_id=@Quote_detail_id
   ELSE
	INSERT INTO dbo.Quote_Detail_File(
			Quote_detail_id
		   ,Estimate_file_name		   
		   ,Estimate_file_mime		   
		   ,Estimate_file   
	)VALUES(
			@Quote_detail_id,
			@estimate_file_name,	
			@estimate_file_mime,		
			@estimate_file			
		 )          	
     
     	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
  
end 
GO

/****** Object:Stored Procedure   dbo.sp_update_quote_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_update_quote_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_update_quote_wiz
GO

create procedure dbo.sp_update_quote_wiz( 
	@quote_id varchar(20),
	@quote_name varchar(50),
	@quote_description varchar(255),
	@address1 varchar(50),
	@address2 varchar(50),
	@city varchar(50),
	@state_id int,
	@zip varchar(50),
	@country_id int,
	@phone varchar(50),
	@mobile varchar(50),
	@fax varchar(50),
	@email varchar(50),
	@Template_type_id	Int,
	@Construction_type_id	Int,
	@Sink_type_id	Int,
	@No_of_Sink	Int,
	@Back_splash 	Char(1),
	@Back_splash_details	Varchar(50),
	@Stove_type_id	Int,
	@Faucet_type_id	Int,
	@Edge_type_id	Int,
	@Cutouts	Varchar(50),
	@Material_id	Varchar(20),
	@Thickness_id	Int,
	@Requested_by	Varchar(20),	
	@modified_by varchar(20),
	@retval int OUTPUT)
as
begin

begin tran
		
	UPDATE dbo.Quotes SET
	    quote_name=@quote_name,
	    quote_description=@quote_description,
	    address1 = @address1,
		address2 = @address2,
		city = @city,
		state_id = @state_id,
		zip = @zip,
		country_id = @country_id,
		phone = @phone,
		mobile = @mobile,
		fax = @fax,
		email = @email,		 			
		Modified_by = @modified_by,
        Modified_date = GETDATE()  
	WHERE quote_id = @quote_id
	
	UPDATE dbo.Quote_Details  SET	  
		Template_type_id = @Template_type_id,
		Construction_type_id = @Construction_type_id,
		Sink_type_id = @Sink_type_id,
		No_of_Sink = @No_of_Sink,
		Back_splash = @Back_splash, 
		Back_splash_details = @Back_splash_details,
		Stove_type_id = @Stove_type_id,
		Faucet_type_id = @Faucet_type_id,
		Edge_type_id = @Edge_type_id,
		Cutouts = @Cutouts,
		Material_id = @Material_id,
		Thickness_id = @Thickness_id		
	
	WHERE quote_id = @quote_id
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_delete_quote_wiz    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_delete_quote_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_delete_quote_wiz
GO

CREATE procedure dbo.sp_delete_quote_wiz(
			@quote_detail_id  varchar(20),
			@modified_by varchar(20),
			@retval int OUTPUT)
AS
begin
 
 begin tran
 
-- DELETE FROM  dbo.Quote_Detail_File WHERE Quote_detail_id = @quote_detail_id
 --DELETE FROM  dbo.Quote_Details WHERE Quote_detail_id = @quote_detail_id 
-- DELETE FROM  dbo.Quotes WHERE quote_id=@quote_id 
 
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 
