

/****** Script: New/Update/Delete estimates - PAvaniStone_db_xx	******/
/****** Author: Sreenivasan Subbanchattiar		******/
/****** Script Created By: Sreenivasan Subbanchattiar   	******/
/****** Script Created Date: 7/20/2011 			******/
/****** Script Modified By: Sreenivasan Subbanchattiar		******/
/****** Script Modified Date: 7/20/2011 	  		******/
/****** Script Version: 1.0  				******/


/****** Object:Stored Procedure dbo.sp_new_estimate_id    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_new_estimate_id') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_new_estimate_id
GO

CREATE procedure dbo.sp_new_estimate_id @new_id as varchar(20) output
as
begin

 select @new_id=(PAL_id + right('0' + cast(datepart(Mm,getdate()) as varchar(2)),2) + right('0' + cast(datepart(dd,getdate()) as varchar(2)),2) + right(cast(datepart(Yy,getdate()) as varchar(4)),2)+ CAST(estimate_id as varchar(10))) from PAL_identifiers
           
 update PAL_identifiers set estimate_id=estimate_id+1
  
end
GO



/****** Object:Stored Procedure   dbo.sp_get_all_estimates    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_all_estimates') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_get_all_estimates
GO

CREATE procedure dbo.sp_get_all_estimates
AS
begin

 SELECT * FROM dbo.view_all_estimates  

 end
GO 

/****** Object:Stored Procedure   dbo.sp_get_estimate    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_get_estimate') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure  dbo.sp_get_estimate
GO

CREATE procedure  dbo.sp_get_estimate
        @estimate_id as varchar(20)
AS
begin
  
  SELECT * FROM  dbo.view_all_estimates  WHERE estimate_id = @estimate_id 
  
 end
GO 


/****** Object:Stored Procedure   dbo.sp_create_estimate_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_create_estimate_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_create_estimate_wiz
GO

create procedure dbo.sp_create_estimate_wiz( 
	@Estimate_number	Varchar(50),
	@Account_id			Varchar(20),
	@Customer_id		Varchar(20),
	@Supplier_id		Varchar(20),
	@Material_id		Varchar(20),
	@Edge_type_id		Integer,
	@Thickness_id		Integer,
	@Square_feet		Float,
	@Price_per_Sq_ft	Float,
	@Estimate_Status	Char(1),
	@created_by varchar(20),
	@retval varchar(20) OUTPUT)
as
begin

declare @Estimate_id varchar(20)

exec dbo.sp_new_estimate_id @Estimate_id OUTPUT

begin tran
		
INSERT INTO dbo.Estimates(
		Estimate_id,
		Estimate_number,
		Account_id,
		Customer_id,
		Supplier_id,
		Material_id,
		Edge_type_id,
		Thickness_id,
		Square_feet,
		Price_per_Sq_ft,
		Estimate_Status,
	    Created_by,
	    Created_date,
	    Modified_by,
	    Modified_date
)VALUES(
		@Estimate_id,
	    @Estimate_number,
		@Account_id,
		@Customer_id,
		@Supplier_id,
		@Material_id,
		@Edge_type_id,
		@Thickness_id,
		@Square_feet,
		@Price_per_Sq_ft,
		@Estimate_Status,
	    @created_by,
		GETDATE(),
	    @created_by,
		GETDATE()
     )          	
     
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = '-1' 
     return 
  end
 
    commit  tran
    set @retval = @estimate_id
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_update_estimate_wiz    Script Date: 07/25/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_update_estimate_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_update_estimate_wiz
GO

create procedure dbo.sp_update_estimate_wiz( 
	@Estimate_id		varchar(20),
	@Estimate_number	Varchar(50),
	@Account_id			Varchar(20),
	@Customer_id		Varchar(20),
	@Supplier_id		Varchar(20),
	@Material_id		Varchar(20),
	@Edge_type_id		Integer,
	@Thickness_id		Integer,
	@Square_feet		Float,
	@Price_per_Sq_ft	Float,
	@Estimate_status	Char(1),
	@modified_by		varchar(20),
	@retval int OUTPUT)
as
begin

begin tran
		
	UPDATE dbo.estimates SET
	    Estimate_number=@Estimate_number,
		Account_id=@Account_id,
		Customer_id=@Customer_id,
		Supplier_id=@Supplier_id,
		Material_id=@Material_id,
		Edge_type_id=@Edge_type_id,
		Thickness_id=@Thickness_id,
		Square_feet=@Square_feet,
		Price_per_Sq_ft=@Price_per_Sq_ft,
		Estimate_status=@Estimate_status,		
		Modified_by = @modified_by,
        Modified_date = GETDATE()  
	WHERE estimate_id = @estimate_id
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
  
end 
GO


/****** Object:Stored Procedure   dbo.sp_delete_estimate_wiz    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_delete_estimate_wiz') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_delete_estimate_wiz
GO

CREATE procedure dbo.sp_delete_estimate_wiz(
			@estimate_id  varchar(20),
			@modified_by varchar(20),
			@retval int OUTPUT)
AS
begin
 
 begin tran
 
 DELETE FROM  dbo.Estimates WHERE Estimate_id=@estimate_id 
 
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 



/****** Object:Stored Procedure   dbo.sp_add_item_to_estimate    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_add_item_to_estimate') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_add_item_to_estimate
GO

CREATE procedure dbo.sp_add_item_to_estimate(
			@Estimate_id	Varchar(20),
			@Estimate_item_no	Integer,
			@Estimate_item_description	Varchar(255),
			@Length Float,
			@Width  Float,
			@Price_per_sq_ft  Float,
			@modified_by varchar(20),
			@retval int OUTPUT)
AS
begin
 
 begin tran
 
	INSERT INTO dbo.Estimates_Items(
				Estimate_id,
				Estimate_item_no,
				Estimate_item_description,
				Length,
				Width,
				Price_per_sq_ft
	)VALUES(
				@Estimate_id,
				@Estimate_item_no,
				@Estimate_item_description,
				@Length,
				@Width,
				@Price_per_sq_ft		
	) 
 
 if @@error = 0
   UPDATE dbo.Estimates SET
		Modified_by = @modified_by,
        Modified_date = GETDATE()  
	WHERE Estimate_id = @Estimate_id
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 



/****** Object:Stored Procedure   dbo.sp_remove_item_from_estimate    Script Date: 7/20/2011 	  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp_remove_item_from_estimate') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp_remove_item_from_estimate
GO

CREATE procedure dbo.sp_remove_item_from_estimate(
			@Estimate_item_id	Varchar(50),			
			@modified_by varchar(20),
			@retval int OUTPUT)
AS
begin
 
 DECLARE @Estimate_id VARCHAR(20)
 
 SELECT @Estimate_id=Estimate_id FROM dbo.Estimates_Items WHERE Estimate_item_id = @Estimate_item_id
 
 begin tran
 
	DELETE FROM dbo.Estimates_Items WHERE Estimate_item_id = @Estimate_item_id
 
  if @@error = 0
   UPDATE dbo.Estimates SET
		Modified_by = @modified_by,
        Modified_date = GETDATE()  
	WHERE Estimate_id = @Estimate_id
	
 if @@error <> 0
  begin
     rollback  tran
     set @retval = -1 
     return 
  end
 
    commit  tran
    set @retval = 0
    return  
    
 end
GO 
