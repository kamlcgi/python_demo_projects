/****** Database Name: PAvaniStone_db_xx  ******/
/****** Author:  Sreenivasan Subbanchattiar  ******/
/****** Script Created Date: 7/20/2011  ******/
/****** Script Modified Date: 7/20/2011  ******/
/****** Script Version: 1.0  ******/


/****** Database:  PAvaniStone_db_xx  ******/
USE PAvaniStone_db_xx
GO


/****** Object:  Table dbo.Accounts    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Accounts') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Accounts
GO

/****** Object:  Table dbo.Accounts_X_Users    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Accounts_X_Users') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Accounts_X_Users
GO

/****** Object:  Table dbo.Suppliers    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Suppliers') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Suppliers
GO

/****** Object:  Table dbo.Suppliers_X_Users    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Suppliers_X_Users') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Suppliers_X_Users
GO

/****** Object:  Table dbo.Quotes    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Quotes') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Quotes
GO

/****** Object:  Table dbo.Quote_Details    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Quote_Details') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Quote_Details
GO

/****** Object:  Table dbo.Quote_Detail_File    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Quote_Detail_File') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Quote_Detail_File
GO

/****** Object:  Table dbo.Construction_Type_LKUP    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Construction_Type_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Construction_Type_LKUP
GO

/****** Object:  Table dbo.Projects    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Projects') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Projects
GO

/****** Object:  Table dbo.Customers    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Customers') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Customers
GO

/****** Object:  Table dbo.Customer_Notes    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Customer_Notes') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Customer_Notes
GO


/****** Object:  Table dbo.Estimates    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Estimates') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Estimates
GO

/****** Object:  Table dbo.Estimates_Items    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Estimates_Items') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Estimates_Items
GO

/****** Object:  Table dbo.Estimates_X_Work_Orders    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Estimates_X_Work_Orders') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Estimates_X_Work_Orders
GO

/****** Object:  Table dbo.Work_Orders    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Work_Orders') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Work_Orders
GO

/****** Object:  Table dbo.Work_Order_Notes    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Work_Order_Notes') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Work_Order_Notes
GO

/****** Object:  Table dbo.Work_Order_Templates    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Work_Order_Templates') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Work_Order_Templates
GO

/****** Object:  Table dbo.Work_Order_Fabrications    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Work_Order_Fabrications') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Work_Order_Fabrications
GO

/****** Object:  Table dbo.Work_Order_Installations    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Work_Order_Installations') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Work_Order_Installations
GO

/****** Object:  Table dbo.Work_Order_Return_Services    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Work_Order_Return_Services') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Work_Order_Return_Services
GO

/****** Object:  Table dbo.File_Type_LKUP    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.File_Type_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.File_Type_LKUP
GO

/****** Object:  Table dbo.Edge_Type_LKUP    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Edge_Type_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Edge_Type_LKUP
GO

/****** Object:  Table dbo.Faucet_Type_LKUP    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Faucet_Type_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Faucet_Type_LKUP
GO

/****** Object:  Table dbo.Faucet_Status_LKUP    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Faucet_Status_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Faucet_Status_LKUP
GO

/****** Object:  Table dbo.Sink_Status_LKUP    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Sink_Status_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Sink_Status_LKUP
GO

/****** Object:  Table dbo.Sink_Type_LKUP    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Sink_Type_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Sink_Type_LKUP
GO

/****** Object:  Table dbo.Thickness_LKUP    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Thickness_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Thickness_LKUP
GO

/****** Object:  Table dbo.Stove_Type_LKUP    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Stove_Type_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Stove_Type_LKUP
GO

/****** Object:  Table dbo.Template_Type_LKUP    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Template_Type_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Template_Type_LKUP
GO

/****** Object:  Table dbo.Time_Slot_LKUP    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Time_Slot_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Time_Slot_LKUP
GO

/****** Object:  Table dbo.Materials    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Materials') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Materials
GO

/****** Object:  Table dbo.Material_Type_LKUP    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Material_Type_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Material_Type_LKUP
GO

/****** Object:  Table dbo.Tips    Script Date: 4/15/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Tips') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Tips
GO


/****** Object:  Table dbo.PAL_Users    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Users') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Users
GO

/****** Object:  Table dbo.PAL_Users_Log    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Users_Log') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Users_Log
GO

/****** Object:  Table dbo.PAL_Role    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Role') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Role
GO

/****** Object:  Table dbo.PAL_Page    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Page') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Page
GO

/****** Object:  Table dbo.PAL_Role_X_PAL_Page    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Role_X_PAL_Page') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Role_X_PAL_Page
GO

/****** Object:  Table dbo.T_PAL_Role_X_PAL_Page    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.T_PAL_Role_X_PAL_Page') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.T_PAL_Role_X_PAL_Page
GO

/****** Object:  Table dbo.PAL_Address    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Address') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Address
GO

/****** Object:  Table dbo.Country_LKUP    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Country_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Country_LKUP
GO

/****** Object:  Table dbo.State_LKUP    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.State_LKUP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.State_LKUP
GO

/****** Object:  Table dbo.Country_X_State    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.Country_X_State') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.Country_X_State
GO


/****** Object:  Table dbo.PAL_Identifiers    Script Date: 7/20/2011  ******/
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.PAL_Identifiers') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table dbo.PAL_Identifiers
GO


/****** Object:  Table dbo.Accounts    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Accounts (
	Account_id		varchar(20)  NOT NULL,
	Account_name	varchar(50) NULL,
	Address_id		varchar(20) NOT NULL,
	Created_by		varchar(20) NULL,
	Created_date	datetime NULL,
	Modified_by		varchar(20) NULL,
	Modified_date	datetime NULL,
        CONSTRAINT PK_Accounts PRIMARY KEY (Account_id)  
) 
GO

/****** Object:  Table dbo.Accounts_X_Users    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Accounts_X_Users (
	Account_id	varchar(20)  NOT NULL,
	User_id		varchar(20)  NOT NULL, 
        CONSTRAINT PK_Accounts_Users PRIMARY KEY (Account_id,User_id)	
) 
GO

/****** Object:  Table dbo.Suppliers    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Suppliers (
	Supplier_id		varchar(20)  NOT NULL,
	Supplier_name	varchar(50) NULL,
	Address_id		varchar(20) NOT NULL,
	Created_by		varchar(20) NULL,
	Created_date	datetime NULL,
	Modified_by		varchar(20) NULL,
	Modified_date	datetime NULL,
        CONSTRAINT PK_Suppliers PRIMARY KEY (Supplier_id)  
) 
GO


/****** Object:  Table dbo.Suppliers_X_Users    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Suppliers_X_Users (
	Supplier_id		varchar(20)  NOT NULL,
	User_id			varchar(20)  NOT NULL, 
        CONSTRAINT PK_Suppliers_Users PRIMARY KEY (Supplier_id,User_id)	
) 
GO



/****** Object:  Table dbo.Construction_Type_LKUP    Script Date: 4/15/2011   ******/
CREATE TABLE dbo.Construction_Type_LKUP (
	Construction_type_id tinyint NOT NULL,
	Construction_type_description varchar(50) NULL,
        CONSTRAINT PK_Construction_Type_LKUP PRIMARY KEY (Construction_type_id)  
) 
GO

/****** Object:  Table dbo.Projects    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Projects (
	Project_id		varchar(20)  NOT NULL,
	Project_name		varchar(50) NULL,
	Project_description		varchar(255) NULL,
	Address1		varchar(50) NULL,
	Address2		varchar(50) NULL,	
	City			varchar(50) NULL,
	State_id		int NULL,
	Zip				varchar(50) NULL,
	Country_id		int NULL,
	Phone			varchar(50) NULL,
	Mobile			varchar(50) NULL,
	Fax				varchar(50) NULL,
	Email			varchar(50) NULL,
	Created_by		varchar(20) NULL,
	Created_date	datetime NULL,
	Modified_by		varchar(20) NULL,
	Modified_date	datetime NULL,
        CONSTRAINT PK_Projects PRIMARY KEY (Project_id)  
) 
GO

/****** Object:  Table dbo.Customers    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Customers (
	Customer_id		varchar(20)  NOT NULL,
	First_name		varchar(50) NULL,
	Last_name		varchar(50) NULL,
	Address1		varchar(50) NULL,
	Address2		varchar(50) NULL,	
	City			varchar(50) NULL,
	State_id		int NULL,
	Zip				varchar(50) NULL,
	Country_id		int NULL,
	Phone			varchar(50) NULL,
	Mobile			varchar(50) NULL,
	Fax				varchar(50) NULL,
	Email			varchar(50) NULL,
	Created_by		varchar(20) NULL,
	Created_date	datetime NULL,
	Modified_by		varchar(20) NULL,
	Modified_date	datetime NULL,
        CONSTRAINT PK_Customers PRIMARY KEY (Customer_id)  
) 
GO


/****** Object:  Table dbo.Customer_Notes    Script Date: 4/15/2011  ******/
CREATE  TABLE dbo.Customer_Notes (
	Customer_note_id UniqueIdentifier default NEWID()  NOT NULL,
	Customer_id		varchar(20)  NOT NULL,	
	Note_text		varchar(50) NULL,
	Created_by		varchar(20) NULL,
	Created_date	datetime NULL,
	CONSTRAINT PK_Customer_Notes PRIMARY KEY (Customer_note_id)  
) 
GO

/****** Object:  Table dbo.Estimates    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Estimates (
	Estimate_id		varchar(20)  NOT NULL,
	Estimate_number varchar(50) NULL,
	Account_id		varchar(20) NULL,
	Customer_id		varchar(20) NULL,
	Supplier_id		varchar(20) NULL,
	Material_id		int NULL,
	Edge_type_id	int NULL,
	Thickness_id	int NULL,
	Square_feet		float NULL,
	Price_per_sq_ft float NULL,
	Estimate_Status Char(1) NULL,
	Created_by		varchar(20) NULL,
	Created_date	datetime NULL,
	Modified_by		varchar(20) NULL,
	Modified_date	datetime NULL,
        CONSTRAINT PK_Estimates PRIMARY KEY (Estimate_id)  
) 
GO

/****** Object:  Table dbo.Estimates_Items    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Estimates_Items (
	Estimate_item_id	uniqueidentifier DEFAULT NEWID() NOT NULL,
	Estimate_id			varchar(20)  NOT NULL,
	Estimate_item_no	int NOT NULL,
	Estimate_item_description varchar(255) NULL,
	Length			float NULL,
	Width			float NULL,
	Price_per_sq_ft float NULL,
	CONSTRAINT PK_Estimates_Items PRIMARY KEY (Estimate_item_id)  
) 
GO


/****** Object:  Table dbo.Estimates_X_Work_Orders    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Estimates_X_Work_Orders (
	Estimate_id		varchar(20)  NOT NULL,
	Work_order_id	varchar(20)  NOT NULL, 
        CONSTRAINT PK_Customers_Users PRIMARY KEY (Estimate_id,Work_order_id)	
) 
GO


/****** Object:  Table dbo.Quotes    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Quotes (
	Quote_id		varchar(20)  NOT NULL,
	Quote_no	varchar(20)  NOT NULL,
	Quote_name		varchar(50) NULL,
	Quote_description		varchar(255) NULL,
	Address1		varchar(50) NULL,
	Address2		varchar(50) NULL,	
	City			varchar(50) NULL,
	State_id		int NULL,
	Zip				varchar(50) NULL,
	Country_id		int NULL,
	Phone			varchar(50) NULL,
	Mobile			varchar(50) NULL,
	Fax				varchar(50) NULL,
	Email			varchar(50) NULL,
	Quoted_date	    datetime NULL,
	Requested_by	varchar(20) NULL,
	Created_by		varchar(20) NULL,
	Created_date	datetime NULL,
	Modified_by		varchar(20) NULL,
	Modified_date	datetime NULL,
        CONSTRAINT PK_Quotes PRIMARY KEY (Quote_id)  
) 
GO


/****** Object:  Table dbo.Quote_Details    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Quote_Details (
	Quote_detail_id varchar(20) NOT NULL,
	Quote_detail_no	varchar(20)  NULL,
	Quote_id	varchar(20)  NOT NULL,		
	Floor	Varchar(50) NULL,
	Template_type_id	Int NULL,
	Construction_type_id Int NULL,
	Sink_type_id	Int NULL,
	No_of_sink	Int NULL,
	Back_splash 	Char(1) NULL,
	Back_splash_details	Varchar(50) NULL,
	Mill_down 	Char(1) NULL,
	Mill_down_details	Varchar(50) NULL,
	Stove_type_id	Int NULL,
	Faucet_type_id	Int NULL,
	Edge_type_id	Int NULL,
	Edge_type_details	Varchar(255) NULL,
	Cutouts	Char(1) NULL,
	Cutouts_quantity	Int NULL,
	Top_removal char(1)  NULL,	
	Material_id	Varchar(20) NULL,
	Thickness_id	Int NULL,		
	Comments	Varchar(255) NULL,
	CONSTRAINT PK_Quote_Details PRIMARY KEY (Quote_detail_id)  
) 
GO


/****** Object:  Table dbo.Quote_Detail_File    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Quote_Detail_File (
		Quote_detail_id varchar(20) NOT NULL,		
		Quote_file_mime varchar(50) NULL,
		Quote_file_name varchar(50) NULL,
		Quote_file	Image NULL,	
		Estimate_file_mime varchar(50) NULL,
		Estimate_file_name varchar(50) NULL,
		Estimate_file	Image NULL,		    
	    CONSTRAINT PK_Quote_Detail_File PRIMARY KEY (Quote_detail_id)  
) 
GO

/****** Object:  Table dbo.Work_Orders    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Work_Orders (
	Work_Order_id varchar(20)  NOT NULL,
	Work_order_number Int NOT NULL,	
	Quote_detail_id varchar(20) NULL,		
	Purchase_order_number varchar(50) NULL,		
	Purchase_order_date date NULL,	
	Requested_start_date Varchar(50) NULL,
	Template char(1)  NULL,	
	Fabrication char(1)  NULL,	
	Installation char(1)  NULL,	
	Repair char(1)  NULL,		
	Service_completed char(1) NULL,
	Service_completed_date datetime  NULL,	
	Work_order_comments	Varchar(255) NULL,
	Created_by varchar(20) NULL,
	Created_date datetime NULL,
	Modified_by varchar(20) NULL,
	Modified_date datetime NULL,
        CONSTRAINT PK_Work_Orders PRIMARY KEY (Work_Order_id)  
) 
GO

/****** Object:  Table dbo.Work_Order_Details    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Work_Order_Details (
	Work_Order_id varchar(20)  NOT NULL,	
	Floor	Varchar(50) NULL,
	Template_type_id	Int NULL,
	Construction_type_id Int NULL,
	Sink_type_id	Int NULL,
	No_of_sink	Int NULL,
	Back_splash 	Char(1) NULL,
	Back_splash_details	Varchar(50) NULL,
	Mill_down 	Char(1) NULL,
	Mill_down_details	Varchar(50) NULL,
	Stove_type_id	Int NULL,
	Faucet_type_id	Int NULL,
	Edge_type_id	Int NULL,
	Edge_type_details	Varchar(255) NULL,
	Cutouts	Char(1) NULL,
	Cutouts_quantity	Int NULL,
	Top_removal char(1)  NULL,	
	Material_id	Varchar(20) NULL,
	Thickness_id	Int NULL,		
	Sink_status_id int  NOT NULL,
	Faucet_status_id int  NOT NULL,
	Kitchen_island	Varchar(255) NULL,
	Cabinets	Varchar(255) NULL,	
	CONSTRAINT PK_Work_Order_Details PRIMARY KEY (Work_Order_id)  
) 
GO

/****** Object:  Table dbo.Work_Order_Notes    Script Date: 4/15/2011  ******/
CREATE  TABLE dbo.Work_Order_Notes (
	Work_order_note_id UniqueIdentifier default NEWID()  NOT NULL,
	Work_Order_id	varchar(20)  NOT NULL,	
	Note_text		varchar(50) NULL,
	Created_by		varchar(20) NULL,
	Created_date	datetime NULL,
	CONSTRAINT PK_Work_Order_Notes PRIMARY KEY (Work_order_note_id)  
) 
GO

/****** Object:  Table dbo.Work_Order_Templates    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Work_Order_Templates (
	Work_order_id varchar(20) NOT NULL,
	Time_slot_id int NULL,
	Template_by varchar(20) NULL,
	Template_date date NULL,
	Estimate_sqft int NULL,
	Actual_sqft float NULL,
	Template_completed char(1) NULL,
	Verified_by varchar(20) NULL,
	Verified_date datetime NULL,
	Template_accepted char(1) NULL,
	CONSTRAINT PK_Templates PRIMARY KEY (Work_order_id)  
) 
GO

/****** Object:  Table dbo.Work_Order_Fabrications    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Work_Order_Fabrications (
	Work_Order_id varchar(20)  NOT NULL,
	Fabrication_by varchar(20) NULL,
	Fabrication_date date NULL,
	Fabrication_completed char(1) NULL,
	CONSTRAINT PK_Fabrications PRIMARY KEY (Work_Order_id)	
) 
GO


/****** Object:  Table dbo.Work_Order_Installations    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Work_Order_Installations (
	Work_Order_id varchar(20)  NOT NULL,	
	Time_slot_id int NULL,
	Installation_by varchar(20) NULL,
	Installation_date date NULL,	
	Installation_completed char(1) NULL,
	CONSTRAINT PK_Work_Orders_Installations PRIMARY KEY (Work_Order_id)	
) 
GO

/****** Object:  Table dbo.Work_Order_Repair_Services    Script Date: 4/15/2011  ******/
CREATE TABLE dbo.Work_Order_Repair_Services (
	Work_Order_id varchar(20)  NOT NULL,	
	Time_slot_id int NULL,
	Repair_service_by varchar(20) NULL,
	Repair_service_date date NULL,
	Repair_service_completed char(1) NULL,
	CONSTRAINT PK_Repair_Services PRIMARY KEY (Work_Order_id)	
) 
GO


/****** Object:  Table dbo.Edge_Type_LKUP    Script Date: 4/15/2011   ******/
CREATE TABLE dbo.Edge_Type_LKUP (
	Edge_type_id tinyint  NOT NULL,
	Edge_type_description varchar(50) NULL,
	Edge_type_file varchar(50) NULL,
        CONSTRAINT PK_Edge_Type_LKUP PRIMARY KEY (Edge_type_id)  
) 
GO

/****** Object:  Table dbo.Faucet_Type_LKUP    Script Date: 4/15/2011   ******/
CREATE TABLE dbo.Faucet_Type_LKUP (
	Faucet_type_id tinyint NOT NULL,
	Faucet_type_description varchar(50) NULL,
        CONSTRAINT PK_Faucet_Type_LKUP PRIMARY KEY (Faucet_type_id)  
) 
GO

/****** Object:  Table dbo.Faucet_Status_LKUP    Script Date: 4/15/2011   ******/
CREATE TABLE dbo.Faucet_Status_LKUP (
	Faucet_status_id tinyint NOT NULL,
	Faucet_status_description varchar(50) NULL,
        CONSTRAINT PK_Faucet_Status_LKUP PRIMARY KEY (Faucet_status_id)  
) 
GO

/****** Object:  Table dbo.Sink_Status_LKUP    Script Date: 4/15/2011   ******/
CREATE TABLE dbo.Sink_Status_LKUP (
	Sink_status_id tinyint NOT NULL,
	Sink_status_description varchar(50) NULL,
        CONSTRAINT PK_Sink_Status_LKUP PRIMARY KEY (Sink_status_id)  
) 
GO

/****** Object:  Table dbo.Sink_Type_LKUP    Script Date: 4/15/2011   ******/
CREATE TABLE dbo.Sink_Type_LKUP (
	Sink_type_id tinyint NOT NULL,
	Sink_type_description varchar(50) NULL,
	Sort_index tinyint NULL,
        CONSTRAINT PK_Sink_Type_LKUP PRIMARY KEY (Sink_type_id)  
) 
GO

/****** Object:  Table dbo.Thickness_LKUP    Script Date: 4/15/2011   ******/
CREATE TABLE dbo.Thickness_LKUP (
	Thickness_id tinyint NOT NULL,
	Thickness_description varchar(50) NULL,
	Sort_index tinyint NULL,
        CONSTRAINT PK_Thickness_LKUP PRIMARY KEY (Thickness_id)  
) 
GO

/****** Object:  Table dbo.Stove_Type_LKUP    Script Date: 4/15/2011   ******/
CREATE TABLE dbo.Stove_Type_LKUP (
	Stove_type_id tinyint NOT NULL,
	Stove_type_description varchar(50) NULL,
	Sort_index tinyint NULL,
        CONSTRAINT PK_Stove_Type_LKUP PRIMARY KEY (Stove_type_id)  
) 
GO

/****** Object:  Table dbo.Template_Type_LKUP    Script Date: 4/15/2011   ******/
CREATE TABLE dbo.Template_Type_LKUP (
	Template_type_id tinyint NOT NULL,
	Template_type_description varchar(50) NULL,
	Sort_index tinyint NULL,
        CONSTRAINT PK_Template_Type_LKUP PRIMARY KEY (Template_type_id)  
) 
GO

/****** Object:  Table dbo.Time_Slot_LKUP    Script Date: 4/15/2011   ******/
CREATE TABLE dbo.Time_Slot_LKUP (
	Time_Slot_id tinyint NOT NULL,
	Time_Slot_description varchar(50) NULL,
	Sort_index tinyint NULL,
        CONSTRAINT PK_Time_Slot_LKUP PRIMARY KEY (Time_Slot_id)  
) 
GO

/****** Object:  Table dbo.Materials    Script Date: 4/15/2011   ******/
CREATE TABLE dbo.Materials (
	Material_id varchar(20) NOT NULL,
	Material_name varchar(50) NULL,
	Material_color varchar(50) NULL,
	Material_code_number varchar(50) NULL,
	Material_type_id int NULL,
	Material_description varchar(500) NULL,
	File_type_id int NULL,
	File_location varchar(50) NULL,
	Country_id int NULL,
	Created_by varchar(20) NULL,
	Created_date datetime NULL,
	Modified_by varchar(20) NULL,
	Modified_date datetime NULL,	
        CONSTRAINT PK_Materials PRIMARY KEY (Material_id)  
) 
GO

/****** Object:  Table dbo.Material_Type_LKUP    Script Date: 4/15/2011   ******/
CREATE TABLE dbo.Material_Type_LKUP (
	Material_type_id tinyint NOT NULL,
	Material_type_description varchar(50) NULL,
	Sort_index tinyint NULL,
        CONSTRAINT PK_Material_Type_LKUP PRIMARY KEY (Material_type_id)  
) 
GO

/****** Object:  Table dbo.File_Type_LKUP    Script Date: 4/15/2011   ******/
CREATE TABLE dbo.File_Type_LKUP (
	File_type_id int NOT NULL,
	File_type_extension varchar(50) NULL,
	File_mime varchar(255) NULL,	
        CONSTRAINT PK_File_Type_LKUP PRIMARY KEY (File_type_id)  
) 
GO

/****** Object:  Table dbo.Tips    Script Date: 4/15/2011   ******/
CREATE TABLE dbo.Tips (
	Tip_id varchar(20) NOT NULL,
	Tip_name varchar(75) NULL,
	Tip_description varchar(500) NULL,
	File_type_id tinyint NULL,
	File_location varchar(50) NULL,
	Modified_by varchar(20) NULL,
	Modified_date datetime NULL,	
	Post char(1) NULL,
        CONSTRAINT PK_Tips PRIMARY KEY (Tip_id)  
) 
GO

/****** Object:  Table dbo.PAL_Users    Script Date: 7/20/2011   ******/
CREATE TABLE dbo.PAL_Users (
	User_id varchar(20) NOT NULL,
	User_name varchar(50) NULL,
	Passwd varchar(50) NULL,
	First_name varchar(50) NULL,
	Last_name varchar(50) NULL,
	Active_user char(1) NULL,
	Role_id	 integer NOT NULL,
	Last_login_date datetime NULL,
	Address_id varchar(20) NULL,
	Created_by varchar(20) NULL,
	Created_date datetime NULL,
	Modified_by varchar(20) NULL,
	Modified_date datetime NULL,
	CONSTRAINT PK_PAL_Users PRIMARY KEY (User_id)  
) 
GO

/****** Object:  Table dbo.PAL_Role    Script Date: 7/20/2011  ******/
CREATE TABLE dbo.PAL_Role (
	Role_id	 integer NOT NULL,
	Role_name	varchar(50) NULL,
	Created_by	varchar(20) NULL,
	Created_date	datetime NULL,
	Modified_by	varchar(20) NULL,
	Modified_date	Datetime NULL,
	CONSTRAINT PK_PAL_Role  PRIMARY KEY (Role_id)	
) 
GO

/****** Object:  Table dbo.PAL_Page    Script Date: 7/20/2011  ******/
CREATE TABLE dbo.PAL_Page (
	Page_id	 integer NOT NULL,
	Parent_Page_id	integer NULL,
	Page_title	varchar(50) NULL,
	Navigate_url	varchar(50) NULL,
	Page_description	varchar(255) NULL,
	Created_by	varchar(20) NULL,
	Created_date	datetime NULL,
	Modified_by	varchar(20) NULL,
	Modified_date	Datetime NULL,
	CONSTRAINT PK_PAL_Page PRIMARY KEY (Page_id)	
) 
GO

/****** Object:  Table dbo.PAL_Role_X_PAL_Page    Script Date: 7/20/2011  ******/
CREATE TABLE dbo.PAL_Role_X_PAL_Page (
	Role_id	integer NOT NULL,	
    Page_id	integer NOT NULL,
	Sort_index	smallint NULL,
	Allow_view char(1) NULL,
	Allow_modify char(1) NULL,
	Allow_delete char(1) NULL,
	CONSTRAINT PK_PAL_Role_X_PAL_Page PRIMARY KEY (Role_id,Page_id)	
) 
GO

/****** Object:  Table dbo.T_PAL_Role_X_PAL_Page    Script Date: 7/20/2011  ******/
CREATE TABLE dbo.T_PAL_Role_X_PAL_Page (
	Role_id	integer NOT NULL,	
    Page_id	integer NOT NULL,
    Modified_by varchar(20) NOT NULL,
	Sort_index	smallint NULL,
	Allow_view char(1) NULL,
	Allow_modify char(1) NULL,
	Allow_delete char(1) NULL,	
	CONSTRAINT PK_T_PAL_Role_X_PAL_Page PRIMARY KEY (Role_id,Page_id,Modified_by)	
) 
GO
	
/****** Object:  Table dbo.PAL_Users_Log    Script Date: 7/20/2011   ******/
CREATE TABLE dbo.PAL_Users_Log (
	Log_id uniqueidentifier NOT NULL DEFAULT NEWID(),
	IP_address  varchar(50) NULL,
	Browser  varchar(500) NULL,
	Log_data varchar(2000) NULL,
	Log_by varchar(20) NULL,
	Log_date datetime NULL,	
	CONSTRAINT PK_PAL_Users_Log PRIMARY KEY (Log_id)  
) 
GO

/****** Object:  Table dbo.Pal_Address    Script Date: 7/20/2011   ******/
CREATE TABLE dbo.Pal_Address (
	Address_id varchar(20) NOT NULL,
	Address1 varchar(50) NULL,
	Address2 varchar(50) NULL,
	City varchar(50) NULL,
	State_id int NULL,
	Zip varchar(50) NULL,
	Country_id int NULL,
	Phone varchar(50) NULL,
	Mobile varchar(50) NULL,
	Fax varchar(50) NULL,
	Email varchar(50) NULL,
	CONSTRAINT PK_Pal_Address PRIMARY KEY (Address_id)  
) 
GO

/****** Object:  Table dbo.Country_LKUP    Script Date: 7/20/2011   ******/
CREATE TABLE dbo.Country_LKUP (
	Country_id int NOT NULL,
	Country_name varchar(50) NULL,
	Country_code varchar(2) NULL,
	CONSTRAINT PK_Country_LKUP PRIMARY KEY (Country_id)  
	) 
GO

/****** Object:  Table dbo.State_LKUP    Script Date: 7/20/2011   ******/
CREATE TABLE dbo.State_LKUP (	
	State_id int NOT NULL,
	State_name varchar(50) NULL,
	State_code varchar(2) NULL,
	CONSTRAINT PK_State_LKUP PRIMARY KEY (State_id)  
	) 
GO

/****** Object:  Table dbo.Country_X_State    Script Date: 7/20/2011   ******/
CREATE TABLE dbo.Country_X_State (
	Country_id int  NOT NULL,
	State_id int NOT NULL, 
	CONSTRAINT PK_Country_X_State PRIMARY KEY (Country_id,State_id)  
	) 
GO


/****** Object:  Table dbo.PAL_Identifiers    Script Date: 7/20/2011   ******/
CREATE TABLE dbo.PAL_Identifiers (
	PAL_id varchar(3) NOT NULL,
	User_id int NOT NULL,
	Address_id int NOT NULL,
	Account_id int NOT NULL,
	Supplier_id int NOT NULL,
	Quote_id int NOT NULL,
	Customer_id int NOT NULL,
	Estimate_id int NOT NULL,
	Work_order_id int NOT NULL,
	Work_order_number int NOT NULL,
	Template_id int NOT NULL,
	Fabrication_id int NOT NULL,
	Installation_id  int NOT NULL,
	Return_service_id int NOT NULL,	
	Material_id int NOT NULL,	
	Tip_id int NOT NULL,	
) 
GO
